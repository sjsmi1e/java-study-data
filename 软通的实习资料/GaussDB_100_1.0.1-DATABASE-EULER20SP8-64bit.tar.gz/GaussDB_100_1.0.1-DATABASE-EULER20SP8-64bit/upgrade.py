#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Perform hot backups of GaussDB100 databases.
# Copyright © Huawei Technologies Co., Ltd. 2010-2018. All rights reserved.

import sys
try:
    import os
    import time
    import re
    import getopt
    import pickle
    import getpass
    import subprocess
    import socket
    import platform
    import tarfile
    sys.path.append(os.path.split(os.path.realpath(__file__))[0])
    sys.dont_write_bytecode = True

    from funclib import CommandTool, exec_popen
    from funclib import get_error_msg, Execution, SshToolException, get_abs_path
    from funclib import CommonValue
except Exception as err:
    sys.exit("Upgrade Failed: Unable to import module: %s." % str(err))

# support the oldest python versions is 2.4.2
PYTHON242 = "2.4.2"
PYTHON25 = "2.5"

# check sha256 sum need hashlib since python 2.5
# and lib sha256 between 2.4.2 to 2.5
try:
    gPyVersion = platform.python_version()
    PYBIN = "python"

    if gPyVersion[0] == "3":
        _pybin = get_abs_path("python3")
        if _pybin:
            PYBIN = "python3"

    if(gPyVersion >= PYTHON242 and gPyVersion < PYTHON25):
        import sha256
    elif(gPyVersion >= PYTHON25):
        import hashlib
    else:
        print(("Upgrade Failed: This install script can not support python version : %s" % gPyVersion))
        sys.exit(1)
except ImportError as err:
    sys.exit("Upgrade Failed: Unable to import module: %s." % str(err))

UPGRADE_MODE_HA = "ha"
UPGRADE_MODE_SINGLE = "single"

STEP_PRECHECK = "upgrade_precheck"
STEP_RUN = "upgrade_run"
STEP_ROLLBACK = "upgrade_rollback"
STEP_ROLLBACK_CHECK = "upgrade_rollback_check"
STEP_CLEAN = "upgrade_clean"
STEP_SUCCESS = "SUCCESS"
STEP_FAILED = "FAILED"
STEP_BEGIN = "BEGIN"

SUBSTEP_PRECHECK_DISTRIBUTE_PKG="distribute-pkg"
SUBSTEP_PRECHECK_SSHEXKEY = "sshexkey"
SUBSTEP_PRECHECK_PRETEST = "pretest"
SUBSTEP_PRECHECK_CHECK_NODE = "check-none"
SUBSTEP_PRECHECK_CHECK_VER = "check-version"

UPGRADE_TYPE_BINARY = 'binary'
UPGRADE_TYPE_SYSTABLE = 'systable'


def normPath(path):
    '''
    return path that 
    expand ~
    absolution path
    real path
    '''
    p = os.path.expanduser(path)
    p = os.path.abspath(p)
    p = os.path.realpath(p)

    return p

def check_illegal_char(check_info):
    '''
    check the path if legal
    '''
    # the list of invalid characters
    VALUE_CHECK_LIST = ["|", ";", "&", "$", "<", ">", "`", "\\", "'", "\"", "{", "}", "(", ")", "[", "]", "~", "*",
                        "?", "!", "\n", " "]
    for ch in VALUE_CHECK_LIST:
        if check_info.find(ch)>= 0:
            raise Exception("The %s contains invalid characters: '%s'" % (check_info, ch))

def checkLegalityOfPath(path):
    '''
    check the path if legal
    :param path:
    :return:
    '''
    check_illegal_char(path)

def getSha256obj():
    '''
    return sha256 object
    '''
    if(gPyVersion >= PYTHON242 and gPyVersion < PYTHON25):
        sha256Obj = sha256.new()
    elif(gPyVersion >= PYTHON25):
        sha256Obj = hashlib.sha256()
    if(sha256Obj == None):
        raise Exception("check integrality of run file failed, can not get verification Obj.")
    return sha256Obj

def calcSha256Sum(targetFile):
    '''
    calculate sha256 sum
    '''

    sha256Obj = getSha256obj()

    with open(targetFile, 'rb') as fp:

        strRead = ""
        while True:
            strRead = fp.read(8096)
            if(not strRead):
                break
            sha256Obj.update(strRead)

        strSHA256 = sha256Obj.hexdigest()

        return strSHA256

def checkSHA256(checkFile, sha256sum):
    '''
    check file's sha256 sum
    return True if matched
    '''

    if(checkFile == ""):
        raise Exception("Can not find run file.")

    if not sha256sum:
        raise Exception("Can not recognize sha256 sum.")

    f = None
    sha256Obj = None
    strSHA256 = ""
    isSameSHA256=False
    try:
        with open(checkFile, "rb") as f:
            if(gPyVersion >= PYTHON242 and gPyVersion < PYTHON25):
                sha256Obj = sha256.new()
            elif(gPyVersion >= PYTHON25):
                sha256Obj = hashlib.sha256()
            if(sha256Obj == None):
                raise Exception("check integrality of run file failed, can not get verification Obj.")
            strRead = ""
            while True:
                strRead = f.read(8096)
                if(not strRead):
                    break
                sha256Obj.update(strRead)
            strSHA256 = sha256Obj.hexdigest()
            if(strSHA256 == sha256sum):
                isSameSHA256 = True
            else:
                isSameSHA256 = False
    except Exception as ex:
        raise Exception("Check integrality of run file except: %s" % str(ex))

    return isSameSHA256

def execShellCmd(cmd, envSetting, time_out=0, stdin_ex=None):
    '''
    execute shell command
    cmd -- the command
    '''
    status ,outputs = execShellCmdEx(cmd, envSetting, time_out, stdin_ex)
    
    output = "%s%s" % (outputs[0], outputs[1])
    if status != 0:
        raise Exception("Error:\n%s" % output)

    return status, output

def execShellCmdEx(cmd, envSetting, time_out=0, stdin_ex=None):
    '''
    execute shell command
    cmd -- the command
    '''

    outputs = []
    extra_info = "\nError: sysdba login is disabled, please specify -P parameter to input password, refer to --help."

    if envSetting:
        cmd = "%s && %s" % (envSetting, cmd)

    if time_out:
        #####################################################
        # when passed the time_out parameter
        # means this call will wait at most time_out seconds
        # for this case
        #    do not call the communicate interface of Popen
        #    it will wait util subprocess exit
        #    use poll of Popen to detect whether the subprocess finished
        # if poll returned not None
        #    the subprocess has finished
        # else
        #    wait 1 seconds and continue
        ########################################################
        p = subprocess.Popen(['bash', '-c', cmd], stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        if stdin_ex:
            stdin_ex = '%s\n' % stdin_ex
            if gPyVersion[0] == "3":
                stdin_ex = stdin_ex.encode()
            p.stdin.write(stdin_ex)
            p.stdin.flush()
        while time_out:
            if p.poll() != None:
                status = p.returncode
                outputs.append(p.stdout.read().strip())
                outputs.append(p.stderr.read().strip())
                break
            else:
                time.sleep(1)
                time_out -= 1
        else:
            p.kill()
            raise Exception("Timeout when executing shell command!" )
    else:
        p = subprocess.Popen(['bash', '-c', cmd], stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        if stdin_ex:
            stdin_ex = '%s\n' % stdin_ex
            if gPyVersion[0] == "3":
                stdin_ex = stdin_ex.encode()
            p.stdin.write(stdin_ex)
            p.stdin.flush()
        (stdoutdata, stderrdata) = p.communicate()
        status = p.returncode
        outputs.append(stdoutdata)
        outputs.append(stderrdata)

    if gPyVersion[0] == "3":
        # python3's Popen returned Byte
        # python2's Popen returned str
        # convert to str if python3
        outputs[0] = outputs[0].decode()
        outputs[1] = outputs[1].decode()

    if cmd.find('zsql') >= 0 and outputs[0].find('login as sysdba is prohibited') >= 0:
        outputs[0] = "%s%s" % (outputs[0], extra_info)

    return status, outputs


class VersionInfo(object):
    '''
    Database version info.
    parse verison info, compare version info.
    '''

    VERSION_TYPE_VRC = "vrc"
    VERSION_TYPE_DOT = "dot"

    def __init__(self, version_str="", version_file="", logger=None):
        '''
        :param version:
        '''
        # eg: GaussDB-100-V300R001C00SPC200B131 Debug 882296b
        # or GaussDB_100_1.0.1.B005 Release 7289c96
        self.version_str = version_str
        # package.xml
        self.version_file = version_file
        self.version_type = ""
        self.version = ""
        self.log = logger

        if self.version_str and self.version_file:
            raise Exception("Version string or version file just allow one.")

        if self.version_str:
            self.parse_version_str()
        elif self.version_file:
            self.parse_version_file()
        else:
            raise Exception("Version string or version file is required.")

    def parse_version_str(self):
        '''
        :return:
        '''
        vrc_pattern = ".*100.*V.*R.*C.*"
        dot_pattern = ".*GaussDB.*100.*\.B.*"
        if re.match(vrc_pattern, self.version_str):
            self.version = self.__get_str_vrc_version(self.version_str)
            self.version_type = VersionInfo.VERSION_TYPE_VRC
        elif re.match(dot_pattern, self.version_str):
            self.version = self.__get_str_dot_version(self.version_str)
            self.version_type = VersionInfo.VERSION_TYPE_DOT
        else:
            raise Exception("Not support this version %s" % self.version_str)

    def __get_str_vrc_version(self, version_str):
        '''
        get old vrc version string, eg: V300R001C00SPCxxxBxxx
        :param version_info: eg: GaussDB-100-V300R001C00SPCxxBxxx Release xxx
        :return:
        '''
        # if version has -, replace - to space
        version = ""
        version_info = version_str.replace("-", " ").split()
        for info in version_info:
            # get version VxxRxxCxxxx
            if re.match("V.*R.*C.*", info):
                version = info
                break

        if not version:
            raise Exception("Error: Get old database version failed. output: %s" % version_str)

        return version

    def __get_str_dot_version(self, version_str):
        '''
        get old version string: eg: 1.0.1.B005
        :param version_info: eg: GaussDB_100_1.0.x.Bxx, GaussDB_100_1.0.xTx.Bxxx, GaussDB_100_1.0.x.SPCx.Bxxx
        :return:
        '''
        # if version has _, replace _ to space
        version_info = version_str.replace("_", " ").split()
        try:
            version = version_info[2]
        except Exception as _:
            raise Exception("Error: Get old database version failed. output: %s" % version_str)

        return version

    def parse_version_file(self):
        '''
        parse version info from package.xml
        :param: package.xml
        two version pattern:
        version="GaussDB-100-V300R001C00SPCxxxBxxx Debug"
        version="GaussDB_100_1.0.x.Bxxx Release"
        dot version 3 format: GaussDB_100_1.0.x.Bxx, GaussDB_100_1.0.xTx.Bxxx, GaussDB_100_1.0.x.SPCx.Bxxx
        :return:
        '''
        if not os.path.exists(self.version_file):
            raise Exception("Error: File %s does not exists." % self.version_file)

        with open(self.version_file, 'r') as fp:
            lines = fp.readlines()

        for line in lines:
            # get version="xxx xxx VxxRxxCxxxx "
            # or version="xxx-xxx-xxx-VxxRxxCxxxx "
            vrc_pattern = "version=.*V.*R.*C.*"
            # get version="xxx xxx x.x.x.Bx"
            dot_version = "version=.*\.B.*"
            if re.match(vrc_pattern, line):
                version_str = line.replace("\"", "").replace("-", " ").split("=")[1].split()
                # get version VxxRxxCxxxx
                for info in version_str:
                    if re.match("V.*R.*C.*", info):
                        self.version = info
                        break
                self.version_type = VersionInfo.VERSION_TYPE_VRC
            elif re.match(dot_version, line):
                # get version x.x.x.Bxxx
                version_str = line.replace("\"", "").replace("_", " ").split("=")[1].split()
                self.version = version_str[2]
                self.version_type = VersionInfo.VERSION_TYPE_DOT

        if not self.version:
            raise Exception("Error: Get new database version failed. version file content: %s" % lines)

    def compare_version(self, version_a_obj, version_b_obj):
        '''
        :return:
        '''
        # can not compare bettween VRC and dot
        if version_a_obj.version_type != version_b_obj.version_type:
            raise Exception("Unsupported version %s -> %s" % (version_a_obj.version, version_b_obj.version))

        if version_b_obj.version_type == VersionInfo.VERSION_TYPE_VRC:
            return self.compare_vrc_version(version_a_obj.version, version_b_obj.version)
        else:
            return self.compare_dot_version(version_a_obj.version, version_b_obj.version)

    # #####################################
    # compare VRC database version
    # #####################################

    def is_number(self, ch):
        """
        function: if a number
        input : char
        output: NA
        return: BOOL
        """

        if ch >= '0' and ch <= '9':
            return True
        else:
            return False

    def get_sub_version(self, sub_version_type, version_str):
        """
        function: split vertion string to sub version
        input : sub type : V,R,C,SPC; version string
        output: NA
        return: version(int)
        """

        try:
            begin = version_str.index(sub_version_type)
        except ValueError as _:
            return 0
        begin += len(sub_version_type)

        ver_number = -1
        end = begin
        while end < len(version_str):
            if self.is_number(version_str[end]):
                end += 1
            else:
                break

        ver_number = int(version_str[begin:end])

        return ver_number

    def get_patch_version(self, version_str):
        '''
        expand spc xxx to xxx0 or
        fetch cp xxxx to xxxx
        '''
        ver = self.get_sub_version('SPC', version_str)
        if ver == 0:
            ver = self.get_sub_version('CP', version_str)
        else:
            ver *= 10

        if ver == 0:
            ver = 1000

        return ver

    def compare_vrc_version(self, a_version, b_version):
        """
        function: verify old new version, if not right, error exit
        input : version strings: eg V300R001C00SPCxxxBxxx
        output: NA
        """

        a_v_ver = self.get_sub_version('V', a_version)
        b_v_ver = self.get_sub_version('V', b_version)
        self.log("Old v version: %s. New v version: %s." % (a_v_ver, b_v_ver))

        a_r_ver = self.get_sub_version('R', a_version)
        b_r_ver = self.get_sub_version('R', b_version)
        self.log("Old r version: %s. New r version: %s." % (a_r_ver, b_r_ver))

        a_c_ver = self.get_sub_version('C', a_version)
        b_c_ver = self.get_sub_version('C', b_version)
        self.log("Old c version: %s. New c version: %s." % (a_c_ver, b_c_ver))

        a_p_ver = self.get_patch_version(a_version)
        b_p_ver = self.get_patch_version(b_version)
        self.log("Old patch version: %s. New patch version: %s." % (a_p_ver, b_p_ver))

        a_b_ver = self.get_sub_version('B', a_version)
        b_b_ver = self.get_sub_version('B', b_version)
        self.log("Old b version: %s. New b version: %s." % (a_b_ver, b_b_ver))

        if a_v_ver > b_v_ver:
            return 1
        elif a_v_ver < b_v_ver:
            return -1

        if a_r_ver > b_r_ver:
            return 1
        elif a_r_ver < b_r_ver:
            return -1

        if a_c_ver > b_c_ver:
            return 1
        elif a_c_ver < b_c_ver:
            return -1

        if a_p_ver > b_p_ver:
            return 1
        elif a_p_ver < b_p_ver:
            return -1

        if a_b_ver > b_b_ver:
            return 1
        elif a_b_ver < b_b_ver:
            return -1
        return 0

    # #####################################
    # compare X.X.X database version
    # #####################################

    def __get_dot_version_list(self, version):
        '''
        :param: version 1.0.x.Bxxx, 1.0.xTx.Bxxx, 1.0.x.SPCx.Bxxx
        :return:
        '''

        if version.find("T") < 0 and version.find("SPC") < 0:
            # 1.0.x.Bxxx --> 1.0.x.xxx
            tmp_version = version.replace("B", "")
            # [1, 0, 0, xxx]
            ver_list = tmp_version.split(".")
            # [1, 0, 0, 0, xxx]
            ver_list.insert(3, '0')
        else:
            tmp_version = version
            # 1.0.xTx.Bxxx --> 1.0.x.Tx.Bxxx
            if version.find(".T") < 0:
                tmp_version = version.replace("T", ".T")
            # remove T, SPC, B
            # 1.0.x.Tx.Bxxx, 1.0.x.SPCx.Bxxx --> 1.0.x.x.xxx
            tmp_version = tmp_version.replace("T", "").replace("SPC", "").replace("B", "")
            ver_list = tmp_version.split(".")

        return ver_list

    def compare_dot_version(self, a_version, b_version):
        '''
        verify old and new version, if not right, error exit
        version strings, eg:
        GaussDB_100_1.0.x.Bxxx
        GaussDB_100_1.0.xTx.Bxxx
        GaussDB_100_1.0.x.SPCx.Bxxx
        :return:
        '''

        a_ver_list = self.__get_dot_version_list(a_version)
        self.log("Old version list." % a_ver_list)
        b_ver_list = self.__get_dot_version_list(b_version)
        self.log("New version list." % b_ver_list)

        # old version format is different with new, can not compare
        if len(a_ver_list) != len(b_ver_list):
            raise Exception("Version %s or Version %s format is not right." % (a_version, b_version))

        # if C version is tha same, eg: old 1.0.0 == new 1.0.0,
        # T version can not to SPC version; SPC version can not to T version
        # if C version is not equal, it is ok
        if (a_version.find("T") > -1 and b_version.find("SPC") > -1) or \
                (a_version.find("SPC") > -1 and b_version.find("T") > -1):
            # c version is the same
            if "".join(a_ver_list[0:3]) == "".join(b_ver_list[0:3]):
                raise Exception("Unsupported version %s -> %s" % (a_version, b_version))

        self.log("Compare old and new version list.")

        for i, a_num in enumerate(a_ver_list):
            b_num = b_ver_list[i]
            # old is big
            if a_num < b_num:
                return -1
            elif a_num == b_num:
                # the same, compare next
                continue
            else:
                # old is small
                return 1
        else:
            # the same
            return 0


class PackageInfo():
    '''
       supported package file name:
       xxx-V300R001C00-xxx-REDHAT-64bit.tar.gz
       inner run package name:
       xxx-V300R001C00-xxx-RUN-REDHAT-64bit.tar.gz
    '''
    def __init__(self, pkg_file, run_pkg=False):
        '''
        init package file attrs from 
        package file name pkg_file
        '''
        # __full_path is /xxx/newpkg/*DATABASE*.tar.gz
        self.__full_path = str(pkg_file)
        # __basename *DATABASE*.tar.gz
        self.__basename = os.path.basename(self.__full_path)
        self.__level1_dir = ''
        self.__level2_dir = ''
        self.__runfile = ''
        self.__sha256file = ''
        self.__run_pkg = run_pkg

        # DATABASE package has ora-dialect.sql, it it green package
        self.is_green_pkg = False

        if self.__run_pkg:
            return

        if not os.path.exists(self.__full_path):
            raise Exception("File %s does not exists!" % self.__full_path)
        if not os.path.isfile(self.__full_path):
            raise Exception("%s is not a file!" % self.__full_path)

        file_name = self.__basename.split('.')

        if not (file_name[-2] == 'tar' and file_name[-1] == 'gz'):
            raise Exception("Expect package file format xxx.tar.gz!")

    def __find_path(self, path, key_word):

        cmd = 'cd %s; find . -maxdepth 1 -name "%s"' % (path, key_word)
        _, outputs = execShellCmdEx(cmd, '')
        target = outputs[0].strip()
        lines = target.split('\n')
        if len(lines) > 1:
            raise Exception("More than one target found in %s: %s\nPlease remove the unused files." % (path, ' ;'.join(lines)))
        absPath = os.path.join(path, target)
        if not os.path.isfile(absPath):
            raise Exception("Cannot find %s in %s" % (key_word, path))
        return os.path.basename(absPath)

    def unzip(self):
        '''
        unzip the tar file
        and inner RUN package tar file
        '''

        if self.__run_pkg:
            return

        dir_name = os.path.dirname(self.__full_path)

        cmd = 'cd %s; tar xzf %s' % (dir_name, self.__basename)
        execShellCmd(cmd, '')

        # get real directory name in tar file
        tars = tarfile.open(self.__full_path)
        basename = tars.getnames()[0]
        tars.close()

        self.__level1_dir = os.path.join(dir_name, basename)
        if not os.path.isdir(os.path.join(dir_name, self.__level1_dir)):
            raise Exception("Cannot find path %s" % self.__level1_dir)

        self.__runfile = self.__find_path(os.path.join(dir_name, self.__level1_dir), "*RUN*.tar.gz")
        self.__sha256file = self.__find_path(os.path.join(dir_name, self.__level1_dir), "*RUN*.sha256")

        cmd = 'cd %s; tar xzf %s' % (os.path.join(dir_name, self.__level1_dir), self.__runfile)
        execShellCmd(cmd, '')
        run_path_file = os.path.join(dir_name, self.__level1_dir, self.__runfile)
        run_tar = tarfile.open(run_path_file)
        self.__level2_dir = run_tar.getnames()[0]
        run_tar.close()

    def processDialect(self):
        '''
        unzip the Dialect tar file
        '''
        if self.__run_pkg:
            return

        dir_name = os.path.dirname(self.__full_path)

        dialect_file = self.__find_path(dir_name, "*DIALECT*.tar.gz")
        cmd = 'cd %s; tar xzf %s' % (dir_name, dialect_file)
        execShellCmd(cmd, '')

        sql_path = os.path.join(dir_name, self.__level1_dir, self.__level2_dir, 'admin/scripts/sql_dialect')
        dialect_path = dialect_file[:-7]

        version_file = os.path.join(dir_name, dialect_path, 'package.xml')
        run_version = os.path.join(self.getPackagePath(), 'package.xml')

        if os.path.exists(version_file):
            dia_ver_obj = VersionInfo(version_file=version_file)
            db_ver_obj = VersionInfo(version_file=run_version)
            if dia_ver_obj.version != db_ver_obj.version:
                raise Exception("DIALECT version: %s is not equal to target "
                                "version: %s" % (dia_ver_obj.version, db_ver_obj.version))

        cmd = 'chmod %s %s && cp %s/* %s && chmod %s %s' % (CommonValue.KEY_DIRECTORY_MODE_STR, sql_path, os.path.join(dir_name, dialect_path),
                                                            sql_path, CommonValue.MID_FILE_MODE, sql_path)
        execShellCmd(cmd, '')


    def getPackagePath(self):
        '''
        return the unzipped RUN package path
        '''

        if self.__run_pkg:
            return self.__full_path

        dirname = os.path.dirname(self.__full_path)
        run_path = os.path.join(dirname, self.__level1_dir, self.__level2_dir)
        return run_path

    def getRunPackage(self):
        '''
        return run package path and sha256 file path
        '''
        if self.__run_pkg:
            return '', ''

        dirname = os.path.dirname(self.__full_path)

        run_path = os.path.join(dirname, self.__level1_dir, self.__runfile)
        sha_path = os.path.join(dirname, self.__level1_dir, self.__sha256file)

        return run_path, sha_path

    def exists(self, path_from_run_path):
        '''
        return the path in package path if exists
        '''
        return os.path.exists(os.path.join(self.getPackagePath(), path_from_run_path))

class Config():
    '''
    parse the config file : zengine.ini
    '''

    def __init__(self, cfg):
        '''
        Construction function for Config class
        parse the config file
        cfg -- file path to config
        '''
        self.__cfg = cfg
        self.__para_dict = {}
        if not os.path.exists(self.__cfg):
            raise Exception("File %s does not exists!" % self.__cfg)
        if not os.path.isfile(self.__cfg):
            raise Exception("%s is not a file!" % self.__cfg)
        with open(self.__cfg, 'r') as fp:
            # parse format:
            # attr_name = value
            # strip all the blank characters
            content = fp.read()
        lines = content.split('\n')
        for line in lines:
            if line.strip():
                # filter comment; such as #LSNR_PORT=1611
                if line.strip().startswith("#"):
                    continue
                if line.find('=') > 0:
                    config = line.split('=', 1)
                    if len(config) == 2:
                        self.__para_dict[config[0].strip()] = config[1].strip()

    def getConfigValue(self, config_name):
        '''
        get value in config file by parameter name
        config_name -- name in config file
        '''

        default_value = ''

        if config_name == 'LSNR_PORT':
            default_value = '1611'

        if config_name in list(self.__para_dict.keys()):
            return self.__para_dict[config_name]

        return default_value

    def getCtlFiles(self):
        '''
        get ctrl files path
        '''
        return self.getConfigValue('CONTROL_FILES').strip('()').split(',')

    def getPeerInfo(self):
        '''
        get peer information : ip address and port
        '''
        peer_info = {}

        for k in list(self.__para_dict.keys()):
            if k.find('ARCHIVE_DEST_') >= 0:
                val = str(self.__para_dict[k])
                if val.upper().find('SERVICE') >= 0:
                    new_val = val.upper().replace("=", " ")
                    tmp_val = new_val.split()
                    service_index = tmp_val.index("SERVICE")
                    if len(tmp_val) >= service_index+1:
                        # when ip is ipv6, split string by last :, split one time.
                        # so index 0 is ip, index 1 is port
                        services = tmp_val[service_index+1].rsplit(':', 1)
                        peer_info[services[0]] = services[1]

        return peer_info

class DatabaseInstance():
    '''
    this class is representation of instance of database
    '''

    def __init__(self, data_dir, gsdb_home_dir):
        '''
        init for the database instance object
        '''

        self.__role = ''
        self.__data_dir = data_dir
        self.__gsdb_home = gsdb_home_dir
        self.__config = Config(os.path.join(self.__data_dir, "cfg/zengine.ini"))
        self.__port = self.__config.getConfigValue('LSNR_PORT')
        self.__host = self.__config.getConfigValue('LSNR_ADDR')
        self.__replport = self.__config.getConfigValue('REPL_PORT')
        self.__peer_info = self.__config.getPeerInfo()
        self.__ctl_files = self.__config.getCtlFiles()
        if self.__host == '0.0.0.0':
            self.__host = '127.0.0.1'

    def ctl_files(self):
        '''
        return ctl files of this database instance
        '''
        return self.__ctl_files
        
    def port(self):
        '''
        return port of this database instance
        '''
        return self.__port

    def host(self):
        '''
        return host ip of this database instance
        '''
        return self.__host

    def replport(self):
        '''
        return replport of this database instance
        '''
        return self.__replport

    def peer_info(self):
        '''
        return peer information of this database instance
        '''
        return self.__peer_info

    def gsdb_home(self):
        '''
        return gsdb_home of this database instance
        '''
        return self.__gsdb_home

    def datadir(self):
        '''
        return datadir of this database instance
        '''
        return self.__data_dir

    def role(self):
        '''
        return role of this database instance
        '''
        if self.__role:
            return self.__role
        else:
            raise Exception("Unknown role of %s" % self.__data_dir)

    def isStandalone(self):
        '''
        return False if peer is not empty
        '''
        return not self.__peer_info

    def setRole(self, db_role):
        '''
        set database instance's role
        '''
        self.__role = db_role

    def execSqlFile(self, sql_file, envs, db_user, db_passwd):
        '''
        execute a sql file
        envs will pass to execShellCmd
        if user is sysdba
            use / as sysdba
        else
            use echo 'passwd' | user
        for the process 'echo' runs really fast
        '''

        stdin_ex = ''
        if db_user == 'sysdba':
            cmd = "%s/zsql / as sysdba 127.0.0.1:%s -D %s -f \"%s\"" % (os.path.join(self.__gsdb_home, "bin"), self.__port, self.__data_dir, sql_file)
        else:
            cmd = "%s/zsql %s@127.0.0.1:%s -f \"%s\"" % (os.path.join(self.__gsdb_home, "bin"), db_user, self.__port, sql_file)
            stdin_ex = db_passwd

        status, output = execShellCmd(cmd, envs, stdin_ex=stdin_ex)

        error_list = []
        for line in output.split('\n'):
            if line.find("column") >=0 and line.find("already exists") >= 0:
                continue
            result = re.match(r'GS-\d{5}',line.strip())
            if result:
                error_list.append(result)

        if error_list:
            raise Exception("Error:\n%s" % output)

        return status, output

    def execSql(self, sql, envs, db_user, db_passwd, time_out=0):
        '''
        execute a sql commands
        same as execSqlFile
        '''

        stdin_ex = ''
        if db_user == 'sysdba':
            cmd = "%s/zsql / as sysdba 127.0.0.1:%s -D %s -c \"%s\"" % (os.path.join(self.__gsdb_home, "bin"), self.__port, self.__data_dir, sql)
        else:
            cmd = "%s/zsql %s@127.0.0.1:%s -c \"%s\"" % (os.path.join(self.__gsdb_home, "bin"), db_user, self.__port, sql)
            stdin_ex = db_passwd

        return execShellCmd(cmd, envs, time_out, stdin_ex=stdin_ex)


class NodeInfo:
    '''
    node information for ha upgrade
    '''
    def __init__(self, ip, pkg, app_path, backup_path, _data_path, _packtype='package'):
        '''
        ip - node ip
        pkg - package name include path
        app_path - install path
        backup_path - backup path
        _data_path - instance data path
        '''
        self.check_ip_valid(ip)
        self.ip = ip
        self.app_path = app_path
        self.data_path = _data_path
        self.pkg = pkg
        self.backup_path = os.path.normpath(os.path.join(backup_path, "ha_upgrade_backup"))
        if _packtype == 'package':
            self.pkg_path = os.path.dirname(os.path.realpath(pkg))
            self.upgrade_path = os.path.join(self.backup_path, "upgrade_tmp")
        else:
            self.pkg_path = pkg
            self.upgrade_path = os.path.dirname(os.path.realpath(__file__))

    def check_ip_valid(self, ip):
        '''
        check ip is valid, ip support ipv4, ipv6
        :return:
        '''
        # check if ip has illegal characters
        check_illegal_char(ip)
        # check ipv4 or ipv6 is valid
        try:
            socket.inet_aton(ip)
        except socket.error:
            try:
                socket.inet_pton(socket.AF_INET6, ip)
            except socket.error:
                raise UpgradeException("The invalid IP:%s is not ipv4 or ipv6 format." % ip)

class UpgradeConfig:
    '''
    class for ha upgrade
    '''

    def __init__(self, _config_file, _auto_rollback=True, _upgrade_mode=UPGRADE_MODE_SINGLE, _packtype="package"):
        '''
        _config_file - node configure file: 
        ip=package,appdir,backupdir,data1,data2,... such as:
        10.0.0.1=/opt/gaussdb/pkg/{package}.tar.gz,/opt/gaussdb/app,/opt/gaussdb/backup,/opt/gaussdb/data1,/opt/gaussdb/data2,...
        10.0.0.2=/opt/gaussdb/pkg/{package}.tar.gz,/opt/gaussdb/app,/opt/gaussdb/backup,/opt/gaussdb/data1,/opt/gaussdb/data2,...

        ssh_tool - execute shell command in remote node
        nodes    - list for all node
        ips      - list for all node's ip
        ha_upgrade_step_file - 
        '''
        self.config_file = _config_file
        self.nodes = []
        self.ips = []
        self.local_node = None
        self.local_ip = ""
        self.ha_mode = False
        if _upgrade_mode == UPGRADE_MODE_HA:
            self.ha_mode = True
        self.packtype = _packtype

        lines = []
        with open(self.config_file, 'r') as fp:
            lines = fp.readlines()
        for ll in lines:
            # skip empty line
            # ll.strip(), Remove spaces, tabs
            ll = ll.strip().strip('\n')
            if not ll:
                continue
            try:
                info = ll.split('=')
                ip = info[0].strip()
                val = info[1].strip().split(',')
                # _v.strip(), Remove spaces, tabs
                val = [_v.strip() for _v in val if _v.strip()]
                # check path valid, blacklist check
                self.__check_config_path_valid(val)
                # get data string, eg: data1,data2,data3
                data_path_str = ",".join(val[3:])
                node = NodeInfo(ip, val[0], val[1], val[2], data_path_str, _packtype)
            except Exception as ex:
                raise UpgradeException("Failed to parse config file, "
                                       "please check your config file.\nOutput: %s" % str(ex))

            if not self.local_node:
                self.local_node = node
                self.local_ip = node.ip
            self.nodes.append(node)
            self.ips.append(ip)

        # configure file is error
        if len(self.nodes) > 1 and '127.0.0.1' in self.ips:
            raise UpgradeException("configure file has 127.0.0.1, only allow do single mode."
                                   " configure file not allow more ip info.") 
        if not self.nodes:
            raise UpgradeException("configure file is empty file, you"
                                   " must write nodes information in it.")

        if len(self.nodes) == 1:
            if self.ha_mode:
                raise UpgradeException("Upgrade for ha mode must be more"
                                       " than one nodes in configure file.")

            if self.local_node == None:
                raise UpgradeException("Upgrade for single mode, "
                                       "local node must be in configure file.")
        else:
            if not self.ha_mode:
                raise UpgradeException("Upgrade for single mode must be one"
                                       " node in configure file.")

        self.cmd_tool = CommandTool()
        self.need_passwd = False
        self.user = 'sys'
        self.db_passwd = ''
        self.db_passwd_mount = ''
        self.auto_rollback = _auto_rollback
        self.pre_step = ""
        self.pre_sup_step = ""
        if not self.local_node.backup_path:
            raise UpgradeException("The path for backup files is not specified.")

        self.ha_upgrade_step_file = os.path.join(self.local_node.backup_path, "ha_upgrade_step_file")
        self.upgrade_sshkey_mark = os.path.join(self.local_node.backup_path, "ha_upgrade_sshkey_file")

    def __check_config_path_valid(self, path_infos):
        '''
        check path is valid after parse config file
        :return:
        '''
        for path in path_infos:
            # blacklist check
            checkLegalityOfPath(path)

    def get_local_backup_path(self):
        return self.local_node.backup_path

    def check_step(self, cur_step):
        '''
        check step for ha upgrade
        '''
        step_tab = {STEP_PRECHECK: self.__check_step_precheck,
                    STEP_RUN: self.__check_step_run,
                    STEP_CLEAN: self.__check_step_cleanup,
                    STEP_ROLLBACK: self.__check_step_rollback,
                    STEP_ROLLBACK_CHECK: self.__check_step_rollback_check}
        mode, pre_step, sub_step, result = self.__get_upgrade_step()
        if cur_step in [STEP_PRECHECK, STEP_CLEAN] and (not mode):
            return
        if (mode and self.ha_mode and mode != UPGRADE_MODE_HA) \
          or (mode and not self.ha_mode and mode == UPGRADE_MODE_HA):
            raise UpgradeException("Upgrade mode must be same as the last step.")

        if cur_step in [STEP_CLEAN]:
            step_tab[cur_step](pre_step, sub_step, result)
        else:
            step_tab[cur_step](pre_step, result)

        # run and rollback has more than one step and can not re-execute
        # so we must update step file first to avoid to can not update
        # the step file
        if cur_step in [STEP_RUN, STEP_ROLLBACK]:
            self.update_upgrade_step(cur_step, "None", STEP_BEGIN)

    def update_upgrade_step(self, step, sub_step, result=STEP_SUCCESS):
        '''
        write step and result to step file, the content is 'upgrade_mode:step:sub_step:result'
        such as ha:run:upgrade:SUCCESS or ha:precheck:distribute_pkg:FAILED
        '''
        if self.ha_mode:
            mode = UPGRADE_MODE_HA
        else:
            mode = UPGRADE_MODE_SINGLE

        with open(self.ha_upgrade_step_file, 'w') as fp:
            fp.write("%s:%s:%s:%s" % (mode, step, sub_step, str(result)))

    def __get_upgrade_step(self):
        '''
        get current step and result from step file
        '''
        step = ""
        if self.__step_file_not_exist():
            return "", "", "", ""

        with open(self.ha_upgrade_step_file, 'r') as fp:
            step = fp.readline().split(':')
        if step:
            return step[0], step[1], step[2], step[3]
        return "", "", "", ""

    def __check_step_run(self, pre_step, result):
        '''
        check pre-step for run, precheck or rollback step success can execute run
        '''
        msg1 = ("Step file for upgrade not found, "
                "you must execute precheck step first")
        if not os.path.exists(self.ha_upgrade_step_file):
            raise UpgradeException(msg1)

        msg2 = ("Can't execute run step for upgrade, you"
                " must exexute precheck or rollback step successfully first.")
        if pre_step not in [STEP_ROLLBACK, STEP_PRECHECK]:
            raise UpgradeException(msg2)

        if pre_step in [STEP_ROLLBACK, STEP_PRECHECK] and result == STEP_FAILED:
            raise UpgradeException(msg2)

    def __check_step_cleanup(self, pre_step, sub_step, result):
        '''
        check pre-step for cleanup, run step success can execute cleanup
        '''
        if (pre_step == STEP_RUN \
            or pre_step == STEP_PRECHECK \
            or pre_step == STEP_ROLLBACK) and result == STEP_SUCCESS:
            return

        if pre_step == STEP_PRECHECK and sub_step == SUBSTEP_PRECHECK_SSHEXKEY and result == STEP_SUCCESS:
            return
        raise UpgradeException("cleanup step can't be execute when pre-step %s and %s" \
                               % (pre_step, result))

    def __check_step_rollback(self, pre_step, result):
        '''
        check pre-step for rollback, rollback-check step success can execute rollback
        '''
        msg1 = ("Step file for upgrade not found, You can't execute rollback.")
        if not os.path.exists(self.ha_upgrade_step_file):
            raise UpgradeException(msg1)

        if pre_step == STEP_ROLLBACK_CHECK and result == STEP_SUCCESS:
            return
        raise UpgradeException("rollback step only can be executed when rollback-check successfully.")

    def __check_step_rollback_check(self, pre_step, result):
        '''
        check pre-step for rollback-check, run step failed can execute rollback-check
        '''
        msg1 = ("Step file for upgrade not found, You can't execute rollback-check.")
        if self.__step_file_not_exist():
            raise UpgradeException(msg1)
        if (pre_step == STEP_RUN or pre_step == STEP_ROLLBACK) and result != STEP_SUCCESS:
            return
        if pre_step == STEP_ROLLBACK_CHECK:
            return
        raise UpgradeException("rollback-check step only can be executed when run step failed.")

    def __check_step_precheck(self, pre_step, result):
        '''
        '''
        if pre_step != STEP_PRECHECK and (pre_step != STEP_ROLLBACK and result != STEP_SUCCESS):
            raise UpgradeException('precheck step can not be execute, pre step is %s:%s.' % (pre_step, result))

    def __step_file_not_exist(self):
        return not os.path.exists(self.ha_upgrade_step_file)

    def __step_file_exist(self):
        return os.path.exists(self.ha_upgrade_step_file)

class UpgradeException(Exception):
    '''
    '''
    pass


class Upgrade():
    '''
    all tools used by upgrading
    '''

    def __assert_not_empty(self, val, tag):
        '''
        assert value not empty
        or raise Exception
        '''

        if not val:
            raise Exception("%s should not been empty." % tag)

    def __assert_exists_path(self, val, tag):
        '''
        assert value path exists
        or raise Exception
        '''

        if not os.path.exists(val):
            raise Exception("%s or %s path does not exists." % (val, tag))

    def __assert_is_dir(self, val, tag):
        '''
        assert value is dir
        or raise Exception
        '''

        if not os.path.isdir(val):
            raise Exception("%s or %s path is not a dir." % (val, tag))

    def __init__(self, pkg_file, backup_path, db_home, db_data, passwd_ui, is_run_package, _action, upgrade_config=None):
        '''
        pkg_file -- file path to new package file
        backup_path -- path for backup when upgrading
        db_home -- GSDB_HOME
        '''

        self.DIRECTORY_PERMISSION = '0700'
        self.FILE_PERMISSION = '0600'
        self.MIN_FILE_PERMISSION = '0400'
        self.MID_FILE_PERMISSION = '0500'
        self.DIRECTORY_MODE = '700'
        self.MIN_FILE_MODE = '400'
        self.MID_FILE_MODE = '500'

        self.UPGRADE_ZENGINE_NAME = "uzengine"
        self.DIALECT_MIN_VERSION = "V300R001C00SPC200B129"

        self.__is_run_package = is_run_package

        self.__view_files = {"admin/scripts/initview.sql":"view_drop.sql",
                             "admin/scripts/initplsql.sql":"pl_drop.sql",
                             "admin/scripts/initwsr.sql":"wsr_drop.sql"}

        self.__dialect_files = {"admin/scripts/sql_dialect/ora-dialect.sql":"ora_drop.sql"}

        self.__is_degrade = False
        self.__upgrade_type = ""
        self.__db_instances = []
        self.__update_list = ['bin', 'admin', 'lib']
        # extended update list , if does not exist, skip
        self.__update_list_ext = ['add-ons', 'package.xml']
        self.__action = _action
        self.__envSetting = ""
        self.__groups = None
        self.__lfn_infos = {}
        self.__sysaux = False
        self.__system_file_map = {}
        self.__rollback_clean_tablespace = []
        self.__rollback_clean_files = []

        # information for ha upgrade
        self.__config = upgrade_config
        if not self.__config:
            if db_home:
                self.__gsdb_home = db_home
            else:
                self.__gsdb_home = os.getenv('GSDB_HOME')

            self.__assert_not_empty(self.__gsdb_home, "GSDB_HOME")
            self.__assert_exists_path(self.__gsdb_home, "GSDB_HOME")
            self.__assert_is_dir(self.__gsdb_home, "GSDB_HOME")

            self.__gsdb_home = normPath(self.__gsdb_home)
            checkLegalityOfPath(self.__gsdb_home)

        # get login name and ip from who -m
        who_m = ''
        p = subprocess.Popen(['bash', '-c', 'who -m'], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        (stdoutdata, _) = p.communicate()
        status = p.returncode
        if gPyVersion[0] == "3":
            who_m = stdoutdata.decode()
        else:
            who_m = stdoutdata
        if status!=0:
            raise Exception("Failed when fetching login user and ip address!")

        # use '' when something goes wrong
        who_m = who_m.split()
        self.__login_user = ''
        self.__login_ip = ''
        if len(who_m) >= 5:
            self.__login_user = who_m[0]
            self.__login_ip = who_m[4].strip('()')
        elif len(who_m) > 0 and len(who_m) < 5:
            self.__login_user = who_m[0]

        # ha-upgrade don't need --GSDB_DATA, we will get instance data dir from --config-file
        if not self.__config:
            if db_data:

                for datadir in db_data:

                    self.__assert_not_empty(datadir, "GSDB_DATA")
                    self.__assert_exists_path(datadir, "GSDB_DATA")
                    self.__assert_is_dir(datadir, "GSDB_DATA")
                    self.__db_instances.append(DatabaseInstance(datadir, self.__gsdb_home))

            else:

                data_env = os.getenv('GSDB_DATA')

                self.__assert_not_empty(data_env, "GSDB_DATA")
                self.__assert_exists_path(data_env, "GSDB_DATA")
                self.__assert_is_dir(data_env, "GSDB_DATA")

                data_env = normPath(data_env)
                checkLegalityOfPath(data_env)
                self.__db_instances.append(DatabaseInstance(data_env, self.__gsdb_home))

            self.__is_standalone = False
            # if a standalone database service
            if len(self.__db_instances) == 1:
                if self.__db_instances[0].isStandalone():
                    self.__is_standalone = True

            self.__is_ha = False
            for inst in self.__db_instances:
                if not inst.isStandalone():
                    self.__is_ha = True
                    break

            export_path = "export PATH=%s:$PATH" % os.path.join(self.__gsdb_home, "bin")
            export_lib = "export LD_LIBRARY_PATH=%s:%s:$LD_LIBRARY_PATH" % (os.path.join(self.__gsdb_home, "lib"), os.path.join(self.__gsdb_home, 'add-ons'))
            export_quiet = "export ZSQL_SSL_QUIET=TRUE"
            link_str = " && "
            self.__envSetting = "%s%s%s%s%s" % (export_path, link_str, export_lib, link_str, export_quiet)

        if not backup_path:
            raise Exception("Backup path should not been empty. Parameter --backupdir is required.")

        self.__backup = os.path.join(backup_path, "upgrade_backup")
        if not os.path.exists(self.__backup):
            self.__execShellCmd("mkdir -p -m %s %s" % (self.DIRECTORY_PERMISSION, self.__backup))
        if not os.path.isdir(self.__backup):
            raise Exception("Path %s is not a path!" % self.__backup)

        self.__upgrade_step_file = os.path.join(self.__backup, "upgrade_step_info")
        self.__logfile = os.path.join(backup_path, 'upgrade.log')
        if not os.path.exists(self.__logfile):
            with open(self.__logfile, 'w') as fp:
                fp.close()
        self.__execShellCmd("chmod %s %s" % (self.FILE_PERMISSION, self.__logfile))

        self.backup_flag_file = os.path.join(self.__backup, 'backup_fin')

        self.__pkg = pkg_file
        # use -s para, _config exists, get upgrade package
        if self.__config:
            self.__pkg = self.__config.local_node.pkg
            self.__gsdb_home = self.__config.local_node.app_path
            self.__backup = os.path.join(self.__config.local_node.backup_path, "upgrade_backup")

        if not self.__pkg:
            raise Exception("Parameter --package is required!")

        if not os.path.exists(self.__pkg):
            raise Exception("Path %s does not exists!" % self.__pkg)
        if not os.path.isfile(self.__pkg) and not self.__is_run_package:
            raise Exception("Path %s is not a file!" % self.__pkg)
        if not os.path.isdir(self.__pkg) and self.__is_run_package:
            raise Exception("Path %s is not a path!" % self.__pkg)
        self.__pkg_info = self.__prepareNewPkg()
        self.__prepareDialectPkg()
        missing_flag = False
        new_pkg_files = ['admin/scripts/initdb.sql',
                         'admin/scripts/initview.sql',
                         'admin/scripts/initplsql.sql',
                         'admin/scripts/initwsr.sql']
        for f in new_pkg_files:
            if not self.__pkg_info.exists(f):
                missing_flag = True
                self.log("Missing file in new package : %s" % f, True)
        if missing_flag:
            raise Exception("Some file(s) missed.")

        self.__setAppProperPriv(self.__pkg_info.getPackagePath())

        self.__db_passwd_mount = ''
        if passwd_ui:
            self.__db_user = 'sys'
            self.__db_passwd = getpass.getpass("Please enter password for user[%s]:" % self.__db_user)
            if not self.__db_passwd:
                raise Exception("Password should not been empty!")
            self.__db_passwd = self.__db_passwd.replace("'", "'\"'\"'")
            self.__db_passwd_mount = getpass.getpass("Please enter password for user[%s][mount mode]:" % self.__db_user)
            if not self.__db_passwd_mount:
                raise Exception("Password should not been empty!")
            self.__db_passwd_mount = self.__db_passwd_mount.replace("'", "'\"'\"'")
            if self.__config:
                self.__config.user = self.__db_user
                self.__config.db_passwd = self.__db_passwd
                self.__config.db_passwd_mount = self.__db_passwd_mount
                self.__config.need_passwd = True
        else:
            self.__db_user = 'sysdba'
            self.__db_passwd = ''
            if self.__config:
                self.__config.need_passwd = False

    def log(self, msg, on_screen=False):
        '''
        log function
        msg -- msg should been logged
        on_screen -- output to screen if True
        '''

        login_info = ''

        if self.__login_user:
            login_info = '%s[USER:%s]' % (login_info, self.__login_user)
        if self.__login_ip:
            login_info = '%s[HOST:%s]' % (login_info, self.__login_ip)

        output = "%s%s %s" % (time.strftime("[%Y-%m-%d %H:%M:%S]"), login_info, str(msg))

        with open(self.__logfile, 'a') as fp:
            fp.write(output)
            fp.write('\n')

        if on_screen:
            print(msg)

    def __execShellCmd(self, cmd, stdin_ex=None):
        '''
        execute shell command
        cmd -- the command 
        '''

        execShellCmd(cmd, self.__envSetting, stdin_ex=stdin_ex)

    def __getOldVersion(self):
        '''
        get old database version from database server
        two old version:
        vrc: GaussDB-100-V3xxRxx1CxxSPCxxxBxxx
        dot: GaussDB_100_1.0.x.Bxx, GaussDB_100_1.0.xTx.Bxxx, GaussDB_100_1.0.x.SPCx.Bxxx
        '''

        if not os.path.isdir(self.__gsdb_home):
            raise Exception("Error: %s is not exists or not a directory." % self.__gsdb_home)
        # get old database version
        if os.path.exists(self.__gsdb_home+"/bin/zengine"):
            cmd = "zengine -v"
        else:
            cmd = self.UPGRADE_ZENGINE_NAME + " -v"
        status, output = execShellCmd(cmd,  self.__envSetting)
        if status:
            raise Exception("Error: Execute cmd '%s' failed. Output:%s." % (cmd, output))

        old_ver_obj = VersionInfo(version_str=output.strip(), logger=self.log)

        return old_ver_obj

    def __getNewVersion(self):
        '''
        get new database version from package.xml
        '''
        xml_file_path = os.path.join(self.__pkg_info.getPackagePath(), 'package.xml')
        new_ver_obj = VersionInfo(version_file=xml_file_path, logger=self.log)
        return new_ver_obj

    def __verifyVersion(self):
        """
        function: verify old new version, if not right, error exit
        input : version strings: eg V300R001C00SPCxxxBxxx
        output: NA
        """
        self.log("Check old and new upgrade version.")
        # get old version
        old_ver_obj = self.__getOldVersion()
        # get new version
        new_ver_obj = self.__getNewVersion()

        compare_result = new_ver_obj.compare_version(old_ver_obj, new_ver_obj)

        if compare_result == -1:
            # old is small, upgrade
            self.__is_degrade = False
        elif compare_result == 1:
            # old is big, degrade
            self.__is_degrade = True
        else:
            # the same, can not do upgrade or degrade
            raise Exception("Identical versions, nothing need to do. "
                            "Old version: %s, New version: %s" % (old_ver_obj.version, new_ver_obj.version))

        self.log("Old version: %s New version: %s." % (old_ver_obj.version, new_ver_obj.version), True)

    def __prepareNewPkg(self):
        '''
        copy new package file to backup path
        then unzip the file
        '''

        self.log("Prepare new package.")
        if not self.__pkg:
            raise Exception("New package unknown!")

        new_pkg = os.path.join(self.__backup, 'newpkg')
        if os.path.exists(new_pkg):
            cmd = 'chmod %s -R %s && rm -rf %s' % (self.DIRECTORY_MODE, new_pkg, new_pkg)
            self.__execShellCmd(cmd)

        if self.__is_run_package:
            cmd = 'mkdir -p -m %s %s && cp -r %s %s' % (self.DIRECTORY_PERMISSION, new_pkg, self.__pkg, new_pkg)
        else:
            cmd = 'mkdir -p -m %s %s && cp %s %s' % (self.DIRECTORY_PERMISSION, new_pkg, self.__pkg, new_pkg)

        self.__execShellCmd(cmd)

        # new_pkg_name /xxx/newpkg/*DATABASE*.tar.gz
        new_pkg_name = os.path.join(new_pkg, os.path.basename(self.__pkg))
        pkg_info = PackageInfo(new_pkg_name, run_pkg = self.__is_run_package)
        pkg_info.unzip()

        return pkg_info

    def __prepareDialectPkg(self):
        '''
        copy new dialect package file to backup path if exists
        then unzip the file
        '''
        new_ver_obj = self.__getNewVersion()

        if new_ver_obj.version_type == VersionInfo.VERSION_TYPE_DOT:
            # if it is GaussDB_100_x.0.x.Bxxx version
            # dialect package must be exists.
            compare_result = 1
        else:
            # VRC database, check dialect is required or not
            # new version >= dialect version, so new database need dialect package
            compare_result = new_ver_obj.compare_vrc_version(new_ver_obj.version, self.DIALECT_MIN_VERSION)

        new_pkg = os.path.join(self.__backup, 'newpkg')
        self.log('Version compare result: %s' % str(compare_result))

        # compare_result >=0, means upgrade or degrade need dialect package
        if compare_result >= 0:

            if self.__is_run_package:
                dialect_path = os.path.join(self.__pkg, "admin/scripts/sql_dialect/ora-dialect.sql")
                if not os.path.exists(dialect_path):
                    raise Exception("File %s does not exist." % dialect_path)
                return

            # it is not run package, check it is green package
            new_run_path = self.__pkg_info.getPackagePath()
            ora_dialect_sql = os.path.join(new_run_path, "admin/scripts/sql_dialect/ora-dialect.sql")
            if os.path.exists(ora_dialect_sql):
                # it is green package, not need get DIALECT*.tar.gz package
                self.__pkg_info.is_green_pkg = True
                self.log("%s file exists in %s." % (ora_dialect_sql, new_run_path))
                return

            pkg_path = os.path.dirname(self.__pkg)
            cmd = 'cd %s; find . -maxdepth 1 -name "*DIALECT*.tar.gz"' % pkg_path
            _, outputs = execShellCmdEx(cmd, '')
            target = outputs[0].strip()
            lines = target.split('\n')
            if len(lines) > 1:
                raise Exception("More than one target found in %s: %s\nPlease remove the unused files." % (pkg_path, ' ;'.join(lines)))
            absPath = os.path.join(pkg_path, target)
            if not os.path.isfile(absPath):
                raise Exception("Cannot find DIALECT in %s" % pkg_path)

            cmd = 'cp %s %s' % (absPath, new_pkg)
            self.__execShellCmd(cmd)
            self.__pkg_info.processDialect()

    def __shutdown(self, insts):
        '''
        shutdown a database instance
        '''

        inst_list = self.__db_instances

        if insts:
            inst_list = insts

        try:
            for inst in inst_list:
                self.log("Shutdown database '%s'." % inst.datadir())
                if self.__db_user == 'sysdba':
                    cmd = "sh %s/shutdowndb.sh -h 127.0.0.1 -p %s -w -D %s -m immediate >> %s 2>&1 " % (os.path.join(self.__gsdb_home,'bin'), inst.port(), inst.datadir(), self.__logfile)
                    self.__execShellCmd(cmd)
                else:
                    cmd = "sh %s/shutdowndb.sh -h 127.0.0.1 -p %s -W -D %s -m immediate -U %s >> %s 2>&1 " % (os.path.join(self.__gsdb_home,'bin'), inst.port(), inst.datadir(), self.__db_user, self.__logfile)
                    self.__execShellCmd(cmd, stdin_ex=self.__db_passwd)
        except Exception as _:
            raise Exception("Shutdown database failed. Please check %s and database log." % self.__logfile)

    def __getOneColFromView(self, inst, col_name, view_name, condition='', is_mount=False):
        '''
        get column values in a view
        col_name  --   the name of the column
        view_name --   the name of the view omit the prefix 'v$'
        condition --   where statement
        '''

        col_values = []

        views_dict = {
                      'DATABASE': ['V\$DATABASE', 'DV_DATABASE'],
                      'TABLESPACE': ['V\$TABLESPACE', 'DV_TABLESPACES'],
                      'DATAFILE': ['V\$DATAFILE', 'DV_DATA_FILES'],
                      'LOGFILE': ['V\$LOGFILE', 'DV_LOG_FILES'],
                      'INSTANCE': ['V\$INSTANCE', 'DV_INSTANCE'],
                      'SYS_TABLES': ['TABLE$', 'SYS_TABLES'],
                      'HA_SYNC_INFO': ['V\$HA_SYNC_INFO', 'DV_HA_SYNC_INFO']
                     }

        if view_name in views_dict:
            old_view_name = views_dict[view_name][0]
            new_view_name = views_dict[view_name][1]
        else:
            old_view_name = view_name
            new_view_name = view_name

        try:
            sql = "select %s from %s %s;" % (col_name, old_view_name, condition)
            _, output = self.__execSql(sql, inst, is_mount=is_mount)
        except Exception as ex:
            self.log("Select view %s error %s" % (view_name, str(ex)))
            try:
                sql = "select %s from %s %s;" % (col_name, new_view_name, condition)
                _, output = self.__execSql(sql, inst, is_mount=is_mount)
            except Exception as ex:
                raise Exception("Cannot get value from view %s\nError:%s" % (view_name, str(ex)))

        lines = output.split('\n')
        for line in lines:
            if line.find(col_name) >= 0:
                begin = lines.index(line) + 2
                break
        else:
            raise Exception("Can not get %s by sql:\n%s\nOn %s" % (col_name, sql, inst.datadir()))

        for i in range(begin, len(lines)):
            if lines[i].strip():
                col_values.append(lines[i].strip())
            else:
                break

        return col_values

    def __fetchSystemTableFiles(self, name='SYSTEM'):
        '''
        fetch all system table files
        '''
        self.log("Fetch system table files.")
        system_table_files = []

        for inst in self.__db_instances:

            self.log("Fetch %s system table." % inst.datadir())
            system_id = self.__getOneColFromView(inst, "ID", "TABLESPACE", "where NAME='%s'" % name)
            if system_id:
                system_id = system_id[0]
            else:
                self.log("%s %s id can not find." % (inst.datadir(), name))
                continue
            self.log("system_id:%s." % system_id)
            _files = self.__getOneColFromView(inst, "FILE_NAME", "DATAFILE", "where TABLESPACE_ID=%s AND STATUS='ONLINE'" % system_id)
            self.log("system_table files:%s." % str(_files))
            system_table_files.extend(_files)

            if _files and name == 'SYSTEM':
                if inst.datadir() not in self.__system_file_map.keys():
                    self.__system_file_map[inst.datadir()] = os.path.dirname(_files[0])

        self.log("All system table files:%s." % str(system_table_files))
        return system_table_files

    def __updatePath(self, source, target):
        '''
        update one path : from source to target
        '''

        cmd = ''
        if not os.path.exists(source):
            raise Exception("Unfound:%s" % source)

        if os.path.exists(target):
            cmd = 'chmod -R 0700 %s && rm -rf %s && ' % (target, target)

        cmd = '%s cp -r %s %s' % (cmd, source, target)
        self.__execShellCmd(cmd)

    def __testPathList(self, root, sub_list):
        '''
        test list : root + each sub_list
        '''

        missing = []
        for item in sub_list:
            source = os.path.join(root, item)
            if not os.path.exists(source):
                missing.append(source)
        return missing

    def __updatePathList(self, source_path, target_path, update_list, skip_missing=False):
        '''
        update in list : from source to target path which in update_list
        '''

        for item in update_list:

            source = os.path.join(source_path, item)
            target = os.path.join(target_path, item)

            try:
                self.__updatePath(source, target)
            except Exception as e:
                if not skip_missing:
                    raise
                else:
                    self.log("Update path missing:\n%s" % str(e))

    def __checkAttrOfDatabase(self, inst, attr_name, expect_value, is_mount=False):
        '''
        check if view database's attr equals expect_value
        '''

        attr = self.__getOneColFromView(inst, attr_name, 'DATABASE', is_mount=is_mount)[0]

        expected = expect_value

        if isinstance(expected, list):
            if attr not in expected:
                raise Exception("Database %s(%s) is not expected(%s)!" % (attr_name, attr, str(expected)))
        else:
            if attr != expected:
                raise Exception("Database %s(%s) is not expected(%s)!" % (attr_name, attr, str(expected)))

        time.sleep(1)

    def __startServiceIfDown(self, inst):
        '''
        start the service when it is down
        '''

        self.log("Check %s database process." % inst.datadir())
        cmd = "lsof -i:%s | grep -i zengine | grep `whoami` | grep LISTEN | awk '{print $2}'" % inst.port()

        p = subprocess.Popen(['bash', '-c', cmd], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        (stdoutdata, stderrdata) = p.communicate()
        status = p.returncode
        if gPyVersion[0] == "3":
            output = "%s%s" % (stdoutdata.decode(), stderrdata.decode())
        else:
            output = "%s%s" % (stdoutdata, stderrdata)
        if status != 0:
            raise Exception("Can not find database service process.")

        if not output.strip():
            self.log("Can not find %s process, start it." % inst.datadir())
            try:
                self.__startNormalByInst(inst)
            except Exception as e:
                raise Exception("Can not start %s service, %s" % (inst.datadir(), str(e)))

    def __checkExtraSql(self, old_path, new_path):
        '''
        check dialect sql for upgrade
        old (sql exists or not):{new (sql exists or not): result}
        'N': {'N': False},
        'N': {'Y': True}
        'Y': {'Y': do check}
        'Y': {'N': raise error}
        '''

        check_extra_files = ["admin/scripts/sql_dialect/ora-dialect.sql"]

        for extra_file in check_extra_files:
            old_sql_file = os.path.join(old_path, extra_file)
            new_sql_file = os.path.join(new_path, extra_file)
            is_old_exists = os.path.exists(old_sql_file)
            is_new_exists = os.path.exists(new_sql_file)

            if (not is_old_exists) and (not is_new_exists):
                # old sql not exists, new sql not exists
                return False
            elif (not is_old_exists) and is_new_exists:
                # old sql not exists, new sql exists
                return True
            elif is_old_exists and is_new_exists:
                # old sql exists, new sql exists, then check diff
                old_sha256 = calcSha256Sum(old_sql_file)
                new_sha256 = calcSha256Sum(new_sql_file)
                if old_sha256 != new_sha256:
                    return True
            else:
                raise Exception('Error: Old database %s exists, New Database does not exists.' % old_sql_file)
        # all old and new sql exists, but not changed
        return False

    def __checkSysauxExistingByInst(self, inst):

        try:
            sql = "SELECT * FROM ADM_TABLESPACES WHERE TABLESPACE_NAME='SYSAUX';"
            _, output = self.__execSql(sql, inst)
        except:
            try:
                sql = "SELECT * FROM DBA_TABLESPACES WHERE TABLESPACE_NAME='SYSAUX';"
                _, output = self.__execSql(sql, inst)
            except Exception as e:
                raise Exception("Cannot access table ADM_TABLESPACES\nError:%s" % str(e))

        if output.find("0 rows fetched") >= 0:
            return False


        result = self.__getOneColFromView(inst, "STATUS", "TABLESPACE", "where NAME='SYSAUX'")[0]
        if result == 'OFFLINE':
            raise Exception("Tablespace SYSAUX is offline!")

        return True

    def __checkSysauxExisting(self):

        existing = set()

        for i in self.__db_instances:
            is_exists = self.__checkSysauxExistingByInst(i)
            existing.add(is_exists)

        if len(existing) != 1:
            raise Exception("Some instances used SYSAUX and others do not!")

        if True in existing:
            self.__sysaux = True
        else:
            self.__sysaux = False

    def __checkPreUpgradeByInst(self, inst, is_primary_ro=True):
        '''
        pre upgrade check
        '''

        self.log("Check %s database condition." % inst.datadir())
        if self.__is_standalone:
            self.__checkAttrOfDatabase(inst, 'DATABASE_ROLE', 'PRIMARY')

        self.__checkAttrOfDatabase(inst, 'STATUS', 'OPEN')

        # set db role
        role = self.__getOneColFromView(inst, 'DATABASE_ROLE', 'DATABASE')[0]
        inst.setRole(role)

        if role == 'PRIMARY' and not is_primary_ro:
            self.__checkAttrOfDatabase(inst, 'OPEN_STATUS', 'READ WRITE')
        else:
            self.__checkAttrOfDatabase(inst, 'OPEN_STATUS', 'READ ONLY')

        self.__checkAttrOfDatabase(inst, 'DATABASE_CONDITION', 'NORMAL')

        # check system spaces size
        self.__checkSystemSpacesByInst(inst)

    def __checkSystemSpaces(self, tablespace='SYSTEM'):

        for i in self.__db_instances:
            self.__checkSystemSpacesByInst(i, tablespace)

    def __checkSystemSpacesByInst(self, inst, tablespace='SYSTEM'):
        '''
        check system table used size
        copyright change in 20190506
        old view name:new view name
        { DBA_TABLESPACES: ADM_TABLESPACES
          V$TABLESPACE : DV_TABLESPACES
          V$DATAFILE': DV_DATA_FILES
         }
        '''

        self.log("Check '%s' system table used size." % inst.datadir())
        try:
            # Get USED_SIZE from old table.
            sql = "SELECT USED_SIZE FROM DBA_TABLESPACES WHERE TABLESPACE_NAME = '%s';" % tablespace
            _, output = self.__execSql(sql, inst)
        except Exception as _:
            try:
                # Get USED_SIZE from new table.
                sql = "SELECT USED_SIZE FROM ADM_TABLESPACES WHERE TABLESPACE_NAME = '%s';" % tablespace
                _, output = self.__execSql(sql, inst)
            except Exception as e:
                raise Exception("Cannot get used_size\nError:%s" % str(e))

        # get used size
        lines = output.split('\n')
        for line in lines:
            if line.find('USED_SIZE') >= 0:
                begin = lines.index(line) + 2
                break
        else:
            raise Exception("Can not get %s by sql:\n%s\nOn %s" % ('system table used size', sql, inst.datadir()))

        used_size = float(lines[begin])

        # get total size
        try:
            select_sql = ("SELECT F.BYTES, F.AUTO_EXTEND, F.MAX_SIZE FROM V\$TABLESPACE AS T, "
                          "V\$DATAFILE AS F WHERE T.ID = F.TABLESPACE_ID AND T.NAME='%s';" % tablespace)
            _, output = self.__execSql(select_sql, inst)
        except Exception as _:
            try:
                select_sql = ("SELECT F.BYTES, F.AUTO_EXTEND, F.MAX_SIZE FROM DV_TABLESPACES AS T, "
                          "DV_DATA_FILES AS F WHERE T.ID = F.TABLESPACE_ID AND T.NAME='%s';" % tablespace)
                _, output = self.__execSql(select_sql, inst)
            except Exception as e:
                raise Exception("Failed to get total size\nError: %s" % str(e))

        records = output.split('\n')
        begin_index = 0
        end_index = 0
        for line in records:
            if line.find('--------') >= 0:
                begin_index = records.index(line) + 1
            if line.find('rows fetched') >= 0:
                end_index = records.index(line)
                break

        try:
            total_size = 0
            data_lists = records[begin_index:end_index]
            self.log("Total size info %s" % data_lists)
            for data in data_lists:
                if not data:
                    continue
                info = data.split()
                if info[1] == 'TRUE':
                    # AUTO_EXTEND = TRUE, use MAX_SIZE
                    total_size += float(info[2])
                else:
                    # AUTO_EXTEND = FALSE, use BYTES
                    total_size += float(info[0])
        except Exception as ex:
            self.log(str(ex))
            raise Exception("Can not get %s by sql:\n%s\nOn %s" % ('%s tablespace total size' % tablespace,
                                                                   select_sql, inst.datadir()))

        if not total_size:
            raise Exception("Error: Get system table total size failed. total size is:%s" % total_size)

        self.log("system table used size is %s." % used_size)
        self.log("system table total size is %s." % total_size)

        ratio = (total_size - used_size)/total_size
        if ratio < 0.20:
            raise Exception("Error: Insufficient %s tablespace. Total size: %s. Used size: %s" % ( tablespace,
                total_size, used_size))

    def __checkTools(self):
        '''
        check tools used by upgrade
        '''
        self.__execShellCmd("which lsof")

    def __checkPreUpgrade(self, primary_ro=True):
        '''
        pre upgrade check
        '''
        for i in self.__db_instances:
            self.__checkPreUpgradeByInst(i,primary_ro)

    def __checkDbProcess(self):
        """
        check db process, if down, start
        """
        for i in self.__db_instances:
            self.__startServiceIfDown(i)

    def __setAppProperPriv(self, app_path):
        '''
        call chmod for setting the required property
        '''

        self.log("Chmod application permission.")
        if os.path.exists(os.path.join(app_path, "add-ons")):
            self.__execShellCmd("chmod %s %s" % (self.DIRECTORY_PERMISSION, os.path.join(app_path, "add-ons")))
            self.__execShellCmd("chmod %s %s/*" % (self.MID_FILE_PERMISSION, os.path.join(app_path, "add-ons")))

        self.__execShellCmd("chmod %s %s" % (self.DIRECTORY_PERMISSION, os.path.join(app_path, "admin")))
        self.__execShellCmd("chmod %s %s" % (self.DIRECTORY_PERMISSION, os.path.join(app_path, "bin")))
        self.__execShellCmd("chmod %s %s/*" % (self.MID_FILE_PERMISSION, os.path.join(app_path, "bin")))
        if os.path.exists(os.path.join(app_path, "bin/script")):
            self.__execShellCmd("chmod %s %s" % (self.DIRECTORY_PERMISSION, os.path.join(app_path, "bin/script")))
        self.__execShellCmd("chmod %s %s" % (self.DIRECTORY_PERMISSION, os.path.join(app_path, "lib")))
        self.__execShellCmd("chmod %s %s/*" % (self.MID_FILE_PERMISSION, os.path.join(app_path, "lib")))
        self.__execShellCmd("chmod %s %s" % (self.DIRECTORY_PERMISSION, os.path.join(app_path, "admin/scripts")))
        self.__execShellCmd("chmod %s %s/*.sql" % (self.MIN_FILE_PERMISSION, os.path.join(app_path, "admin/scripts")))
        self.log("Successfully chmod application permission.")

    def __getSystemTableInfo(self):
        '''
        get system table info
        '''

        self.log("Get system table info")
        all_files_need_backup = []
        system_table_files = self.__fetchSystemTableFiles()
        undo_files = self.__fetchSystemTableFiles('UNDO')
        sysaux_table_files = self.__fetchSystemTableFiles('SYSAUX')
        all_files_need_backup.extend(system_table_files)
        all_files_need_backup.extend(undo_files)
        all_files_need_backup.extend(sysaux_table_files)

        for i in self.__db_instances:
            for f in i.ctl_files():
                all_files_need_backup.append(f.strip())
            redo_logs = self.__getOneColFromView(i, 'FILE_NAME', 'LOGFILE')
            for f in redo_logs:
                all_files_need_backup.append(f.strip())

        system_backup_path = os.path.join(self.__backup, 'system')
        if os.path.exists(system_backup_path):
            files = os.listdir(system_backup_path)
            if files:
                raise Exception("%s should been empty!" % system_backup_path)

        self.__execShellCmd("mkdir -p -m %s %s " % (
                                               self.DIRECTORY_PERMISSION,
                                               system_backup_path))

        backup_system_table = {}
        for f in all_files_need_backup:
            source = f
            target = os.path.join(system_backup_path, str(all_files_need_backup.index(f)))
            backup_system_table[source] = target

        system_backup_file = os.path.join(self.__backup, 'backup_system_table')
        with open(system_backup_file, 'wb') as fp:
            pickle.dump(backup_system_table, fp, 0)

        self.__execShellCmd("chmod %s %s" % (self.FILE_PERMISSION, system_backup_file))

    def __backupFiles(self):
        '''
        find system table file then backup
        find old initdb.sql and initview.sql then backup
        '''

        if os.path.exists(self.backup_flag_file):
            os.remove(self.backup_flag_file)

        backuped_system_table_info = os.path.join(self.__backup, 'backup_system_table')
        # systable upgrade must backup system table space, and skip it when binary upgrade
        if self.__systable_upgrade():
            if not os.path.exists(backuped_system_table_info):
                raise Exception("System table information missing, should do precheck before this step.")
 
            with open(backuped_system_table_info, 'rb') as fp:
                system_table_backup = pickle.load(fp)

            for s, t in list(system_table_backup.items()):
                cmd = "cp %s %s" % (s, t)
                self.__execShellCmd(cmd)

        cmd = 'cp %s %s' % (os.path.join(self.__gsdb_home, 'admin/scripts/initdb.sql'), self.__backup)
        cmd = '%s && cp %s %s' % (cmd, os.path.join(self.__gsdb_home, 'admin/scripts/initview.sql'), self.__backup)
        self.__execShellCmd(cmd)

        cmd = 'chmod %s %s' % (self.FILE_PERMISSION, os.path.join(self.__backup, "*.sql"))
        self.__execShellCmd(cmd)

        old_path = self.__gsdb_home
        back_path = os.path.join(self.__backup, 'bindir')
        
        if os.path.exists(back_path):
            files = os.listdir(back_path)
            if files:
                raise Exception("%s should been empty!" % back_path)

        cmd = 'mkdir -p -m %s %s' % (self.DIRECTORY_PERMISSION, back_path)
        self.__execShellCmd(cmd)

        self.__updatePathList(old_path, back_path, self.__update_list)
        self.__updatePathList(old_path, back_path, self.__update_list_ext, skip_missing=True)

        self.__setAppProperPriv(back_path)

        self.__execShellCmd('touch %s' % self.backup_flag_file)
        self.__execShellCmd("chmod %s %s" % (self.FILE_PERMISSION, self.backup_flag_file))

    def __cleanBackupFiles(self):
        '''
        clean all backuped files
        '''
        
        system_backup_path = os.path.join(self.__backup, 'system')
        if os.path.exists(system_backup_path):
            self.__execShellCmd("rm -rf %s" % system_backup_path)

        # clean replace_fin file
        replace_fin = os.path.join(os.path.dirname(self.__backup), 'replace_fin')
        if os.path.exists(replace_fin):
            self.__execShellCmd("rm -rf %s" % replace_fin)
        self.__execShellCmd("rm -rf %s/*.sql" % self.__backup)
        # clean backup old bin directory
        bin_dir = os.path.join(self.__backup, 'bindir')
        if os.path.exists(bin_dir):
            self.__execShellCmd("chmod -R %s %s && rm -rf %s" % (self.DIRECTORY_PERMISSION, bin_dir, bin_dir))
        # clean upgrade package
        pack_dir = os.path.join(self.__backup, 'newpkg')
        if os.path.exists(pack_dir):
            self.__execShellCmd("chmod -R %s %s && rm -rf %s" % (self.DIRECTORY_PERMISSION, pack_dir, pack_dir))
        self.__execShellCmd("rm -rf %s" % os.path.join(self.__backup, 'backup_db_info'))
        self.__execShellCmd("rm -rf %s" % os.path.join(self.__backup, 'backup_system_table'))
        self.__execShellCmd("rm -rf %s" % os.path.join(self.__backup, 'backup_fin'))
        self.__execShellCmd("rm -rf %s" % os.path.join(self.__backup, '01'))

        # clean the step file
        if os.path.exists(self.__upgrade_step_file):
            os.remove(self.__upgrade_step_file)

        # delete upgrade_backup directory, if it is empty
        file_info = os.listdir(self.__backup)
        if not file_info:
            self.__execShellCmd("chmod %s %s && rm -rf %s" % (self.DIRECTORY_PERMISSION, self.__backup, self.__backup))

    def __replace(self):
        '''
        replace package.xml bin lib admin
        '''

        if not self.__pkg:
            raise Exception("New package unknown!")

        old_path = self.__gsdb_home
        new_path = self.__pkg_info.getPackagePath()
        # rename zengine name
        self.__rename_bin(new_path)

        self.__updatePathList(new_path, old_path, self.__update_list)
        self.__updatePathList(new_path, old_path, self.__update_list_ext, skip_missing=True)

        cmd = 'chmod %s %s' % (self.MIN_FILE_MODE, os.path.join(old_path, 'package.xml'))
        self.__execShellCmd(cmd)

        # delete old zengine in gsdb_home
        old_bin = os.path.join(old_path, "bin", "zengine")
        if os.path.exists(old_bin):
            os.remove(old_bin)

        # in some system(such as euler2.0 SP8): logger depend the libuuid library,
        # but the lib provide by zenith is not match with the one provide by system,
        # so we choose the high version by remove the link of low version library
        self.__check_uuid_lib()

    def __rename_bin(self, new_path):
        '''
        rename zengine --> new_name
        '''
        old_zengine = os.path.join(new_path, "bin", "zengine")
        if os.path.exists(old_zengine):
            cmd = "chmod 700 %s/bin && cd %s/bin && rm -f %s" % (new_path, new_path, self.UPGRADE_ZENGINE_NAME)
            cmd += " && mv zengine %s" % self.UPGRADE_ZENGINE_NAME
            cmd += " && chmod %s %s" % (self.MID_FILE_MODE, self.UPGRADE_ZENGINE_NAME)
            self.__execShellCmd(cmd, '')

    def __get_uuid_version(self, uuid_lib):
        '''
        function: get real libuuid version, such as 1.0.0,
        input: uuid lib file or link
        output: the version of uuid library
        '''
        if os.path.islink(uuid_lib):
            uuid_lib_file = os.path.realpath(uuid_lib)
        else:
            uuid_lib_file = uuid_lib

        if uuid_lib_file.endswith('so') or uuid_lib_file.endswith('so.'):
            # libuuid.so or libuuid.so.
            lib_ver = ""
        else:
            # libuuid.so.x.y.z
            ver_idx = uuid_lib_file.rfind('so') + 3
            lib_ver = uuid_lib_file[ver_idx:]

        return lib_ver

    def __check_uuid_lib(self):
        '''
        function: check system libuuid version, if the version number
                  is great than that in zenith package, we use the system
                  libuuid avoid affecting system functions
        input: NA
        output: NA
        '''
        my_uuid_lib = os.path.join(self.__gsdb_home, "add-ons/libuuid.so.1")
        if not os.path.exists(my_uuid_lib):
            return
        my_uuid_lib_ver = self.__get_uuid_version(my_uuid_lib)

        lib_paths = ["/usr/lib", "/usr/lib64", "/lib", "/lib64"]
        for lib in lib_paths:
            sys_uuid_lib = os.path.join(lib, "libuuid.so.1")
            if not os.path.exists(sys_uuid_lib):
                continue
            sys_uuid_lib_ver = self.__get_uuid_version(sys_uuid_lib)
            if sys_uuid_lib_ver > my_uuid_lib_ver:
                os.remove(my_uuid_lib)
            break

    def __waitForService(self, inst, check_status='OPEN'):
        '''
        wait for database service normal
        '''

        maxTryTime = 300
        tryCount = 0
        interval_time = 3
        mount_mode = False

        if check_status == 'MOUNT' or check_status == 'NOMOUNT':
            mount_mode = True

        while True:

            try:
                attr = self.__getOneColFromView(inst, 'STATUS', 'INSTANCE', is_mount=mount_mode)[0]
                if attr != check_status:
                    raise Exception("STATUS(%s) is not expected(%s)!" % (attr, check_status))
                break

            except Exception as e:
                tryCount += 1
                self.log("Wait database service try time: %s\n%s" % (tryCount, str(e)))
                if tryCount * interval_time > maxTryTime:
                    if str(e).find('please specify -P parameter to input password') >= 0:
                        raise
                    raise Exception('Waiting database service exceed %s seconds' % maxTryTime)
                else:
                    time.sleep(interval_time)
        time.sleep(1)

    def __startNormalByInst(self, inst, zengine_name="zengine"):
        '''
        start database instance
        '''

        self.log("Start %s database normal." % inst.datadir())
        cmd = "nohup %s/%s -D %s >> %s 2>&1 &" % (os.path.join(self.__gsdb_home, 'bin'),
                                                  zengine_name,
                                                  inst.datadir(),
                                                  self.__logfile)

        cmd = "%s ; %s" % (self.__envSetting, cmd)
        status, _ = execShellCmd(cmd, '')
        if status != 0:
            raise Exception("Error:\n%s" % status)

        self.__waitForService(inst)

    def __startNomountByInst(self, inst, zengine_name="zengine"):
        '''
        start database instance
        '''

        self.log("Start %s database nomount." % inst.datadir())
        cmd = "nohup %s/%s nomount -D %s >> %s 2>&1 &" % (os.path.join(self.__gsdb_home, 'bin'),
                                                          zengine_name,
                                                          inst.datadir(),
                                                          self.__logfile)

        cmd = "%s ; %s" % (self.__envSetting, cmd)
        status, _ = execShellCmd(cmd, '')
        if status != 0:
            raise Exception("Error:\n%s" % status)

        self.__waitForService(inst, check_status='NOMOUNT')

    def __startReadonly(self, insts, zengine_name="zengine"):
        '''
        start database instance with readonly
        '''

        inst_list = self.__db_instances

        if insts:
            inst_list = insts

        for i in inst_list:
            self.log("Start database '%s' read only." % i.datadir())
            self.__startNomountByInst(i, zengine_name)
            self.__execSql("ALTER DATABASE OPEN READ ONLY", i)
            self.__waitForService(i)

    def __startNormal(self, insts, zengine_name="zengine"):
        '''
        start database instance
        '''

        inst_list = self.__db_instances

        if insts:
            inst_list = insts

        for i in inst_list:
            self.__startNormalByInst(i, zengine_name)

    def __startUpgradeByInst(self, inst, zengine_name="zengine"):
        '''
        start database instance with mount open upgrade mode
        '''

        self.log("Start database '%s' upgrade mode." % inst.datadir())
        cmd = "nohup %s/%s mount -D %s >> %s 2>&1 &" % (os.path.join(self.__gsdb_home, 'bin'),
                                                        zengine_name,
                                                        inst.datadir(),
                                                        self.__logfile)

        cmd = "%s ; %s" % (self.__envSetting, cmd)
        status, _ = execShellCmd(cmd, '')
        if status != 0:
            raise Exception("Error:\n%s" % status)

        self.__waitForService(inst, check_status='MOUNT')

        sql = "ALTER DATABASE OPEN UPGRADE;"
        try:
            self.__execSql(sql, inst, is_mount=True)
        except Exception as e:
            self.log(str(e))
            time.sleep(1)
            sql = "ALTER DATABASE OPEN RESTRICT;"
            self.__execSql(sql, inst, is_mount=True)
        
        time.sleep(1)

    def __startUpgrade(self, insts, zengine_name="zengine"):
        '''
        start database instance with mount open Upgrade mode
        '''

        inst_list = self.__db_instances

        if insts:
            inst_list = insts

        for i in inst_list:
            self.__startUpgradeByInst(i, zengine_name)

    def __checkDatabase(self):
        '''
        check if Upgrade mode
        '''
        for i in self.__db_instances:
            self.log("Check '%s' condition after start upgrade." % i.datadir())
            if self.__is_standalone:
                self.__checkAttrOfDatabase(i, 'DATABASE_ROLE', 'PRIMARY')

            self.__checkAttrOfDatabase(i, 'STATUS', 'OPEN')

            if i.role() == 'PRIMARY':
                self.__checkAttrOfDatabase(i, 'OPEN_STATUS', ['UPGRADE', 'RESTRICT'])
            else:
                self.__checkAttrOfDatabase(i, 'OPEN_STATUS', 'READ ONLY')

            self.__checkAttrOfDatabase(i, 'DATABASE_CONDITION', 'NORMAL')

    def __check_initdb_sql(self):
        '''
        check initdb.sql
        '''

        if self.__is_degrade:

            sql_processor = os.path.join(self.__gsdb_home, "bin/sql_process.py")
            new_sql = os.path.join(self.__gsdb_home, 'admin/scripts/initdb.sql')
            old_sql = os.path.join(self.__pkg_info.getPackagePath(), 'admin/scripts/initdb.sql')

        else:

            sql_processor = os.path.join(self.__pkg_info.getPackagePath(), "bin/sql_process.py")
            new_sql = os.path.join(self.__pkg_info.getPackagePath(), 'admin/scripts/initdb.sql')
            old_sql = os.path.join(self.__gsdb_home, 'admin/scripts/initdb.sql')

        cmd = "%s %s -t check-initdb --new-initdb=%s --old-initdb=%s" % ( PYBIN,
                                                                          sql_processor,
                                                                          new_sql,
                                                                          old_sql)

        path_env = "export PATH=%s:$PATH" % os.path.join(self.__gsdb_home, "bin")

        cmd = "%s && %s" % (path_env, cmd)

        self.__execShellCmd(cmd)

    def __check_white_list(self):
        '''
        check white list
        '''

        if self.__is_degrade:
            sql_processor = os.path.join(self.__gsdb_home, "bin/sql_process.py")
            upgrade_sql_path = os.path.join(self.__gsdb_home, "admin/scripts/upgrade")
        else:
            sql_processor = os.path.join(self.__pkg_info.getPackagePath(), "bin/sql_process.py")
            upgrade_sql_path = os.path.join(self.__pkg_info.getPackagePath(), "admin/scripts/upgrade")



        cmd = "%s %s -t check-whitelist --sqls-path=%s" % ( PYBIN,
                                                            sql_processor,
                                                            upgrade_sql_path)

        path_env = "export PATH=%s:$PATH" % os.path.join(self.__gsdb_home, "bin")

        cmd = "%s && %s" % (path_env, cmd)

        self.__execShellCmd(cmd)

    def __generateSql(self):
        '''
        generate upgrade.sql
        '''
        if self.__is_degrade:
            sql_processor = os.path.join(self.__gsdb_home, "bin/sql_process.py")
            upgrade_sql_path = os.path.join(self.__gsdb_home, "admin/scripts/upgrade")
        else:
            sql_processor = os.path.join(self.__pkg_info.getPackagePath(), "bin/sql_process.py")
            upgrade_sql_path = os.path.join(self.__pkg_info.getPackagePath(), "admin/scripts/upgrade")
        new_sql = os.path.join(self.__pkg_info.getPackagePath(), 'admin/scripts/initdb.sql')
        old_sql = os.path.join(self.__gsdb_home, 'admin/scripts/initdb.sql')

        cmd = "%s %s -t generate --new-initdb=%s --old-initdb=%s --outdir=%s --sqls-path=%s" % ( PYBIN,
                                                                                  sql_processor,
                                                                                  new_sql,
                                                                                  old_sql,
                                                                                  self.__backup,
                                                                                  upgrade_sql_path)

        if self.__is_degrade:
            cmd += " --degrade"

        path_env = "export PATH=%s:$PATH" % os.path.join(self.__gsdb_home, "bin")

        cmd = "%s && %s" % (path_env, cmd)

        drop_views_cmds = []

        view_files = self.__view_files
        dialect_files = self.__dialect_files

        for view_f in view_files.keys():
            new_view = os.path.join(self.__pkg_info.getPackagePath(), view_f)
            old_view = os.path.join(self.__gsdb_home, view_f)
            drop_views_cmds.append("%s %s -t gen-view --new=%s --old=%s --outfile=%s" % (PYBIN, 
                                                                                         sql_processor,
                                                                                         new_view, 
                                                                                         old_view, 
                                                                                         os.path.join(self.__backup, view_files[view_f])))

        for dial in dialect_files.keys():
            new_dial = os.path.join(self.__pkg_info.getPackagePath(), dial)
            old_dial = os.path.join(self.__gsdb_home, dial)
            if os.path.exists(new_dial) or os.path.exists(old_dial):
                gen_cmd = "%s %s -t gen-view --outfile=%s" % (PYBIN, sql_processor, os.path.join(self.__backup, dialect_files[dial]))
                if os.path.exists(new_dial):
                    gen_cmd += " --new=%s" % new_dial
                if os.path.exists(old_dial):
                    gen_cmd += " --old=%s" % old_dial
                drop_views_cmds.append(gen_cmd)

        for drop_cmd in drop_views_cmds:
            cmd = cmd + " && " + drop_cmd

        self.__execShellCmd(cmd)

    def __generateDictionarySql(self):
        '''
        generate dictionary upgrade.sql 
        '''
        sql_processor = os.path.join(self.__backup, "bindir/bin/sql_process.py")
        initdb_sql_file = os.path.join(self.__gsdb_home, 'admin/scripts/initdb.sql')

        cmd = "%s %s -t gen-dict --initdb=%s --outdir=%s" % ( PYBIN,
                                                              sql_processor,
                                                              initdb_sql_file,
                                                              self.__backup)

        path_env = "export PATH=%s:$PATH" % os.path.join(self.__gsdb_home, "bin")

        cmd = "%s ; %s" % (path_env, cmd)

        self.__execShellCmd(cmd)

    def __execSqlFile(self, sql_file, inst):
        '''
        execute a sql file
        '''

        inst.execSqlFile(sql_file, self.__envSetting, self.__db_user, self.__db_passwd)

    def __execSql(self, sql, inst, time_out=0, is_mount=False):
        '''
        execute a sql command
        '''

        passwd = self.__db_passwd
        if is_mount:
            passwd = self.__db_passwd_mount
        return inst.execSql(sql, self.__envSetting, self.__db_user, passwd, time_out)

    def __execUpgradeSqlByInst(self, inst, phase=0):
        '''
        execute upgrade sql file
        '''

        self.log("Execute upgrade sql for '%s'." % inst.datadir())
        upgrade_sql = os.path.join(self.__backup, 'upgradeFile.sql')
        rename_sql = os.path.join(self.__backup, 'upgradeRename.sql')

        initview_sql = os.path.join(self.__gsdb_home, "admin/scripts/initview.sql")
        initplsql_sql = os.path.join(self.__gsdb_home, "admin/scripts/initplsql.sql")
        initwsr_sql = os.path.join(self.__gsdb_home, "admin/scripts/initwsr.sql")
        ora_dialect_sql = os.path.join(self.__gsdb_home, "admin/scripts/sql_dialect/ora-dialect.sql")

        # get list [[file path or string, flag]], flag is file or string
        init_sql_infos0 = [[upgrade_sql, "file"]]
        init_sql_infos1 = [[upgrade_sql, "file"]]
        init_sql_infos2 = [[upgrade_sql, "file"]]

        all_drop_files = list(self.__view_files.values()) + list(self.__dialect_files.values())
        for f in all_drop_files:
            drop_file = os.path.join(self.__backup, f+'_jobs')
            if os.path.exists(drop_file):
                init_sql_infos1.append([drop_file, "file"])

        for f in all_drop_files:
            drop_file = os.path.join(self.__backup, f)
            if os.path.exists(drop_file):
                init_sql_infos0.append([drop_file, "file"])
                init_sql_infos1.append([drop_file, "file"])

        if os.path.exists(rename_sql):
            init_sql_infos0.append([rename_sql, "file"])
            init_sql_infos1.append([rename_sql, "file"])

        init_sql_infos0.extend([[initview_sql, "file"],
                                [initplsql_sql, "file"],
                                [initwsr_sql, "file"]])

        init_sql_infos2.extend([[initview_sql, "file"],
                                [initplsql_sql, "file"],
                                [initwsr_sql, "file"]])

        if os.path.exists(ora_dialect_sql):
            self.log("The ora-dialect.sql file exists, execute for upgrade.")
            init_sql_infos0.append([ora_dialect_sql, "file"])
            init_sql_infos2.append([ora_dialect_sql, "file"])

        info_list = [init_sql_infos0, init_sql_infos1, init_sql_infos2]

        if not isinstance(phase, int):
            raise Exception("Unexpected type: %s" % type(phase))

        if phase < 0 or phase > 2:
            raise Exception("Unexpected phase value: %s" % str(phase))

        init_sql_infos = info_list[phase]

        create_sysaux_flag = False
        adjust_sysaux_flag = False

        if phase==0:
            if self.__sysaux:
                adjust_sysaux_flag = True
            else:
                create_sysaux_flag = True

        path_of_system = self.__system_file_map[inst.datadir()]
        path_of_sysaux = path_of_system + '/sysaux'

        create_sysaux_sql = "\nCREATE TABLESPACE SYSAUX DATAFILE '%s' SIZE 512M AUTOEXTEND ON NEXT 32M\n/\n\nALTER TABLESPACE SYSAUX AUTOPURGE OFF\n/\n\n" % path_of_sysaux

        adjust_sysaux_sql = "ALTER TABLESPACE SYSAUX AUTOEXTEND ON NEXT 32M\n/\n\n"
        adjust_sysaux_sql += "ALTER TABLESPACE SYSAUX AUTOPURGE OFF\n/\n\n"

        upgrade_tmp_sql = os.path.join(self.__backup, 'upgrade_tmp_file.sql')
        try:
            with open(upgrade_tmp_sql, "w") as fp_w:

                if create_sysaux_flag:
                    fp_w.write(create_sysaux_sql)
                    self.__rollback_clean_files.append(path_of_sysaux)

                if adjust_sysaux_flag:
                    fp_w.write(adjust_sysaux_sql)

                for sql_info in init_sql_infos:
                    # read one sql info
                    if sql_info[1] == "file":
                        with open(sql_info[0], "r") as fp_r:
                            infos = fp_r.readlines()
                    else:
                        infos = sql_info[0:1]

                    fp_w.write("-- %s sql info" % sql_info[0])
                    # write warp
                    fp_w.write(os.linesep)
                    fp_w.write(os.linesep)
                    self.log("Write sql info %s" % sql_info[0])
                    # write one sql info
                    for info in infos:
                        fp_w.write(info)

                    # write sql info end, write wrap
                    fp_w.write(os.linesep)

                    self.log("Successfully write sql info %s." % sql_info[0])

        except Exception as e:
            raise Exception(str(e))
        
        if create_sysaux_flag:
            self.__rollback_clean_tablespace.append(inst)
        self.__saveDbInfo()
        self.__execSqlFile(upgrade_tmp_sql, inst)
        time.sleep(1)

        if os.path.exists(upgrade_tmp_sql):
            os.remove(upgrade_tmp_sql)

    def __execUpgradeSql(self, phase_num=0):
        '''
        execute upgrade sql file
        '''

        for i in self.__db_instances:
            if i.role() == 'PRIMARY':
                self.__execUpgradeSqlByInst(i, phase=phase_num)

    def __checkUpgradeByInst(self, inst):
        '''
        check upgrade
        '''
        self.log("check upgrade for database '%s'." % inst.datadir())
        objects_tb = "ALL_OBJECTS"
        try:
            self.__execSql("select COUNT(1) from ALL_OBJECTS", inst)
        except Exception as _:
            try:
                self.__execSql("select COUNT(1) from DB_OBJECTS", inst)
            except Exception as e:
                raise Exception("Can't find view name about all objects."
                                "\nError: %s" % str(e))
            objects_tb = "DB_OBJECTS"

        sqls = r"""exec DBMS_UTILITY.compile_schema('sys', false);
select * from %s where OWNER = 'SYS' AND OBJECT_TYPE = 'TABLE' and STATUS != 'VALID';
select * from %s where OWNER = 'SYS' AND OBJECT_TYPE = 'VIEW' and STATUS != 'VALID';
select * from %s where OWNER = 'SYS' AND OBJECT_TYPE = 'INDEX' and STATUS != 'VALID';
select * from %s where OWNER = 'SYS' AND OBJECT_TYPE = 'SEQUENCE' and STATUS != 'VALID';
select * from %s where OWNER = 'SYS' AND OBJECT_TYPE = 'SYNONYM' and STATUS != 'VALID';
""" % (objects_tb, objects_tb, objects_tb, objects_tb, objects_tb)

        _, output = self.__execSql(sqls, inst)

        if output.count('0 rows fetched') != 5:
            self.log("check upgrade sql: %s" % sqls)
            raise Exception("Check upgrade failed! Output:\n%s" % str(output))

        time.sleep(1)

    def __checkUpgrade(self, insts):
        '''
        check upgrade
        '''
        inst_list = self.__db_instances

        if insts:
            inst_list = insts

        for i in inst_list:
            self.__checkUpgradeByInst(i)

    def __cancelUpgrade(self, insts):
        '''
        execute cancel upgrade
        '''

        self.__shutdown(insts)
        self.__startNormal(insts)

    def __promptRollback(self):
        '''
        upgrade failed, auto rollback
        '''

        if os.path.exists(self.backup_flag_file):
            self.log("Upgrade Failed: ", True)
            self.log("Hint: Please do rollback when upgrade failed.", True)
            self.log("Hint: Do rollback, please refer to python upgrade.py --help.", True)
            sys.exit(1)

    def __checkRollback(self):
        '''
        upgrade failed, check if need rollback when upgrade retry
        '''
        self.__promptRollback()

    def doRollbackCheck(self):
        '''
        do rollback check
        when -t upgrade, do execute_upgrade_sql, wait_sync,
        primary_ckpt, standby_ckpt failed
        need check LFN
        '''

        self.__checkRollbackStep()
        self.log("Do rollback check.", True)

        self.log("Rollback check succeed.", True)

        # flush step info
        self.__flushRollbackStep("rollback-check:check_lfn")

        self.log("Done.", True)

    def doRollback(self):
        '''
        rollback main process
        '''

        self.__checkRollbackStep()

        self.log("Do rollback.", True)
        if not os.path.exists(self.backup_flag_file):
            self.log("Shutdown zenith server.", True)
            self.__shutdown([])
            self.__flushRollbackStep("rollback:replace")
            self.log("Done.", True)
            return

        try:
            # load dbinfo, check systable upgrade or binary upgrade
            self.__loadDbInfo()
            self.log("Shutdown zenith server.", True)
            self.__shutdown([])

            self.log("Restore zenith files.", True)
            target_path = self.__gsdb_home
            source_path = os.path.join(self.__backup, 'bindir')

            self.__rename_bin(source_path)

            miss_items = self.__testPathList(source_path, self.__update_list)
            if miss_items:
                raise Exception("Missing:%s\n" % '\n'.join(miss_items))

            self.__updatePathList(source_path, target_path, self.__update_list)
            self.__updatePathList(source_path, target_path, self.__update_list_ext, skip_missing=True)

            pkg_xml = os.path.join(target_path, "package.xml")
            if os.path.exists(pkg_xml):
                cmd = 'chmod %s %s' % (self.MIN_FILE_MODE, pkg_xml)
                self.__execShellCmd(cmd)

            if self.__systable_upgrade():
                backup_system_table = os.path.join(self.__backup, 'backup_system_table')
                # system table backup files must be exist for systable upgrade 
                if not os.path.exists(backup_system_table):
                    raise Exception("Can not find system tablespace backup files for systable upgrade.")

                self.log("Restore zenith system table.", True)
                system_table_backup = None

                with open(backup_system_table, 'rb') as fp:
                    system_table_backup = pickle.load(fp)

                for s, t in list(system_table_backup.items()):
                    cmd = "cp %s %s" % (t, s)
                    self.__execShellCmd(cmd)

            self.__flushRollbackStep("rollback:replace")

        except Exception as ex:
            self.log(str(ex), True)
            raise Exception("Rollback failed.")

        self.log("Rollback successfully.", True)
        self.log("Done.", True)

    def doRollbackClean(self):
        '''
        rollback clean
        '''

        self.__checkRollbackStep()

        db_info_backup_file = os.path.join(self.__backup, 'backup_db_info')
        if os.path.exists(db_info_backup_file):
            self.__loadDbInfo()

        self.log("Do rollback clean.", True)
        # rename new name ---> zengine
        new_name = "%s/bin/%s" % (self.__gsdb_home, self.UPGRADE_ZENGINE_NAME)
        self.log("Revert install info.")
        if os.path.exists(new_name):
            cmd = "cd %s/bin && rm -f zengine && mv %s zengine" % (self.__gsdb_home, new_name)
            self.__execShellCmd(cmd, self.__envSetting)

        self.log("Start database", True)
        self.__startNormal([])

        for inst in self.__rollback_clean_tablespace:
            try:
                self.__execSql("DROP TABLESPACE SYSAUX INCLUDING CONTENTS AND DATAFILES;", inst)
            except Exception as e:
                self.log(str(e))
                if str(e).find("GS-00780") >= 0:
                    pass
                else:
                    raise

        for f in self.__rollback_clean_files:
            try:
                self.__execShellCmd("rm -rf %s" % f)
            except Exception as e:
                self.log(str(e))

        self.log("Clean backup files.", True)
        self.__cleanBackupFiles()

        self.log("Rollback clean successfully.", True)
        self.log("Done.", True)

    def __checkLocalLrpRcyPoint(self):
        '''
        check RCY and LRP of all database instances
        '''

        for inst in self.__db_instances:
            rcy_point = self.__getOneColFromView(inst, 'RCY_POINT', 'DATABASE')[0]
            time.sleep(1)
            lrp_point = self.__getOneColFromView(inst, 'LRP_POINT', 'DATABASE')[0]
            time.sleep(1)
            self.log("[%s] RCY_POINT:%s LRP_POINT:%s" % (inst.datadir(), rcy_point, lrp_point))
            if rcy_point != lrp_point:
                raise Exception("Database %s RCY and LRP point is not equal:[%s, %s]" % (inst.datadir(), rcy_point, lrp_point))

    def __printLrpRcyPoint(self):
        '''
        print RCY and LRP of all database instances
        '''

        for inst in self.__db_instances:
            rcy_point = self.__getOneColFromView(inst, 'RCY_POINT', 'DATABASE')[0]
            time.sleep(1)
            lrp_point = self.__getOneColFromView(inst, 'LRP_POINT', 'DATABASE')[0]
            time.sleep(1)
            self.log("[%s] RCY_POINT:%s LRP_POINT:%s" % (inst.datadir(), rcy_point, lrp_point), True)

    def __checkpointOnAll(self, insts):
        '''
        execute checkpoints sql on all instances
        '''

        inst_list = self.__db_instances
        if insts:
            inst_list = insts

        sql = "ALTER SYSTEM CHECKPOINT;"
        max_seconds = 600

        for inst in inst_list:
            self.log("Checkpoint on '%s'." % inst.datadir())
            try:
                begin = time.time()
                self.__execSql(sql, inst, time_out=max_seconds)
                self.log("Checkpoint took %s seconds." % str(time.time()-begin), True)
            except Exception as e:
                if 'Timeout' in str(e):
                    raise Exception('CHECK step has exceeded %s seconds, please make sure the '
                                    'product services have been stopped and try again.' % str(max_seconds))
                else:
                    raise

        time.sleep(1)

    def __saveDbInfo(self):
        '''
        only call this in precheck function
        save database server's information
            role info
        save version 
        '''

        all_info = {}
        db_info = {}
        for inst in self.__db_instances:
            if not inst.role():
                raise Exception("Unknown role of %s" % inst.datadir())
            db_info[inst.datadir()] = inst.role()

        all_info['db_info'] = db_info
        all_info['degrade'] = self.__is_degrade
        all_info['lfn_infos'] = self.__lfn_infos
        all_info['upgrade_type'] = self.__upgrade_type
        all_info['sysaux'] = self.__sysaux
        all_info['system_file_map'] = self.__system_file_map
        all_info['rollback_clean'] = self.__rollback_clean_tablespace
        all_info['rollback_clean_files'] = self.__rollback_clean_files

        db_info_backup_file = os.path.join(self.__backup, 'backup_db_info')
        with open(db_info_backup_file, 'wb') as fp:
            pickle.dump(all_info, fp, 0)

        self.__execShellCmd("chmod %s %s" % (self.FILE_PERMISSION, db_info_backup_file))

    def __loadDbInfo(self):
        '''
        load database server's information
        role info
        '''

        with open(os.path.join(self.__backup, 'backup_db_info'), 'rb') as fp:
            all_info = pickle.load(fp)

        db_info = all_info['db_info']
        for inst in self.__db_instances:
            inst.setRole(db_info[inst.datadir()])

        self.__is_degrade = all_info['degrade']
        self.__lfn_infos = all_info['lfn_infos']
        self.__upgrade_type = all_info['upgrade_type']
        self.__sysaux = all_info['sysaux'] 
        self.__system_file_map = all_info['system_file_map'] 
        self.__rollback_clean_tablespace = all_info['rollback_clean']
        self.__rollback_clean_files = all_info['rollback_clean_files']

    def __saveStepInfo(self, step_info):
        '''
        save step info in file
        '''
        self.log("Save step info %s." % step_info)
        with open(self.__upgrade_step_file, 'wb') as fp:
            pickle.dump(step_info, fp, 0)

        self.__execShellCmd("chmod %s %s" % (self.FILE_PERMISSION, self.__upgrade_step_file))

    def __loadStepInfo(self):
        '''
        check if do rollback check lfn
        '''
        step_info = [":", ":"]
        if os.path.exists(self.__upgrade_step_file):
            # get upgrade step info
            with open(self.__upgrade_step_file, 'rb') as fp:
                step_info = pickle.load(fp)

        self.log("Load step info %s." % step_info)

        return step_info

    def __flushUpgradeStep(self, upgrade_step):
        '''
        flush upgrade step info
        '''
        self.__saveStepInfo([upgrade_step, ":"])

    def __flushRollbackStep(self, rollback_step):
        '''
        flush rollback step info
        '''

        # get upgrade step info
        step_info = self.__loadStepInfo()
        # index 0 is upgrade step
        self.__saveStepInfo([step_info[0], rollback_step])

    def __checkUpgradeStep(self):
        '''
        check -t action is ok or not
        '''
        if self.__systable_upgrade():
            upgrade_step = {
                "precheck": {
                    "check1": {
                        "precheck": True,
                        "prepare": True
                    }
                },
                "prepare": {
                    "shutdown": {"replace": True}
                },
                "replace": {
                    "update": {"start": True}
                },
                "start": {
                    "start": {"upgrade": True}
                },
                "upgrade": {
                    "check2": {},
                    "exec_upgrade_sql": {},
                    "check_lfn": {},
                    "primary_ckpt": {"sync": True}
                },
                "sync": {
                    "standby_ckpt": {"dbcheck": True},
                    "standby_ckpt1": {"restart": True}
                },
                "restart": {
                    "restart": {"upgrade-view": True}
                },
                "upgrade-view": {
                    "before_exec_sql": {},
                    "upgrade-view": {"checkpoint": True}
                },
                "checkpoint": {
                    "checkpoint": {"dbcheck": True}
                },
                "dbcheck": {
                    "load_db_info": {},
                    "shutdown": {"flush": True}
                }
            }
        else:
            upgrade_step = {
                "precheck": {
                    "check1": {
                        "precheck": True,
                        "prepare": True
                    }
                },
                "prepare": {
                    "shutdown": {"replace": True}
                },
                "replace": {
                    "update": {"dbcheck": True}
                },
                "dbcheck": {
                    "load_db_info": {},
                    "shutdown": {"flush": True}
                }
            }
            
        # upgrade_step_info file content, eg: ["upgrade:check2", ""]
        # upgrade:check2, normal step info
        # rollback-check:True, has do rollback-check; False, not do.
        step_info = self.__loadStepInfo()
        # get upgrade step info
        upgrade_step_info = step_info[0].split(":")
        step_key = upgrade_step_info[0]
        step_value = upgrade_step_info[1]
        is_allow_action = False
        if step_key and step_value:
            is_allow_action = upgrade_step[step_key][step_value].get(self.__action, False)
        elif self.__action == "precheck":
            # step file not exists, action is precheck, allow
            is_allow_action = True

        if not is_allow_action:
            raise Exception("Error: Can not do [%s] now, please check your step." % self.__action)

    def __checkRollbackStep(self):
        '''
        check rollback step
        '''
        rollback_step = {
            "rollback-check": {
                "check_lfn": {"rollback": True, "rollback-check": True}
                
            },
            "rollback": {
                "replace": {"rollback-clean": True}
            }
        }

        step_info = self.__loadStepInfo()
        # get rollback step info
        rollback_step_info = step_info[1].split(":")
        step_key = rollback_step_info[0]
        step_value = rollback_step_info[1]
        is_allow_action = False
        if step_key and step_value:
            is_allow_action = rollback_step[step_key][step_value].get(self.__action, False)

        elif self.__action == "rollback-check":
            # step file not exists, action is precheck, allow
            is_allow_action = True

        if not is_allow_action:
            raise Exception("Error: Can not do [%s] now, please check your step." % self.__action)


    def single_cleanup(self):
        '''
        clean backup path and tmp file
        '''
        print("clean backup and tmp files.")
        cmd = "rm -rf %s;" % self.__config.ha_upgrade_step_file
        cmd = "%schmod %s %s -R; rm -rf %s" % (cmd, self.DIRECTORY_PERMISSION, self.__config.local_node.backup_path, self.__config.local_node.backup_path)
        try:
            exec_popen(cmd)
        except (UpgradeException, KeyboardInterrupt) as err:
            raise err

    def single_run(self):
        '''
        run step for single upgrade
        '''
        self.__config.check_step(STEP_RUN)
        self.__verifyVersion()
        self.__set_upgrade_type()
        if self.__systable_upgrade():
            self.__single_run_systable()
        else:
            self.__single_run_binary()
        self.__config.update_upgrade_step(STEP_RUN, "None", STEP_SUCCESS)

    def __single_run_binary(self):
        '''
        single run for binary upgrade
        '''
        try:
            self.log("Begin to run step for single upgrade.")
            self.log("Precheck step for single upgrade.", True)
            self.__single_run_precheck(self.__config.need_passwd)
            self.log("Prepare step for single upgrade.", True)
            self.__single_run_prepare(self.__config.need_passwd)
            self.log("Replace step for single upgrade.", True)
            self.__single_run_replace()            
            self.log("Dbcheck step for single upgrade.", True)
            self.__single_run_dbcheck(self.__config.need_passwd)
            self.log("Flush step for single upgrade.", True)
            self.__single_run_flush(self.__config.need_passwd)
            self.log("Run for single upgrade finished.", True)
        except (UpgradeException, KeyboardInterrupt) as err:
            self.__process_run_exception(err)

    def __single_run_systable(self):
        '''
        single run for systable upgrade 
        '''
        try:
            self.log("Begin to run step for single upgrade.")
            self.log("Precheck step for single upgrade.", True)
            self.__single_run_precheck(self.__config.need_passwd)
            self.log("Prepare step for single upgrade.", True)
            self.__single_run_prepare(self.__config.need_passwd)
            self.log("Replace step for single upgrade.", True)
            self.__single_run_replace()            
            self.log("Start step for single upgrade.", True)
            self.__single_run_start(self.__config.need_passwd)
            self.log("Upgrade step for single upgrade.", True)
            self.__single_run_upgrade(self.__config.need_passwd)
            self.log("Sync step for single upgrade.", True)
            self.__single_run_sync(self.__config.need_passwd)
            if self.__is_degrade:
                self.log("Restart step for single upgrade.", True)
                self.__single_run_restart(self.__config.need_passwd)
                self.log("Upgrade-view step for single upgrade.", True)
                self.__single_run_upgrade_view(self.__config.need_passwd)
                self.log("Checkpoint step for single upgrade.", True)
                self.__single_run_checkpoint(self.__config.need_passwd)
            self.log("Dbcheck step for single upgrade.", True)
            self.__single_run_dbcheck(self.__config.need_passwd)
            self.log("Flush step for single upgrade.", True)
            self.__single_run_flush(self.__config.need_passwd)
            self.log("Run for single upgrade finished.", True)
        except (UpgradeException, KeyboardInterrupt) as err:
            self.__process_run_exception(err)

    def __ha_execute_command(self, cmds, interactive=False):
        '''
        execute command for ha upgrade
        '''
        if interactive:
            ret_code, _, failed = self.__config.cmd_tool.expect_execute(cmds)
            self.__delete_passwd(cmds)
        else:
            ret_code, _, failed = self.__config.cmd_tool.execute_in_node(cmds)
        if ret_code:
            raise UpgradeException("Execute command Failed:\ncommand: %s\nresult: %s" %(cmds, str(failed)))


    def __delete_passwd(self, cmds):
        '''
        reset empty list for password
        '''
        for cmd in cmds:
            if len(cmd) == 3:
                cmd[2] = []

    def __single_execute_command(self, cmd, interactive=False):
        '''
        execute command for single upgrade
        '''
        ret_code, _, failed = self.__config.cmd_tool.expect_execute(cmd)
        if interactive:
            self.__delete_passwd(cmd)
        if ret_code:
            raise UpgradeException("Execute command Failed:\ncommand: %s\nresult: %s" % (cmd, str(failed)))


    def __single_run_precheck(self, interactive=False):
        '''
        precheck step for single upgrade
        '''
        cmd = self.__single_generate_uprade_cmd('precheck', interactive)
        self.__single_execute_command(cmd, interactive)

    def __single_run_prepare(self, interactive=False):
        '''
        prepare step for single upgrade
        '''
        cmd = self.__single_generate_uprade_cmd('prepare', interactive)
        self.__single_execute_command(cmd, interactive)

    def __single_run_replace(self):
        '''
        prepare step for single upgrade
        '''
        cmd = self.__single_generate_uprade_cmd('replace', False)
        self.__single_execute_command(cmd, False)
        # replace action will create replace_fin file when the action is completed.
        # so we must remove it 
        fin_file = "%s/replace_fin" % self.__config.local_node.backup_path
        cmd = "if [ -f %s ]; then rm -rf %s; fi" % (fin_file, fin_file)
        exec_popen(cmd)

    def __single_run_start(self, interactive=False):
        '''
        prepare step for single upgrade
        '''
        cmd = self.__single_generate_uprade_cmd('start', interactive)
        self.__single_execute_command(cmd, interactive)

    def __single_run_upgrade(self, interactive=False):
        '''
        upgrade step for single upgrade
        '''
        cmd = self.__single_generate_uprade_cmd('upgrade', interactive)
        self.__single_execute_command(cmd, interactive)

    def __single_run_dbcheck(self, interactive=False):
        '''
        dbcheck step for single upgrade
        '''
        cmd = self.__single_generate_uprade_cmd('dbcheck', interactive)
        self.__single_execute_command(cmd, interactive)

    def __single_run_flush(self, interactive=False):
        '''
        dbcheck step for single upgrade
        '''
        cmd = self.__single_generate_uprade_cmd('flush', interactive)
        self.__single_execute_command(cmd, interactive)

    def __single_run_sync(self, interactive=False):
        '''
        sync step for single upgrade
        '''
        cmd = self.__single_generate_uprade_cmd('sync', interactive)
        self.__single_execute_command(cmd, interactive)

    def __single_run_restart(self, interactive=False):
        '''
        restart step for single upgrade
        '''
        cmd = self.__single_generate_uprade_cmd('restart', interactive)
        self.__single_execute_command(cmd, interactive)

    def __single_run_upgrade_view(self, interactive=False):
        '''
        upgrade-view step for single upgrade
        '''
        cmd = self.__single_generate_uprade_cmd('upgrade-view', interactive)
        self.__single_execute_command(cmd, interactive)

    def __single_run_checkpoint(self, interactive=False):
        '''
        checkpoint step for single upgrade
        '''
        cmd = self.__single_generate_uprade_cmd('checkpoint', interactive)
        self.__single_execute_command(cmd, interactive)

    def single_rollback(self):
        '''
        rollback step for single upgrade
        '''
        self.__config.check_step(STEP_ROLLBACK)
        try:
            self.log("Rollback for single upgrade.", True)
            cmd = self.__single_generate_uprade_cmd('rollback', 
                                                    self.__config.need_passwd)
            self.__single_execute_command(cmd, self.__config.need_passwd)
            self.log("Rollback-clean for single upgrade.", True)
            cmd = self.__single_generate_uprade_cmd('rollback-clean', 
                                                    self.__config.need_passwd)
            self.__single_execute_command(cmd, self.__config.need_passwd)
            self.__config.update_upgrade_step(STEP_ROLLBACK, "None", STEP_SUCCESS)
            self.log("Rollback finished.", True)
        except (UpgradeException, KeyboardInterrupt) as err:
            self.__config.update_upgrade_step(STEP_ROLLBACK, "None", STEP_FAILED)
            raise err

    def single_rollback_check(self):
        '''
        rollback-check step for single upgrade
        '''
        self.__config.check_step(STEP_ROLLBACK_CHECK)
        try:
            self.log("Rollback-check for single upgrade.", True)
            cmd = self.__single_generate_uprade_cmd('rollback-check', 
                                                    self.__config.need_passwd)
            self.__single_execute_command(cmd, self.__config.need_passwd)
            self.__config.update_upgrade_step(STEP_ROLLBACK_CHECK, "None", STEP_SUCCESS)
            self.log("Rollback-check finished.", True)
        except (UpgradeException, KeyboardInterrupt) as err:
            self.__config.update_upgrade_step(STEP_ROLLBACK_CHECK, "None", STEP_FAILED)
            raise err

    def single_precheck(self):
        '''
        precheck step for single upgrade
        '''
        self.log("Begin to precheck for single upgrade.", True)
        self.__config.check_step(STEP_PRECHECK)
        try:
            self.__verifyVersion()
            if self.__config.packtype != 'run':
                upgrade_path = self.__config.local_node.upgrade_path
                upgrade_src_path = os.path.dirname(os.path.realpath(__file__))
                cmd = "if [ -d %s ]; then chmod %s %s -R; rm -rf %s; fi; mkdir %s; cp %s/*.py %s" \
                  % (upgrade_path, self.DIRECTORY_PERMISSION, upgrade_path, upgrade_path, upgrade_path, upgrade_src_path, upgrade_path)
                ret_code, _, errout = exec_popen(cmd)
                if ret_code:
                    UpgradeException(str(errout))

            self.__single_pretest(self.__config.need_passwd)
            self.__config.update_upgrade_step(STEP_PRECHECK, 
                                              SUBSTEP_PRECHECK_PRETEST, 
                                              STEP_SUCCESS)

        except (UpgradeException, KeyboardInterrupt) as err:
            self.__config.update_upgrade_step(STEP_PRECHECK, 
                                              SUBSTEP_PRECHECK_PRETEST, 
                                              STEP_FAILED)
            raise err
        self.log("Precheck for single upgrade finished.", True)

    def __single_pretest(self, interactive=False):
        cmd = self.__single_generate_uprade_cmd('pretest', interactive)
        self.__single_execute_command(cmd, interactive)

    def ha_precheck(self):
        '''
        pre-check before upgrade HA
        '''
        self.log("Begin to precheck for ha upgrade.", True)
        self.__config.check_step(STEP_PRECHECK)
        try:
            self.__verifyVersion()
            # 0. check ssh connect without password
            self.log("Check connect to nodes.", True)
            self.__check_ssh_connection()
            # 1. create user trust
            self.__sshexkey("create")
            # 2. check the version are some all the nodes
            self.log("Check database version.", True)
            self.__ha_check_version()
            # 3. check node environment
            self.log("Check node environment.", True)
            self.__ha_precheck_nodes()
            # 4. distribute package
            self.log("Send package to remote node.", True)
            if self.__config.packtype == 'run':
                self.__ha_distribute_run_pkg()
            else:
                self.__ha_distribute_pkg()
            # 5. pre-check all instance
            self.log("Run pretest for upgrade.", True)
            self.__ha_pretest()
        except UpgradeException as err:
            raise err
        except KeyboardInterrupt as err:
            self.__config.update_upgrade_step(STEP_PRECHECK, "None", STEP_FAILED)
            raise err

        self.log("Precheck for ha upgrade finished.", True)

    def __check_ssh_connection(self):
        '''
        check ssh connection without password, if success to
        connect the node user trust to the node has be created
        '''
        failed_ip = []
        success_ip = []
        ssh = get_abs_path("ssh")
        if not ssh:
            raise UpgradeException("Can not find ssh in PATH.")
        for node in self.__config.nodes:
            cmd = "%s %s -o PasswordAuthentication=no -o ConnectTimeout=10" % (ssh, node.ip)
            process = Execution(cmd)
            idx = process.expect(['Permission denied','Last login','Are you sure you want to continue connecting', 'Password', 'ssh:'], 60)
            if idx == 0:
                failed_ip.append(node.ip)
            elif idx == 1:
                success_ip.append(node.ip)
                process.sendLine("exit")
            elif idx == 2:
                process.sendLine('yes')
                idx = process.expect(['Permission denied','Last login', 'Password', 'ssh:'], 60)
                if idx == 0:
                    failed_ip.append(node.ip)
                elif idx == 1:
                    success_ip.append(node.ip)
                    process.sendLine("exit")
                elif idx == 2:
                    raise UpgradeException("Check ssh connection failed, check your ssh configure file please.")
                elif idx == 3:
                    raise UpgradeException(str(process.context_buffer))
            elif idx == 3:
                # when ChallengeResponseAuthentication is yes in sshd configure file,
                # the check method will change to use password authentication method,
                # so we must expect Password key word to avoid to wait to timeout
                raise UpgradeException("Check ssh connection failed, check your ssh configure file please.")
            elif idx == 4:
                raise UpgradeException(str(process.context_buffer))

        if len(failed_ip) == len(self.__config.nodes):
            # all remote node connect failed. user must create trust
            self.__config.user_trust = True
        else:
            self.__config.user_trust = False
            # some node connect successfully and some failed.
            if not success_ip:
                raise UpgradeException("User trust has beed exist in some nodes"
                                       ", and not exist in other nodes, please"
                                       "make sure user trust in all nodes or not"
                                       "exist")
    def __ha_check_version(self):
        '''
        check database version
        '''
        cmds = []
        for node in self.__config.nodes:
            cmd = "%s/bin/zengine -v" % node.app_path
            cmds.append([node.ip, cmd])
        ret_code, output, _ = self.__config.cmd_tool.execute_in_node(cmds)
        try:
            if ret_code:
                raise UpgradeException("Get database version failed.")
            local_ver = output[0]
            output.pop(0)
            
            for ver in output:
                if local_ver[1][1] != ver[1][1]:
                    raise UpgradeException("The database version in nodes are different.")
            self.__config.update_upgrade_step(STEP_PRECHECK,
                                              SUBSTEP_PRECHECK_CHECK_VER,
                                              STEP_SUCCESS)
        except UpgradeException:
            self.__config.update_upgrade_step(STEP_PRECHECK, 
                                              SUBSTEP_PRECHECK_CHECK_VER, 
                                              STEP_FAILED)
            raise 

    def __sshexkey(self, opt):
        '''
        call sshexkey.py to create/clean user trust
        action: create - create user trust
                clean  - clean user trust
        '''
        if opt == "create" and (self.__config.user_trust):
            ret_code, _, _ = exec_popen("touch %s" % self.__config.upgrade_sshkey_mark)
            if ret_code:
                raise UpgradeException("User trust exists, but can't mark for the condition.")

        ip_str = ""
        for ip in self.__config.ips:
            ip_str = "%s%s," % (ip_str, ip)

        ip_str = ip_str.rstrip(',')
        sshexkey_cmd = "%s %s/sshexkey.py" % (PYBIN, os.path.dirname(os.path.realpath(__file__)))

        if opt == "create":
            cmd = "%s -h %s" % (sshexkey_cmd, ip_str)
        elif opt == "clean":
            cmd = "%s -h %s --cleanup" % (sshexkey_cmd, ip_str)
        ret_code, stdout, stderr = exec_popen(cmd)
        if ret_code:
            output = get_error_msg(stdout, stderr)
            raise UpgradeException(str(output))

    def __get_dia_pkg(self):
        '''
        get dialect package, if not found, return empty string
        '''
        if self.__pkg_info.is_green_pkg:
            # it is green package, not need dialect package
            return ""
        _path = os.path.dirname(self.__config.local_node.pkg)
        dialect_pkg = ""
        cmd = 'cd %s; find . -maxdepth 1 -name "%s"' % (_path, "*DIALECT*.tar.gz")
        _, output, _ = exec_popen(cmd)
        target = output.strip()
        absPath = os.path.normpath(os.path.join(_path, target))
        if os.path.isfile(absPath):
            dialect_pkg = absPath
        return dialect_pkg

    def __ha_distribute_pkg(self):
        '''
        distribute package to remote when packtype is package
        '''
        src = self.__config.local_node.pkg
        upgrade_src_path = os.path.dirname(os.path.realpath(__file__))
        upgrade_src = os.path.join(upgrade_src_path, "*.py")
        scp_cmds = []
        scp_src_cmds = []
        cmds = []
        dialect_pkg = self.__get_dia_pkg()

        for node in self.__config.nodes:
            upgrade_path = node.upgrade_path
            cmd = "if [ -d %s ]; then chmod %s %s -R; rm -rf %s; fi; mkdir %s" \
              % (upgrade_path, self.DIRECTORY_PERMISSION, upgrade_path, upgrade_path, upgrade_path)

            cmds.append([node.ip, cmd])
            scp_src_cmds.append([node.ip, upgrade_src, upgrade_path, True])
            if node.ip == self.__config.local_ip:
                continue

            dest_pkg_path = node.pkg_path
            scp_cmds.append([node.ip, src, dest_pkg_path, False])
            if dialect_pkg:
                scp_cmds.append([node.ip, dialect_pkg, dest_pkg_path, False])
        try:
            ret_code, _, failed = self.__config.cmd_tool.execute_in_node(cmds)
            if ret_code:
                raise UpgradeException(str(failed))

            ret_code, _, failed = self.__config.cmd_tool.scp_in_node(scp_src_cmds)
            if ret_code:
                raise UpgradeException(str(failed))

            ret_code, _, failed = self.__config.cmd_tool.scp_in_node(scp_cmds)
            if ret_code:
                raise UpgradeException(str(failed))
            self.__config.update_upgrade_step(STEP_PRECHECK,
                                              SUBSTEP_PRECHECK_DISTRIBUTE_PKG,
                                              STEP_SUCCESS)
        except UpgradeException as err:
            self.__config.update_upgrade_step(STEP_PRECHECK,
                                              SUBSTEP_PRECHECK_DISTRIBUTE_PKG,
                                              STEP_FAILED)
            raise err

    def __ha_distribute_run_pkg(self):
        '''
        distribute package to remote when packtype is run
        '''
        scp_cmds = []
        src = self.__config.local_node.pkg
        upgrade_path = self.__config.local_node.upgrade_path
        for node in self.__config.nodes:
            if node.ip == self.__config.local_ip:
                continue

            # check remote node file exists or not
            # files exists, not rm and scp
            # files not exists, scp them to remote nodes
            cmd = "if [ -d %s ];then if [ \`ls -A %s | wc -l \` != 0 ]; then echo okok;fi;fi;" % (
                node.pkg_path, node.pkg_path)
            exec_cmd = [[node.ip, cmd]]
            ret_code, outputs, failed = self.__config.cmd_tool.execute_in_node(exec_cmd)
            if ret_code:
                raise UpgradeException(str(failed))

            if outputs[0][1][1].strip() != "okok":
                # run package files not exists, scp new files
                dest_pkg_path = node.pkg_path
                # delete empty directory
                cmd = [[node.ip, "rm -rf %s" % dest_pkg_path]]
                ret_code, _, failed = self.__config.cmd_tool.execute_in_node(cmd)
                if ret_code:
                    raise UpgradeException(str(failed))
                # scp new directory
                scp_cmds.append([node.ip, src, dest_pkg_path, True])

            if self.__is_degrade:
                # do degrade, check remote upgrade files exists or not
                # if not exists, scp new files
                cmd = "if [ -d %s ];then if [ \`ls -A %s | wc -l \` != 0 ]; then echo okok;fi;fi;" % (
                    upgrade_path, upgrade_path)
                exec_cmd = [[node.ip, cmd]]
                ret_code, outputs, failed = self.__config.cmd_tool.execute_in_node(exec_cmd)
                if ret_code:
                    raise UpgradeException(str(failed))
                if outputs[0][1][1].strip() != "okok":
                    # delete empty directory
                    cmd = [[node.ip, "rm -rf %s" % upgrade_path]]
                    ret_code, _, failed = self.__config.cmd_tool.execute_in_node(cmd)
                    if ret_code:
                        raise UpgradeException(str(failed))
                    # scp new directory
                    scp_cmds.append([node.ip, upgrade_path, os.path.dirname(upgrade_path), True])

        try:
            if scp_cmds:
                ret_code, _, failed = self.__config.cmd_tool.scp_in_node(scp_cmds)
                if ret_code:
                    raise UpgradeException(str(failed))
            self.__config.update_upgrade_step(STEP_PRECHECK,
                                              SUBSTEP_PRECHECK_DISTRIBUTE_PKG,
                                              STEP_SUCCESS)
        except UpgradeException as err:
            self.__config.update_upgrade_step(STEP_PRECHECK,
                                              SUBSTEP_PRECHECK_DISTRIBUTE_PKG,
                                              STEP_FAILED)
            raise err

    def __ha_precheck_nodes(self):
        '''
        check nodes, such as path exist and premission
        '''
        cmds = []
        for node in self.__config.nodes:
            pkg_path = os.path.dirname(node.pkg)
            backup_path = os.path.dirname(node.backup_path)
            cmd = "if [ ! -d %s ]; then echo '%s not exist.'; exit 1; fi; " % (pkg_path, pkg_path)
            cmd = "%sif [ ! -d %s ]; then echo '%s not exist.'; exit 1; fi; " % (cmd, node.app_path, node.app_path)
            cmd = "%sif [ ! -d %s ]; then echo '%s not exist.'; exit 1; fi; " % (cmd, backup_path, backup_path)
            cmd = "%sif [ ! -r %s ]; then echo '%s can not be read.'; exit 1; fi; " % (cmd, pkg_path, pkg_path)
            cmd = "%sif [ ! -r %s ]; then echo '%s can not be read.'; exit 1; fi; " % (cmd, node.app_path, node.app_path)
            cmd = "%sif [ ! -w %s ]; then echo '%s can not be write.'; exit 1; fi; " % (cmd, backup_path, backup_path)

            data_path_list = node.data_path.split(',')
            for d_path in data_path_list:
                cmd = "%sif [ ! -d %s ]; then echo '%s not exist.'; exit 1; fi; " % (cmd, d_path, d_path)
                cmd = "%sif [ ! -r %s ]; then echo '%s can not be write.'; exit 1; fi; " % (cmd, d_path, d_path)

            cmd = "%sif [ ! -d %s ]; then mkdir -p %s; fi" % (cmd, node.backup_path, node.backup_path)
            cmds.append([node.ip, cmd])

        ret_code, _, failed = self.__config.cmd_tool.execute_in_node(cmds)
        if ret_code:
            self.__config.update_upgrade_step(STEP_PRECHECK,
                                              SUBSTEP_PRECHECK_CHECK_NODE,
                                              STEP_FAILED)
            raise UpgradeException(str(failed))
        self.__config.update_upgrade_step(STEP_PRECHECK,
                                          SUBSTEP_PRECHECK_CHECK_NODE,
                                          STEP_SUCCESS)

    def __ha_pretest(self):
        '''
        pretest step for pre-check
        '''
        cmds = self.__ha_generate_upgrade_cmd('pretest', 
                                              self.__config.need_passwd)
        try:
            self.__ha_execute_command(cmds, self.__config.need_passwd)
            self.__config.update_upgrade_step(STEP_PRECHECK, 
                                              SUBSTEP_PRECHECK_PRETEST,
                                              STEP_SUCCESS)
        except (UpgradeException, KeyboardInterrupt) as err:
            self.__config.update_upgrade_step(STEP_PRECHECK, 
                                              SUBSTEP_PRECHECK_PRETEST, 
                                              STEP_FAILED)
            raise err

    def ha_run(self):
        '''
        main process for upgrade
        '''
        self.__verifyVersion()
        self.__set_upgrade_type()
        if self.__systable_upgrade():
            self.__ha_run_systable()
        else:
            self.__ha_run_binary()

    def __ha_run_binary(self):
        '''
        1. precheck
        2. prepare
        3. replace
        4. dbcheck
        5. flush
        '''
        self.__config.check_step(STEP_RUN)
        try:
            self.log("Begin to run step for ha upgrade.", True)
            self.log("Precheck step for ha upgrade.", True)
            self.__ha_run_precheck(self.__config.need_passwd)
            self.log("Prepare step for ha upgrade.", True)
            self.__ha_run_prepare(self.__config.need_passwd)
            self.log("Replace step for ha upgrade.", True)
            self.__ha_run_replace()
            self.log("Dbcheck step for ha upgrade.", True)
            self.__ha_run_dbcheck(self.__config.need_passwd)
            self.log("Flush step for ha upgrade.", True)
            self.__ha_run_flush(self.__config.need_passwd)
            self.__config.update_upgrade_step(STEP_RUN, "None", STEP_SUCCESS)
            self.log("Run for ha upgrade finished.", True)
        except (UpgradeException, KeyboardInterrupt, SshToolException) as err:
            self.__process_run_exception(err)

    def __process_run_exception(self, _err):
        '''
        auto rollback or not
        '''
        self.__config.update_upgrade_step(STEP_RUN, "None", STEP_FAILED)
        if not self.__config.auto_rollback:
            raise _err
        self.log("Upgrade failed, begin to auto-rollback.")
        if self.__config.ha_mode:
            self.ha_rollback_check()
            self.ha_rollback()
        else:
            self.single_rollback_check()
            self.single_rollback()
        raise UpgradeException("Auto-rollback finished.")
            
    def __ha_run_systable(self):
        '''
        1. precheck
        2. prepare
        3. replace
        4. start
        5. upgrade
        6. sync
        7. restart (degrade)
        8. upgrade-view (degrade)
        9. checkpoint (degrade)
        10. dbcheck
        11. flush
        '''
        self.__config.check_step(STEP_RUN)
        try:
            self.log("Begin to run step for ha upgrade.", True)
            self.log("Precheck step for ha upgrade.", True)
            self.__ha_run_precheck(self.__config.need_passwd)
            self.log("Prepare step for ha upgrade.", True)
            self.__ha_run_prepare(self.__config.need_passwd)
            self.log("Replace step for ha upgrade.", True)
            self.__ha_run_replace()
            self.log("Start step for ha upgrade.", True)
            self.__ha_run_start(self.__config.need_passwd)
            self.log("Upgrade step for ha upgrade.", True)
            self.__ha_run_upgrade(self.__config.need_passwd)
            self.log("Sync step for ha upgrade.", True)
            self.__ha_run_sync(self.__config.need_passwd)
            if self.__is_degrade:
                self.log("Restart step for ha upgrade.", True)
                self.__ha_run_restart(self.__config.need_passwd)
                self.log("Upgrade-view step for ha upgrade.", True)
                self.__ha_run_upgrade_view(self.__config.need_passwd)
                self.log("Checkpoint step for ha upgrade.", True)
                self.__ha_run_checkpoint(self.__config.need_passwd)
            self.log("Dbcheck step for ha upgrade.", True)
            self.__ha_run_dbcheck(self.__config.need_passwd)
            self.log("Flush step for ha upgrade.", True)
            self.__ha_run_flush(self.__config.need_passwd)
            self.__config.update_upgrade_step(STEP_RUN, "None", STEP_SUCCESS)
            self.log("Run for ha upgrade finished.", True)
        except (UpgradeException, KeyboardInterrupt, SshToolException) as err:
            self.__process_run_exception(err)

    def __ha_generate_upgrade_cmd(self, act, interactive=False):
        '''
        generate upgrade command for each node by node information
        act - action for upgrade.py
        interactive - -P parameter, if interactive is True, we must
        set user name and password
        return - a list of command, each command's format:
                 interactive is Ture: [ip, shell_command, user_info]
                 interactive is False: [ip, shell_command]
        NOTE: user_info in command must be 2 in the list, if you change
              the position of user_info, you must change delete_passwd
        ''' 
        cmds = []
        for node in self.__config.nodes:
            cmd = "cd %s; source /etc/profile; %s upgrade.py -t %s" % (node.upgrade_path, PYBIN, act)
            cmd = "%s --GSDB_HOME=%s --GSDB_DATA=%s" % (cmd, node.app_path, node.data_path)
            cmd = "%s --package=%s --backupdir=%s" % (cmd, node.pkg, node.backup_path)
            if self.__config.packtype == 'run':
                cmd = "%s --packtype=run" % cmd
            if interactive:
                cmd = "%s -P" % cmd
                user_info = [self.__config.user, 
                             self.__config.db_passwd, 
                             self.__config.db_passwd_mount]
                cmds.append([node.ip, cmd, user_info])
            else:
                cmds.append([node.ip, cmd])
        return cmds

    def __ha_generate_upgrade_cmd2(self, act):
        '''
        generate upgrade command for each node by node information
        act - action for upgrade.py
        interactive - -P parameter
        '''
        cmds = []
        for node in self.__config.nodes:
            cmd = "cd %s; source /etc/profile; nohup %s upgrade.py -t %s" % (node.upgrade_path, PYBIN, act)
            cmd = "%s --GSDB_HOME=%s --GSDB_DATA=%s" % (cmd, node.app_path, node.data_path)
            cmd = "%s --package=%s --backupdir=%s" % (cmd, node.pkg, node.backup_path)
            if self.__config.packtype == 'run':
                cmd = "%s --packtype=run" % cmd
            cmd = "%s >/dev/null 2>&1 & " % cmd
            cmds.append("ssh %s \"%s\"" % (node.ip, cmd))
        return cmds

    def __single_generate_uprade_cmd(self, act, interactive=False):
        '''
        generate upgrade command for single mode, like ha, but there is 
        no ip in the command list
        '''
        user_info = []
        node = self.__config.local_node
        if act == "upgrade-type":
            cur_path = os.path.dirname(os.path.realpath(__file__))
            cmd = "cd %s; source /etc/profile; %s upgrade.py -t %s" % (cur_path, PYBIN, act)
        else:
            cmd = "cd %s; source /etc/profile; %s upgrade.py -t %s" % (node.upgrade_path, PYBIN, act)
        cmd += " --GSDB_HOME=%s --GSDB_DATA=%s" % (node.app_path, node.data_path)
        cmd += " --package=%s --backupdir=%s" % (node.pkg, node.backup_path)
        if self.__config.packtype == 'run':
            cmd += " --packtype=run"

        if interactive:
            cmd += " -P"
            user_info = [self.__config.user, 
                         self.__config.db_passwd, 
                         self.__config.db_passwd_mount]

        else:
            user_info = None
        return [[None, cmd, user_info]]


    def __ha_run_precheck(self, interactive=False):
        '''
        call upgrade -t precheck in all nodes
        '''
        cmds = self.__ha_generate_upgrade_cmd('precheck', interactive)
        self.__ha_execute_command(cmds, interactive)

    def __ha_run_prepare(self, interactive=False):
        '''
        prepare step for ha upgrade without -P parameter
        '''
        cmds = self.__ha_generate_upgrade_cmd('prepare', interactive)
        self.__ha_execute_command(cmds, interactive)

    def __clean_replace_fin(self):
        '''
        clean replace fin file
        '''
        cmds_rm = []
        for node in self.__config.nodes:
            fin_file = "%s/replace_fin" % node.backup_path
            rm_cmd = "if [ -f %s ]; then rm -f %s; fi " % (fin_file, fin_file)
            cmds_rm.append([node.ip, rm_cmd])
        ret_code, _, failed = self.__config.cmd_tool.execute_in_node(cmds_rm)
        if ret_code:
            raise UpgradeException(str(failed))

    def __ha_run_replace(self):
        '''
        '''
        try:
            self.__clean_replace_fin()
            cmds = self.__ha_generate_upgrade_cmd2('replace')
            for cmd in cmds:
                status, stdout, stderr = exec_popen(cmd)
                if status:
                    raise UpgradeException("Failed to execute cmd:%s, "
                                           "output:%s%s" % (str(cmd), str(stdout), str(stderr)))
            self.__check_replace()
        except (Exception, KeyboardInterrupt) as err:
            raise err
        finally:
            self.__clean_replace_fin()

    def __check_replace(self):
        cmds = []
        cat_cmds = []
        for node in self.__config.nodes:
            cmd = "if [ ! -f %s/replace_fin ]; then exit 1; fi;" % node.backup_path
            cat_cmd = "cat %s/replace_fin" % node.backup_path
            cmds.append([node.ip, cmd])
            cat_cmds.append([node.ip, cat_cmd])
        for _ in range(720):
            ret_code, _, _ = self.__config.cmd_tool.execute_in_node(cmds)
            if ret_code == 0:
                _, outputs, _ = self.__config.cmd_tool.execute_in_node(cat_cmds)
                failed = []
                for output in outputs:
                    if output[1][1].strip(' ') != '0':
                        failed.append(output[0])
                if not failed:
                    break
                raise UpgradeException("Replace step failed, check log in %s for details." % str(failed))
            time.sleep(5)
        else:
            raise UpgradeException("Replace timeout.")

    def __ha_run_start(self, interactive=False):
        '''
        upgrade step for HA upgrade run
        '''
        cmds = self.__ha_generate_upgrade_cmd('start', interactive)
        self.__ha_execute_command(cmds, interactive)

    def __ha_run_upgrade(self, interactive=False):
        '''
        upgrade step for HA upgrade run
        '''
        cmds = self.__ha_generate_upgrade_cmd('upgrade', interactive)
        self.__ha_execute_command(cmds, interactive)

    def __ha_run_sync(self, interactive=False):
        '''
        sync step for ha upgrade without -P parameter
        '''
        cmds = self.__ha_generate_upgrade_cmd('sync', interactive)
        self.__ha_execute_command(cmds, interactive)

    def __ha_run_restart(self, interactive=False):
        '''
        restart step for ha upgrade without -P parameter
        '''
        cmds = self.__ha_generate_upgrade_cmd('restart', interactive)
        self.__ha_execute_command(cmds, interactive)

    def __ha_run_upgrade_view(self, interactive=False):
        '''
        upgrade-view step for ha upgrade without -P parameter
        '''
        cmds = self.__ha_generate_upgrade_cmd('upgrade-view', interactive)
        self.__ha_execute_command(cmds, interactive)

    def __ha_run_checkpoint(self, interactive=False):
        '''
        checkpoint step for ha upgrade without -P parameter
        '''
        cmds = self.__ha_generate_upgrade_cmd('checkpoint', interactive)
        self.__ha_execute_command(cmds, interactive)

    def __ha_run_dbcheck(self, interactive=False):
        '''
        dbcheck step for ha upgrade without -P parameter
        '''
        cmds = self.__ha_generate_upgrade_cmd('dbcheck', interactive)
        self.__ha_execute_command(cmds, interactive)

    def __ha_run_flush(self, interactive=False):
        '''
        switch step for ha upgrade without -P parameter
        '''
        cmds = self.__ha_generate_upgrade_cmd('flush', interactive)
        self.__ha_execute_command(cmds, interactive)

    def ha_cleanup(self):
        '''
        cleanup step for ha upgrade
        '''
        self.__config.check_step(STEP_CLEAN)
        try:
            clean_user_trust = False

            if os.path.exists(self.__config.upgrade_sshkey_mark):
                clean_user_trust = True
            # clean node
            print("Clean nodes.")
            self.__ha_clean_node()
            if self.__config.ha_mode and clean_user_trust:
                # clean user turst
                print("Clean user trust.")
                self.__sshexkey('clean')
        except (UpgradeException, KeyboardInterrupt) as err:
            raise err

    def __ha_clean_node(self):
        '''
        clean node: clean backup_path and tmp file for ha upgrade
        '''
        cmds = []
        dia_pkg = ""
        if self.__config.packtype != 'run':
            dia_pkg = self.__get_dia_pkg()
            dia_pkg = os.path.basename(dia_pkg)
        for node in self.__config.nodes:
            if node.ip == self.__config.local_ip:
                cmd = "rm -rf %s;" % self.__config.ha_upgrade_step_file
                cmd = "%schmod %s %s -R; rm -rf %s" % (cmd, self.DIRECTORY_PERMISSION, node.backup_path, node.backup_path)
            else:
                if self.__config.packtype != 'run':
                    cmd = "rm -rf %s;" % node.pkg
                    if dia_pkg:
                        cmd = "%srm -rf %s/%s;" % (cmd, node.pkg_path, dia_pkg)
                    cmd = "%schmod %s %s -R; rm -rf %s" % (cmd, self.DIRECTORY_PERMISSION, node.backup_path, node.backup_path)
                else:
                    cmd = "chmod %s %s -R; rm -rf %s" % (self.DIRECTORY_PERMISSION, node.backup_path, node.backup_path)

            cmds.append([node.ip, cmd])
        ret_code, _, failed = self.__config.cmd_tool.execute_in_node(cmds)
        if ret_code:
            raise UpgradeException(str(failed))

    def ha_rollback(self):
        '''
        rollback step for ha upgrade
        '''
        self.__config.check_step(STEP_ROLLBACK)
        try:
            self.log("Rollback for ha upgrade.", True)
            cmds = self.__ha_generate_upgrade_cmd('rollback', self.__config.need_passwd)
            self.__ha_execute_command(cmds, self.__config.need_passwd)
            self.log("Rollback-clean for ha upgrade.", True)
            cmds = self.__ha_generate_upgrade_cmd('rollback-clean', self.__config.need_passwd)
            self.__ha_execute_command(cmds, self.__config.need_passwd)
            self.__config.update_upgrade_step(STEP_ROLLBACK, "None", STEP_SUCCESS)
            self.log("Rollback finished.", True)            
        except (UpgradeException, KeyboardInterrupt) as err:
            self.__config.update_upgrade_step(STEP_ROLLBACK, "None", STEP_FAILED)
            raise err

    def ha_rollback_check(self):
        '''
        rollback check step for rollback when ha upgrade failed
        '''
        self.__config.check_step(STEP_ROLLBACK_CHECK)
        try:
            self.log("Rollback-check for ha upgrade.", True)
            cmds = self.__ha_generate_upgrade_cmd('rollback-check', self.__config.need_passwd)
            self.__ha_execute_command(cmds, self.__config.need_passwd)
            self.__config.update_upgrade_step(STEP_ROLLBACK_CHECK, "None", STEP_SUCCESS)
            self.log("Rollback-check finished.", True)
        except (UpgradeException, KeyboardInterrupt) as err:
            self.__config.update_upgrade_step(STEP_ROLLBACK_CHECK, "None", STEP_FAILED)
            raise err
            
    def __checkRunPackage(self):
        '''
        check run package's sha256 sum
        '''

        runFile, sha256File = self.__pkg_info.getRunPackage()
        if(sha256File == ""):
            raise Exception("Can not find verification file.")

        strRead = ''
        with open(sha256File, 'r') as fp:
            strRead = fp.readline()
        isSame = checkSHA256(runFile, strRead.strip())
        if not isSame:
            raise Exception("Check integrality of run file failed")

    def __testPeerLFNbyInst(self, inst):
        '''
        test database server's peer LFN
        '''
        self.log("Check peer LFN on database '%s'." % inst.datadir())
        local_LFNs = self.__getOneColFromView(inst, 'LOCAL_LFN', 'HA_SYNC_INFO', 'where STATUS!=\'NOT RUNNING\'')
        peer_LFNs = self.__getOneColFromView(inst, 'PEER_LFN', 'HA_SYNC_INFO', 'where STATUS!=\'NOT RUNNING\'')
        self.log('local LFN : %s' % str(local_LFNs))
        self.log('peer LFN : %s' % str(peer_LFNs))
        for i in local_LFNs:
            if abs(int(i) - int(peer_LFNs[local_LFNs.index(i)])) > 1000:
                raise Exception("Test LFNs diff more than 1000!")

    def __testPeerLFN(self):
        '''
        test database server's peer LFN
        '''
        for i in self.__db_instances:
            self.__testPeerLFNbyInst(i)

    def __checkPeerLFNbyInst(self, inst, times=60):
        '''
        check database server's peer LFN
        '''

        all_lfns = None
        self.log("Check peer LFN on database '%s'." % inst.datadir())
        for _ in range(times):
            local_LFNs = self.__getOneColFromView(inst, 'LOCAL_LFN', 'HA_SYNC_INFO', 'where STATUS!=\'NOT RUNNING\'')
            peer_LFNs = self.__getOneColFromView(inst, 'PEER_LFN', 'HA_SYNC_INFO', 'where STATUS!=\'NOT RUNNING\'')
            all_lfns = set(local_LFNs + peer_LFNs)
            self.log('local LFN : %s' % str(local_LFNs))
            self.log('peer LFN : %s' % str(peer_LFNs))
            if '0' in all_lfns or len(all_lfns) > 1:
                self.log("LFNs : %s" % str(all_lfns))
                time.sleep(1)
            else:
                break
        else:
            if '0' in all_lfns:
                raise Exception("Database's local LFN or peer LFN is equal to ZERO!")
            raise Exception("Database's local LFN is not equal to peer LFN.")

        return all_lfns

    def __checkPeerLFN(self, tryTime=60):
        '''
        check database server's peer LFN
        '''
        for i in self.__db_instances:
            inst_lfn = self.__checkPeerLFNbyInst(i, tryTime)
            self.log("Before:Instance %s lfn %s" % (i.datadir(), str(inst_lfn)))
            if inst_lfn:
                self.__lfn_infos[i] = list(inst_lfn)[0]

    def __setDbReadonlyInst(self, inst):
        '''
        set database server to readonly 
        '''
        # check database readonly or not
        self.log("Set database '%s' read only." % inst.datadir())
        open_status = self.__getOneColFromView(inst, 'OPEN_STATUS', 'DATABASE')[0]
        if open_status.upper() == "READ ONLY":
            # database already read only
            self.log("%s database already %s" % (inst.datadir(), open_status))
            return

        sql = "ALTER DATABASE CONVERT TO READONLY"
        self.__execSql(sql, inst)

    def __setDbReadWriteInst(self, inst):
        '''
        set database server to readwrite
        '''
        # check database readonly or not
        self.log("Set database '%s' read write." % inst.datadir())
        open_status = self.__getOneColFromView(inst, 'OPEN_STATUS', 'DATABASE')[0]
        if open_status.upper() == "READ WRITE":
            # database already read write
            self.log("%s database already %s" % (inst.datadir(), open_status))
            return

        sql = "ALTER DATABASE CONVERT TO READWRITE"
        self.__execSql(sql, inst)

    def __setDbReadonly(self):
        '''
        set database server to readonly 
        '''
        for i in self.__db_instances:
            role = self.__getOneColFromView(i, 'DATABASE_ROLE', 'DATABASE')[0]
            # in primary db, set read only mode
            if role.upper() == 'PRIMARY':
                self.__setDbReadonlyInst(i)

    def __setDbReadWrite(self):
        '''
        set database server to readwrite
        '''
        self.log('Set database read write mode.')
        for i in self.__db_instances:
            role = self.__getOneColFromView(i, 'DATABASE_ROLE', 'DATABASE')[0]
            # in primary db, set read write mode
            if role.upper() == 'PRIMARY':
                self.__setDbReadWriteInst(i)

    def doPretest(self):
        '''
        check database server before upgrading
        '''
        self.log("Check database version.", True)
        self.__verifyVersion()

        self.log("Check tools used by upgrade.", True)
        self.__checkTools()

        self.log("Generate system table upgrade sql.", True)
        self.__generateSql()

        self.log("Check zenith server health.", True)
        self.__checkPreUpgrade(primary_ro=False)

        self.log("Check Peer LFN.", True)
        self.__testPeerLFN()

        self.log("Done.", True)

    def __set_upgrade_type(self):
        '''
        '''
        old_path = self.__gsdb_home
        new_path = self.__pkg_info.getPackagePath()

        check_files = ['admin/scripts/initdb.sql', 
                       'admin/scripts/initview.sql',
                       'admin/scripts/initplsql.sql',
                       'admin/scripts/initwsr.sql']

        diff_flag = False
        for f in check_files:
            old_sha256 = calcSha256Sum(os.path.join(old_path, f))
            new_sha256 = calcSha256Sum(os.path.join(new_path, f))
            if old_sha256 != new_sha256:
                diff_flag = True
                break

        if not diff_flag:
            diff_flag = self.__checkExtraSql(old_path, new_path)
            self.log("Extral sql diff_flag: %s" % diff_flag)
        if diff_flag:
            self.__upgrade_type = UPGRADE_TYPE_SYSTABLE
        else:
            self.__upgrade_type = UPGRADE_TYPE_BINARY
        self.log("Current upgrade type is: %s" % self.__upgrade_type)

    def __systable_upgrade(self):
        '''
        return True when upgrade_type is systable
        '''
        if self.__upgrade_type == UPGRADE_TYPE_SYSTABLE:
            return True
        return False

    def __binary_upgrade(self):
        '''
        return True when upgrade_type is binary
        '''
        if self.__upgrade_type == UPGRADE_TYPE_BINARY:
            return True
        return False

    def doUpgradeType(self):
        '''
        print upgrade type:
            binary-upgrade
            systable-upgrade
            unable-upgrade
        '''
        self.__set_upgrade_type()
        
        if self.__binary_upgrade():
            self.log("binary-upgrade", True)
            self.__cleanForUpgradeType()
            sys.exit(0)

        try:
            self.__verifyVersion()
            self.__generateSql()
        except Exception as ex:
            self.log("Error output: %s" % str(ex), True)
            self.log("unable-upgrade", True)
            self.__cleanForUpgradeType()
            sys.exit(10)

        if self.__systable_upgrade():
            if self.__is_degrade:
                self.log("systable-degrade", True)
                self.__cleanForUpgradeType()
                sys.exit(2)
            else:
                self.log("systable-upgrade", True)
                self.__cleanForUpgradeType()
                sys.exit(1)

    def __cleanForUpgradeType(self):
        '''
        '''
        try:
            self.__execShellCmd("chmod -R %s %s && rm -rf %s && rm -rf %s" \
                                % (self.DIRECTORY_PERMISSION, self.__backup, self.__backup, self.__logfile))
        except Exception as err:
            print(str(err))


    def doPrecheck(self):
        '''
        check database server before upgrading
        '''

        # check action is right or not
        self.__checkUpgradeStep()
        # check if need do rollback or not
        self.__checkRollback()
        # check db process, not exists, start again
        self.__checkDbProcess()
        self.__set_upgrade_type()
        try:
            self.log("Check database version.", True)
            self.__verifyVersion()

            self.log("Check tools used by upgrade.", True)
            self.__checkTools()

            if not self.__is_degrade:
                self.log("Check sysaux existing.", True)
                self.__checkSysauxExisting()

            self.log("Set database read only mode.", True)
            self.__setDbReadonly()

            if self.__sysaux:
                self.log("Check sysaux space.", True)
                self.__checkSystemSpaces(tablespace='SYSAUX')

            if self.__systable_upgrade():
                self.log("Check the initdb sqls.", True)
                self.__check_initdb_sql()

                self.log("Check the upgrade white list.", True)
                self.__check_white_list()

                self.log("Generate system table upgrade sql.", True)
                self.__generateSql()

            self.log("Check zenith server health.", True)
            self.__checkPreUpgrade()

            self.log("Check Peer LFN.", True)
            self.__checkPeerLFN()
         
            if self.__systable_upgrade():
                self.log("Fetch system table information.", True)
                self.__getSystemTableInfo()

            self.log("Save zenith server information.", True)
            self.__saveDbInfo()

            if not self.__is_run_package:
                self.log("Check integrality of database package.", True)
                self.__checkRunPackage()

            # record step info:check1
            self.__flushUpgradeStep("precheck:check1")

        except Exception as ex:
            self.__setDbReadWrite()
            raise Exception(str(ex))

        self.log("Done.", True)

    def doPrepare(self):

        # check action is right or not
        self.__checkUpgradeStep()

        # check if need do rollback or not
        self.__checkRollback()

        self.log("Load zenith server information.", True)
        self.__loadDbInfo()

        self.log("Shutdown zenith server.", True)
        self.__shutdown([])

        self.__rename_bin(self.__gsdb_home)

        primary_list = [i for i in self.__db_instances if i.role() == 'PRIMARY']
        standby_list = [i for i in self.__db_instances if i.role() != 'PRIMARY']

        self.log("Restart zenith server(s) read only mode.", True)
        if primary_list:
            self.__startReadonly(primary_list, self.UPGRADE_ZENGINE_NAME)
        if standby_list:
            self.__startNormal(standby_list, self.UPGRADE_ZENGINE_NAME)

        self.log("Do synchronize.", True)
        self.__checkpointOnAll([])

        for i in self.__lfn_infos.keys():
            i_lfn = self.__getOneColFromView(i, "LFN", "DATABASE")[0]
            self.log("After:Instance %s lfn %s" % (i.datadir(), str(i_lfn)))
            if i_lfn != self.__lfn_infos[i]:
                raise Exception("Instance %s LFN changed from %s to %s" % (i.datadir(), self.__lfn_infos[i], i_lfn))

        self.log("Shutdown zenith server.", True)
        self.__shutdown([])

        self.__flushUpgradeStep("prepare:shutdown")
        self.log("Done.", True)

    def doReplace(self):
        """
        :return:
        """
        # backup finish, upgrade failed, prompt do rollback
        try:
            replace_fin = os.path.join(os.path.dirname(self.__backup), 'replace_fin')
            # check action is right or not
            self.__checkUpgradeStep()
            self.log("Load zenith server information.", True)
            self.__loadDbInfo()
            self.log("Backup zenith server.", True)
            self.__backupFiles()

            if (not self.__is_degrade and self.__systable_upgrade()) or self.__binary_upgrade():
                self.log("Update zenith server.", True)
                self.__replace()

            self.__execShellCmd('echo 0 >  %s ' % replace_fin)
        except Exception as ex:
            self.__execShellCmd('echo 1 >  %s ' % replace_fin)
            self.log(str(ex), True)
            self.__promptRollback()
            self.log("Upgrade Failed: %s" % str(ex), True)
            sys.exit(1)

        # record step info
        self.__flushUpgradeStep("replace:update")
        self.log("Done.", True)

    def doStart(self):
        '''
        do start
        '''
        self.log("Load zenith server information.", True)
        
        try:
            self.__loadDbInfo()
            if not self.__systable_upgrade():
                self.log("Can not do start action for binary upgrade, nothing to do.", True)
                self.log("Done.", True)
                return

            # check action is right or not
            self.__checkUpgradeStep()

            self.log("Start zenith server.", True)
            primary_list = [i for i in self.__db_instances if i.role() == 'PRIMARY']
            standby_list = [i for i in self.__db_instances if i.role() != 'PRIMARY']

            if primary_list:
                self.__startUpgrade(primary_list, self.UPGRADE_ZENGINE_NAME)
            if standby_list:
                self.__startNormal(standby_list, self.UPGRADE_ZENGINE_NAME)

            # record step info
            self.__flushUpgradeStep("start:start")

            self.log("Done.", True)

        except Exception as ex:
            self.log(str(ex), True)
            self.__promptRollback()

    def doUpgrade(self):
        '''
        do upgrade
        '''
        self.log("Load zenith server information.", True)
        try:
            self.__loadDbInfo()
            if not self.__systable_upgrade():
                self.log("Can not do upgrade action for binary upgrade, nothing to do.", True)
                self.log("Done.", True)
                return

            # check upgrade step is right or not
            self.__checkUpgradeStep()
            self.log("Check zenith server upgrade mode.", True)
            self.__checkDatabase()

            self.log("Check Peer LFN.", True)
            self.__checkPeerLFN()

            # record step info
            self.__flushUpgradeStep("upgrade:check2")

            self.log("Execute system table upgrade sql.", True)
            if self.__is_degrade:
                self.__execUpgradeSql(phase_num=1)
            else:
                self.__execUpgradeSql()

            # record step info
            self.__flushUpgradeStep("upgrade:exec_upgrade_sql")

            primary_list = [i for i in self.__db_instances if i.role() == 'PRIMARY']

            if not self.__is_degrade:
                if primary_list:
                    self.log("Check upgrade.", True)
                    self.__checkUpgrade(primary_list)

            self.log("Check Peer LFN.", True)
            self.__checkPeerLFN()

            # record step info
            self.__flushUpgradeStep("upgrade:check_lfn")

            if primary_list:
                self.__checkpointOnAll(primary_list)

            self.__flushUpgradeStep("upgrade:primary_ckpt")

            self.log("Done.", True)

        except Exception as ex:
            self.log(str(ex), True)
            self.__promptRollback()

    def doUpgradePhase2(self):
        '''
        do upgrade phase2
        '''
        self.log("Load zenith server information.", True)

        try:
            self.__loadDbInfo()
            if not self.__systable_upgrade():
                self.log("Can not do upgrade-view action for binary upgrade, nothing to do.", True)
                self.log("Done.", True)
                return

            # check upgrade step is right or not
            self.__checkUpgradeStep()

            if not self.__is_degrade:
                raise Exception("Degrade only.")
 
            self.__flushUpgradeStep("upgrade-view:before_exec_sql")

            self.log("Check zenith server upgrade mode.", True)
            self.__checkDatabase()
 
            self.log("Execute system table upgrade sql phase 2.", True)

            self.__generateDictionarySql()
 
            self.__execUpgradeSql(phase_num=2)
 
            primary_list = [ i for i in self.__db_instances if i.role() == 'PRIMARY' ]

            if primary_list:
                self.log("Check upgrade.", True)
                self.__checkUpgrade(primary_list)

            self.log("Check Peer LFN.", True)
            self.__checkPeerLFN()
 
            if primary_list:
                self.__checkpointOnAll(primary_list)

            self.__flushUpgradeStep("upgrade-view:upgrade-view")
 
            self.log("Done.", True)

        except Exception as ex:
            self.log(str(ex), True)
            self.__promptRollback()

    def doSync(self):
        '''
        check point in standby instances
        '''
        self.log("Load zenith server information.", True)
        try:
            self.__loadDbInfo()
            if not self.__systable_upgrade():
                self.log("Can not do sync action for binary upgrade, nothing to do.", True)
                self.log("Done.", True)
                return

            # check action is right or not
            self.__checkUpgradeStep()

            standby_list = [inst for inst in self.__db_instances if inst.role() != 'PRIMARY']
            self.log("Do synchronize.", True)
            if standby_list:
                self.__checkpointOnAll(standby_list)

            # record step info
            if self.__is_degrade:
                self.__flushUpgradeStep("sync:standby_ckpt1")
            else:
                self.__flushUpgradeStep("sync:standby_ckpt")
            self.log("Done.", True)

        except Exception as ex:
            self.log(str(ex), True)
            self.__promptRollback()

    def doCheckpoint(self):
        '''
        check point in standby instances
        '''
        self.log("Load zenith server information.", True)

        try:
            self.__loadDbInfo()
            if not self.__systable_upgrade():
                self.log("Can not do checkpoint action for binary upgrade, nothing to do.", True)
                self.log("Done.", True)
                return

            # check action is right or not
            self.__checkUpgradeStep()

            standby_list = [inst for inst in self.__db_instances if inst.role() != 'PRIMARY']
            self.log("Do synchronize.", True)
            if standby_list:
                self.__checkpointOnAll(standby_list)

            # record step info
            self.__flushUpgradeStep("checkpoint:checkpoint")
            self.log("Done.", True)

        except Exception as ex:
            self.log(str(ex), True)
            self.__promptRollback()

    def doRestartLowUpgrade(self):
        '''
        shutdown 
        replace binary files
        start to upgrade mode
        '''
        self.log("Load zenith server information.", True)
        try:
            self.__loadDbInfo()
            if not self.__systable_upgrade():
                self.log("Can not do restart action for binary upgrade, nothing to do.", True)
                self.log("Done.", True)
                return

            # check action is right or not
            self.__checkUpgradeStep()

            self.__shutdown([])
 
            self.log("Update zenith server.", True)
            self.__replace()
 
            self.log("Start zenith server.", True)
            primary_list = [ i for i in self.__db_instances if i.role() == 'PRIMARY' ]
            standby_list = [ i for i in self.__db_instances if i.role() != 'PRIMARY' ]
            if primary_list:
                self.__startUpgrade(primary_list, self.UPGRADE_ZENGINE_NAME)
            if standby_list:
                self.__startNormal(standby_list, self.UPGRADE_ZENGINE_NAME)
 
            self.__flushUpgradeStep("restart:restart")
            self.log("Done.", True)

        except Exception as ex:
            self.log(str(ex), True)
            self.__promptRollback()

    def doDbcheck(self):
        '''
        check Normal database after upgrade
        '''
        self.log("Load zenith server information.", True)
        try:
            self.__loadDbInfo()
            # check action is right or not
            self.__checkUpgradeStep()

            self.__flushUpgradeStep("dbcheck:load_db_info")
            if self.__systable_upgrade():
                inst_list = [i for i in self.__db_instances if i.role() == 'PRIMARY']
            else:
                inst_list = self.__db_instances
            if inst_list:
                self.__shutdown(inst_list)
                self.log("Restart zenith server(s) read only mode.", True)
                self.__startReadonly(inst_list, self.UPGRADE_ZENGINE_NAME)

            # stop services
            self.log("Shutdown zenith server.", True)
            self.__shutdown([])
            self.__flushUpgradeStep("dbcheck:shutdown")

            self.log("Done.", True)

        except Exception as ex:
            self.log(str(ex), True)
            self.__promptRollback()

    def doFlush(self):
        '''
        at begin, modify zengine -- > new name
        at the end, modfiy new name ---> zengine
        '''
        # check action is right or not
        self.__checkUpgradeStep()
        self.__flushUpgradeStep("flush:rename")
        self.log("Do flush.", True)

        upgrade_zengine = os.path.join(self.__gsdb_home, "bin", self.UPGRADE_ZENGINE_NAME)

        if os.path.exists(upgrade_zengine):
            cmd = "cd %s/bin && rm -f zengine && mv %s zengine && chmod %s zengine" % (
                self.__gsdb_home, self.UPGRADE_ZENGINE_NAME, self.MID_FILE_MODE)

            try:
                self.__execShellCmd(cmd)
            except Exception as ex:
                self.log("Failed to change upgrade_zengine name. please execute cmd %s manually" % cmd)
                raise Exception(str(ex))

        self.log("Flush succeed.", True)

        try:
            self.log("Clean backup files.", True)
            self.__cleanBackupFiles()
        except Exception as ex:
            # decompress and clean failed, warning
            self.log("Warning: Decompress upgrade backup files and clean failed.", True)
            self.log("Warning: Please solve the fail reason: %s." % str(ex), True)
            self.log("Warning: Please decompress backup files and clean manually.", True)

        self.log("Done.", True)

def usage():
    """
    upgrade.py is a utility to upgrade a Zengine server.

    Usage:
        python upgrade.py --help
        python upgrade.py -?
        python upgrade.py -t upgrade-type --package=path_to_package_file --backupdir=path_to_backup [--GSDB_HOME=path_to_gsdb_home] [--GSDB_DATA=path_to_data_dir] [-f cmd_config_file]
        python upgrade.py -t pretest --package=path_to_package_file --backupdir=path_to_backup [--GSDB_HOME=path_to_gsdb_home] [--GSDB_DATA=path_to_data_dir] [-f cmd_config_file] 
        python upgrade.py -t precheck --package=path_to_package_file --backupdir=path_to_backup [--GSDB_HOME=path_to_gsdb_home] [--GSDB_DATA=path_to_data_dir] [-f cmd_config_file]   
        python upgrade.py -t prepare --package=path_to_package_file --backupdir=path_to_backup [--GSDB_HOME=path_to_gsdb_home] [--GSDB_DATA=path_to_data_dir] [-f cmd_config_file]
        python upgrade.py -t replace --package=path_to_package_file --backupdir=path_to_backup [--GSDB_HOME=path_to_gsdb_home] [--GSDB_DATA=path_to_data_dir] [-f cmd_config_file]
        python upgrade.py -t start --package=path_to_package_file --backupdir=path_to_backup [--GSDB_HOME=path_to_gsdb_home] [--GSDB_DATA=path_to_data_dir] [-f cmd_config_file]
        python upgrade.py -t upgrade --package=path_to_package_file --backupdir=path_to_backup [--GSDB_HOME=path_to_gsdb_home] [--GSDB_DATA=path_to_data_dir] [-f cmd_config_file]
        python upgrade.py -t sync --package=path_to_package_file --backupdir=path_to_backup [--GSDB_HOME=path_to_gsdb_home] [--GSDB_DATA=path_to_data_dir] [-f cmd_config_file]
        python upgrade.py -t restart --package=path_to_package_file --backupdir=path_to_backup [--GSDB_HOME=path_to_gsdb_home] [--GSDB_DATA=path_to_data_dir] [-f cmd_config_file]
        python upgrade.py -t upgrade-view --package=path_to_package_file --backupdir=path_to_backup [--GSDB_HOME=path_to_gsdb_home] [--GSDB_DATA=path_to_data_dir] [-f cmd_config_file]
        python upgrade.py -t checkpoint --package=path_to_package_file --backupdir=path_to_backup [--GSDB_HOME=path_to_gsdb_home] [--GSDB_DATA=path_to_data_dir] [-f cmd_config_file]
        python upgrade.py -t dbcheck --package=path_to_package_file --backupdir=path_to_backup [--GSDB_HOME=path_to_gsdb_home] [--GSDB_DATA=path_to_data_dir] [-f cmd_config_file]
        python upgrade.py -t flush --package=path_to_package_file --backupdir=path_to_backup [--GSDB_HOME=path_to_gsdb_home] [--GSDB_DATA=path_to_data_dir] [-f cmd_config_file]
        python upgrade.py -t rollback-check --backupdir=path_to_backup [--GSDB_HOME=path_to_gsdb_home] [--GSDB_DATA=path_to_data_dir] [-f cmd_config_file]
        python upgrade.py -t rollback --backupdir=path_to_backup [--GSDB_HOME=path_to_gsdb_home] [--GSDB_DATA=path_to_data_dir] [-f cmd_config_file]
        python upgrade.py -t rollback-clean --backupdir=path_to_backup [--GSDB_HOME=path_to_gsdb_home] [--GSDB_DATA=path_to_data_dir] [-f cmd_config_file]
        python upgrade.py -s pre-check --config-file=CONFIG_FILE [--upgrade-mode=ha|single] [--packtype=run|package] [-f cmd_config_file]
        python upgrade.py -s run --config-file=CONFIG_FILE [--auto-rollback=true|false] [--upgrade-mode=ha|single] [--packtype=run|package] [-f cmd_config_file]
        python upgrade.py -s cleanup --config-file=CONFIG_FILE [--upgrade-mode=ha|single] [--packtype=run|package] [-f cmd_config_file]
        python upgrade.py -s rollback-check --config-file=CONFIG_FILE [--upgrade-mode=ha|single] [--packtype=run|package] [-f cmd_config_file]
        python upgrade.py -s rollback --config-file=CONFIG_FILE [--upgrade-mode=ha|single] [--packtype=run|package] [-f cmd_config_file]

    Common options:
        --help              show this help, then exit.
        -?                  show this help, then exit.
        -P                  input password.
        -t                  input the function that need to be executed.
        -s                  input the step for upgrade.
        --package           input the name of package containing the path.
        --backupdir         input the name of backup folder containing the path.
        --GSDB_HOME         input the name of app floder containing the path.
        --GSDB_DATA         input the name of data floder containing the path.
        --config-file       input the name of node configure file, the format is:
                            IP=pkg,app_path,backup_path,data1,data2,..
        --auto-rollback     if auto-rollback is false, will not rollback when run step failed
        --upgrade-mode      if upgrade-mode is ha, will upgrade all the nodes in the configure file
        --packtype          input upgrade package type, value scope is [run, package]
        -f                  input the config file that provide 'parameter=value'. -P, --package, --backupdir, --GSDB_HOME, --GSDB_DATA can be configed by a file.
                            in the config file, interactive=True is equal with specify '-P' parameter. 
                            for example, the config file content: 
                            GSDB_HOME=path_to_gsdb_home
                            GSDB_HOME=path_to_gsdb_home
                            backupdir=path_to_package_file
                            interactive=TRUE
    """
    print(usage.__doc__)

def getParameters(paraFile):
    '''
    get parameters from file
    parse format:
    attr_name = value
    and save the information to paraDict
    return the dict
    '''
    
    paraDict = {}

    with open(paraFile, 'r') as fp:
        content = fp.read()
        lines = content.split('\n')
        for line in lines:
            if line.strip():
                if line.find('=') > 0:
                    config = line.split('=', 1)
                    if len(config) == 2:
                        paraDict[config[0].strip()] = config[1].strip()

    return paraDict

if __name__ == '__main__':

    packagefile = ''
    backuppath = ''
    action = ''
    gsdb_home = ''
    gsdb_data = []
    upgrade = None
    need_passwd = False
    parameters_file = ''
    config_file = ''
    _config = None
    ha_step = ""
    auto_rollback = True
    rollback_parameter_flag = False
    # ha/single upgrade mode is supported, default mode is single
    upgrade_mode = 'single'
    is_run_pack = False
    packtype = 'package'

    if(os.getuid() == 0):
        print("Upgrade Failed: Cannot use root user for this operation!")
        sys.exit(1)

    try:
        opts, args = getopt.getopt(sys.argv[1:], "Ps:f:t:?", ['help', 'package=', 'backupdir=', 'GSDB_HOME=', 'GSDB_DATA=', 'auto-rollback=', 'config-file=', 'upgrade-mode=','packtype='])

    except getopt.GetoptError as e:
        print("Upgrade Failed: Error:%s." % str(e))
        sys.exit(1)

    if (len(args) > 0):
        print("Upgrade Failed: Unknown parameter [%s]." % args[0])
        sys.exit(1)

    if (len(opts) == 0):
        print("Upgrade Failed: Missing required parameters.")
        sys.exit(1)

    try:
        for (key, value) in opts:

            if (key == "--help" or key == "-?"):
                usage()
                sys.exit(0)

            if (key == "-P"):
                need_passwd = True

            if (key == "-f"):
                parameters_file = normPath(str(value))
                checkLegalityOfPath(parameters_file)

            if (key == "--config-file"):
                config_file = normPath(str(value))
                checkLegalityOfPath(config_file)

            if (key == "--upgrade-mode"):
                upgrade_mode = str(value)
                if upgrade_mode.lower() not in ["ha", 'single']:
                    raise UpgradeException("Unknown upgrade mode: %s mode." % upgrade_mode)

            if (key == "-s"):
                ha_step = str(value)
                if ha_step not in ["pre-check", "cleanup", "run", "rollback-check", "rollback"]:
                    raise UpgradeException("Unkown step for ha upgrade.")

            if (key == "--auto-rollback"):
                rollback_parameter_flag = True
                auto_rollback = str(value).lower()
                if auto_rollback not in ['true', 'false']:
                    raise UpgradeException("Unknown auto-rollback value: %s." % auto_rollback)
                if auto_rollback == 'false':
                    auto_rollback = False

            if (key == '--package'):
                packagefile = normPath(str(value))
                checkLegalityOfPath(packagefile)

            if (key == '--backupdir'):
                backuppath = normPath(str(value))
                checkLegalityOfPath(backuppath)

            if (key == '--GSDB_HOME'):
                gsdb_home = normPath(str(value))
                checkLegalityOfPath(gsdb_home)

            if (key == '--GSDB_DATA'):
                path_list = str(value).split(',')
                for data_path in path_list:
                    npath = normPath(str(data_path))
                    checkLegalityOfPath(npath)
                    gsdb_data.append(npath)

            if (key == '--packtype'):
                packtype = str(value)
                if not packtype in ['run', 'package']:
                    raise UpgradeException("Unknown packtype: %s." % packtype)
                if packtype == 'run':
                    is_run_pack = True

            if (key == '-t'):
                action = str(value)
                if not action in ['upgrade', 'rollback', 'precheck', 'prepare', 'replace', 'checkpoint',
                                  'dbcheck', 'rollback-check','start', 'restart', 'upgrade-view',
                                  'rollback-clean','sync', 'flush', 'pretest', 'upgrade-type']:
                    print(('Upgrade Failed: Unknown action: %s' % action))
                    sys.exit(1)

        if parameters_file:
            #get parameters from file

            parasFromFile = getParameters(parameters_file)

            if 'GSDB_HOME' in parasFromFile:
                gsdb_home = normPath(parasFromFile['GSDB_HOME'])
                checkLegalityOfPath(gsdb_home)

            if 'GSDB_DATA' in parasFromFile:
                gsdb_data = []
                path_list = str(parasFromFile['GSDB_DATA']).split(',')
                for data_path in path_list:
                    npath = normPath(str(data_path))
                    checkLegalityOfPath(npath)
                    gsdb_data.append(npath)

            if 'backupdir' in parasFromFile:
                backuppath = normPath(parasFromFile['backupdir'])
                checkLegalityOfPath(backuppath)

            if 'package' in parasFromFile:
                packagefile = normPath(parasFromFile['package'])
                checkLegalityOfPath(packagefile)

            if 'interactive' in parasFromFile:
                if parasFromFile['interactive'].upper() == 'TRUE':
                    need_passwd = True

            if 'config-file' in parasFromFile:
                config_file = normPath(parasFromFile['config-file'])
                checkLegalityOfPath(config_file)

            if 'auto-rollback' in parasFromFile:
                rollback_parameter_flag = True
                auto_rollback = parasFromFile['auto-rollback'].lower()
                if auto_rollback not in ['true', 'false']:
                    raise UpgradeException("Unknown auto-rollback value: %s." % auto_rollback)
                if auto_rollback == 'false':
                    auto_rollback = False

            if 'upgrade-mode' in parasFromFile:
                upgrade_mode = parasFromFile['upgrade-mode'].lower()
                if upgrade_mode not in ["ha", 'single']:
                    raise UpgradeException("Unknown upgrade mode: %s mode." % upgrade_mode)

            if 'packtype' in parasFromFile:
                packtype = parasFromFile['packtype'].lower()
                if packtype not in ["package", "run"]:
                    raise UpgradeException("Unknown packtype: %s." % packtype)
                if packtype == "run":
                    is_run_pack = True

        if config_file:
            _config = UpgradeConfig(config_file, auto_rollback, upgrade_mode, packtype)
            backuppath = _config.get_local_backup_path()

        upgrade = Upgrade(packagefile, backuppath, gsdb_home, gsdb_data, need_passwd, is_run_pack, action, _config)

        # -t and -s can't be all none
        if (not action) and (not ha_step):
            raise UpgradeException("-t or -s parameter must be specified one.")

        # -t and -s can't be used together
        if action and ha_step:
            raise UpgradeException("-t and -s parameter can't be specified together.")

        if action:
            upgrade_func = {'upgrade': upgrade.doUpgrade,
                            'rollback': upgrade.doRollback,
                            'rollback-check': upgrade.doRollbackCheck,
                            'precheck': upgrade.doPrecheck,
                            'prepare': upgrade.doPrepare,
                            'replace': upgrade.doReplace,
                            'start': upgrade.doStart,
                            'restart': upgrade.doRestartLowUpgrade,
                            'upgrade-view': upgrade.doUpgradePhase2,
                            'checkpoint': upgrade.doCheckpoint,
                            'dbcheck': upgrade.doDbcheck,
                            'sync': upgrade.doSync,
                            'flush': upgrade.doFlush,
                            'pretest': upgrade.doPretest,
                            'rollback-clean': upgrade.doRollbackClean,
                            'upgrade-type': upgrade.doUpgradeType}
            upgrade_func[action]()
            print('Upgrade [%s] action successfully.' % action)

        if ha_step:
            if not config_file:
                raise UpgradeException("-s parameter must be used with --config-file.")
            if upgrade_mode == "ha":
                upgrade_func = {"pre-check": upgrade.ha_precheck,
                                "run"      : upgrade.ha_run,
                                "cleanup"  : upgrade.ha_cleanup,
                                "rollback" : upgrade.ha_rollback,
                                "rollback-check": upgrade.ha_rollback_check}
            else:
                upgrade_func = {"pre-check": upgrade.single_precheck,
                                "run"      : upgrade.single_run,
                                "rollback" : upgrade.single_rollback,
                                "rollback-check": upgrade.single_rollback_check,
                                "cleanup"  : upgrade.single_cleanup}
            upgrade_func[ha_step]()
            print("Upgrade [%s] step successfully." % ha_step)
        sys.exit(0)

    except Exception as e:
        if upgrade:
            upgrade.log(str(e))
        print('Upgrade Failed: %s' % str(e))
        sys.exit(1)



