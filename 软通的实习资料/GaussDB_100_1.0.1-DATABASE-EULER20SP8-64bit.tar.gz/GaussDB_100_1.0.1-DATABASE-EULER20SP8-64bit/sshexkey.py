#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Perform hot backups of GaussDB100 databases.
# Copyright © Huawei Technologies Co., Ltd. 2010-2018. All rights reserved.

import sys
try:
    import os
    import getopt
    import socket
    import platform
    from funclib import exec_popen, get_error_msg, CommonValue, check_path
except ImportError as err:
    sys.exit("Unable to import module: %s." % str(err))
sys.dont_write_bytecode = True

home_dir = os.getenv("HOME")
if not check_path(home_dir):
    sys.exit("Home path '%s' is invalid." % home_dir)

SSH_DIR = "%s/.ssh" % home_dir
SSH_PUB_KEY_FILE = "%s/.ssh/id_rsa.pub" % home_dir
SSH_PRI_KEY_FILE = "%s/.ssh/id_rsa" % home_dir
SSH_AUTH_FILE = "%s/.ssh/authorized_keys" % home_dir


def usage():
    """
sshexkey.py is utility for create trust for user between different hosts 

Usage:
    python sshexkey.py --check
    python sshexkey.py -h IP1[,IP2,...]
    python sshexkey.py -f IPFILE
    python sshexkey.py -h IP1[,IP2,...] --cleanup

Common Options:
    -h          ip list for hosts
    -f          ip list for hosts in file
    --check     check user trust exist or not
    --cleanup   delete trust for user
    """


python_verion = platform.python_version()


class SshExkeyException(Exception):
    """
    Exception for sshexkey
    """
    pass


class SshExkey:
    """
    class for sshexkey
    """
    def __init__(self):
        """
        construct function
        """
        self.action = "create"
        self.pub_key = ""
        self.local_ip = ""
        self.ips = []

    def run(self):
        """
        main entry for sshexkey
        """
        self.__parse_parameter()
        if self.action == "cleanup":
            self.__clean_sshkey()
        elif self.action == "check":
            self.__check()
        else:
            self.__generate_sshkey()

    def __check(self):
        """
        """
        if self.__trust_exist():
            print("User trust is exist.")
        else:
            print("User trust is not exist")

    def __clean_sshkey(self):
        """
        clean sshkey
        """
        print("Clean user trust.")
        cmd = "rm -rf %s" % SSH_DIR
        for ip in self.ips:
            if ip == self.local_ip or ip == '127.0.0.1':
                continue
            ssh_cmd = "ssh %s '%s'" % (ip, cmd)
            ret_code, stdout, stderr = exec_popen(ssh_cmd)
            if ret_code:
                output = get_error_msg(stdout, stderr)
                raise SshExkeyException("Clean remote user trust failed: %s" % output)
        ret_code, stdout, stderr = exec_popen(cmd)
        if ret_code:
            output = get_error_msg(stdout, stderr)
            raise SshExkeyException("Clean local user trust failed: %s" % output)
        print("Clean user turst succeed.")

    def __generate_sshkey(self):
        """
        generate sshkey
        """
        print("Creating user trust.")
        self.__check_env()
        self.__sshexkey_for_local()
        self.__sshexkey_for_remote()
        print("Creating user trust succeed.")

    def __parse_parameter(self):
        """
        parse command line parameter
        """
        if "--help" in sys.argv[1:]:
            usage()
            sys.exit(0)

        try:
            opts, args = getopt.getopt(sys.argv[1:], "h:f:", ["cleanup", "check"])
        except getopt.GetoptError as err:
            raise SshExkeyException(str(err))

        if args:
            sys.exit("Error: Parameter input error: " + str(args[0]))

        for _key, _value in opts:
            if _key == "-h":
                self.__set_ips(_value)
            elif _key == "-f":
                self.__set_ips_from_file(_value)
            elif _key == "--cleanup":
                self.action = "cleanup"
            elif _key == "--check":
                self.action = "check"

    def __set_ips_from_file(self, fname):
        """
        """
        ip_file = os.path.realpath(fname)
        if not os.path.exists(ip_file):
            raise SshExkeyException("IP file %s is not exists" % ip_file)
        try:
            with open(ip_file, "r") as fd:
                self.ips = [ip.strip('\n') for ip in fd.readlines()]

        except IOError as err:
            raise SshExkeyException(str(err))
        
    def __set_ips(self, ips):
        """
        """
        self.ips = ips.strip().split(',')
        self.local_ip = self.ips[0]

    def __check_env(self):
        """
        """
        print("Check environment.")
        for ip in self.ips:
            self.__check_ip_valid(ip)

    def __check_ip_valid(self, ip):
        """
        """
        try:
            socket.inet_aton(ip)
            IPV_TYPE = "ipv4"
        except socket.error:
            try:
                socket.inet_pton(socket.AF_INET6, ip)
                IPV_TYPE = "ipv6"
            except socket.error:
                pass
        if IPV_TYPE == "ipv6":
            ping_cmd = "ping6"
        else:
            ping_cmd = "ping"
        # use ping command to chech the the ip, if no package lost,
        # the ip is valid
        cmd = "%s %s -i 1 -c 3 |grep ttl |wc -l" % (ping_cmd,ip)
        ret_code, stdout, _ = exec_popen(cmd)
        if ret_code or stdout != '3':
            print("The invalid IP is '%s'." % ip)


    def __sshexkey_for_local(self):
        """
        create trust for local
        """
        print("Generate ssh key for local host.")
        if not self.__trust_exist():
            self.__generate_new_key()
        else:
            self.__set_pub_key()
        print("Generate ssh key for local host succeed.")

    def __set_pub_key(self):
        """
        """
        try:
            with open(os.path.realpath(SSH_PUB_KEY_FILE), "r") as fd:
                self.pub_key = fd.readline().strip()
        except IOError as err:
            raise SshExkeyException(str(err))

    def __generate_new_key(self):
        """
        generate new ssh key
        """
        cmd = "ssh-keygen -t rsa -N \"\" -f %s < /dev/null" % SSH_PRI_KEY_FILE
        ret_code, output, errput = exec_popen(cmd)
        if ret_code:
            output = get_error_msg(output, errput)
            raise SshExkeyException("Execute ssh-keygen failed: " + output)
        self.__set_pub_key()

    def __trust_exist(self):
        """
        check trust exists in the hosts
        """
        pri_key_exsit = os.path.exists(SSH_PRI_KEY_FILE)
        pub_key_exsit = os.path.exists(SSH_PUB_KEY_FILE)
        if pri_key_exsit and pub_key_exsit:
            return True
        elif (not pri_key_exsit) and (not pub_key_exsit):
            return False
        else:
            raise SshExkeyException("Unsure if you have created a trust or not")


    def __sshexkey_for_remote(self):
        """
        create trust for remote
        """
        print("Generate ssh key for remote host.")
        cmd = "mkdir -p %s;" % SSH_DIR
        cmd +="chmod %s %s;" % (CommonValue.KEY_DIRECTORY_MODE, SSH_DIR)
        cmd += "echo %s >> %s;" % (self.pub_key, SSH_AUTH_FILE)
        cmd += "chmod %s %s/*'" % (CommonValue.KEY_FILE_MODE, SSH_DIR)

        for ip in self.ips:
            ssh_cmd = "ssh %s '%s" % (ip, cmd)
            ret_code, stdout, stderr = exec_popen(ssh_cmd)
            if ret_code:
                output = get_error_msg(stdout, stderr)
                raise SshExkeyException("Genreate ssh key for %s failed: %s" %(ip, output))
        print("Generate ssh key for remote host succeed.")


if __name__ == '__main__':
    ssh_exkey = SshExkey()
    try:
        ssh_exkey.run()
        sys.exit(0)
    except SshExkeyException as err:
        print(str(err))
        sys.exit(1)
