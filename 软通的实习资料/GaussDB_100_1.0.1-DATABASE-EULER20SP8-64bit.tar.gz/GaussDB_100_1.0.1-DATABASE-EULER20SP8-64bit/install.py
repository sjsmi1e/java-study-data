#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Perform hot backups of GaussDB100 databases.
# Copyright © Huawei Technologies Co., Ltd. 2010-2018. All rights reserved.


import sys
try:
    import getopt
    import getpass
    import grp
    import os
    import platform
    import pwd
    import re
    import shutil
    import socket
    import stat
    import socket
    import subprocess
    import time
    import tarfile
    import warnings
    from funclib import CommonValue

    PYTHON242 = "2.4.2"
    PYTHON25 = "2.5"
    gPyVersion = platform.python_version()

    if PYTHON242 <= gPyVersion < PYTHON25:
        import sha256
    elif gPyVersion >= PYTHON25:
        import hashlib
    else:
        print("This install script can not support python version: %s"
              % gPyVersion)
        sys.exit(1)
except ImportError as err:
    sys.exit("Unable to import module: %s." % str(err))


CURRENT_OS = platform.system()


class Options(object):
    """
    command line options
    """
    def __init__(self):
        self.log_file = ""
        self.install_user_privilege = ""
        self.opts = []

        # Database username and password are required after disabling
        # confidential login
        self.db_user = ""
        self.db_passwd = ""

        # User info
        self.os_user = ""
        self.os_group = ""

        # The object of opened log file.
        self.fp = None


g_opts = Options()


def check_invalid_symbol(para):
    """
    If there is invalid symbol in parameter?
    :param para: parameter's value
    :return: NA
    """
    symbols = ["|", ";", "&", "$", "&&", "||", ">", "<", ">>", "'"]
    for symbol in symbols:
        if para.find(symbol) > -1:
            print("There is invalid symbol \"%s\" in %s" % (symbol, para))
            sys.exit(1)


def all_zero_addr_after_ping(nodeIp):
    """
    check ip is all 0
    :param nodeIp: ip addr
    :return: bool
    """
    if not nodeIp:
        return False
    allowed_chars = set('0:.')
    if set(nodeIp).issubset(allowed_chars):
        return True
    else:
        return False


def checkPath(path_type_in):
    """
    Check the validity of the path.
    :param path_type_in: path
    :return: weather validity
    """
    path_len = len(path_type_in)
    i = 0
    a_ascii = ord('a')
    z_ascii = ord('z')
    A_ascii = ord('A')
    Z_ascii = ord('Z')
    num0_ascii = ord('0')
    num9_ascii = ord('9')
    blank_ascii = ord(' ')
    sep1_ascii = ord(os.sep)
    sep2_ascii = ord('_')
    sep3_ascii = ord(':')
    sep4_ascii = ord('-')
    sep5_ascii = ord('.')
    if CURRENT_OS == "Linux":
        for i in range(0, path_len):
            char_check = ord(path_type_in[i])
            if(not (a_ascii <= char_check <= z_ascii
                    or A_ascii <= char_check <= Z_ascii
                    or num0_ascii <= char_check <= num9_ascii
                    or char_check == blank_ascii
                    or char_check == sep1_ascii
                    or char_check == sep2_ascii
                    or char_check == sep4_ascii
                    or char_check == sep5_ascii)):
                return False
    elif CURRENT_OS == "Windows":
        for i in range(0, path_len):
            char_check = ord(path_type_in[i])
            if(not (a_ascii <= char_check <= z_ascii
                    or A_ascii <= char_check <= Z_ascii
                    or num0_ascii <= char_check <= num9_ascii
                    or char_check == blank_ascii
                    or char_check == sep1_ascii
                    or char_check == sep2_ascii
                    or char_check == sep3_ascii
                    or char_check == sep4_ascii)):
                return False
    else:
        print("Error: Can not support this platform.")
        sys.exit(1)
    return True


def _exec_popen(cmd):
    """
    subprocess.Popen in python2 and 3.
    :param cmd: commands need to execute
    :return: status code, standard output, error output
    """
    bash_cmd = ["bash"]
    pobj = subprocess.Popen(bash_cmd, shell=False, stdin=subprocess.PIPE,
                            stdout=subprocess.PIPE, stderr=subprocess.PIPE)

    if gPyVersion[0] == "3":
        stdout, stderr = pobj.communicate(cmd.encode())
        stdout = stdout.decode()
        stderr = stderr.decode()
    else:
        stdout, stderr = pobj.communicate(cmd)

    if stdout[-1:] == os.linesep:
        stdout = stdout[:-1]
    if stderr[-1:] == os.linesep:
        stderr = stderr[:-1]

    return pobj.returncode, stdout, stderr


def _get_input(msg):
    """
    Packaged function about user input which dialect with Python 2
    and Python 3.
    :param msg: input function's prompt message
    :return: the input value of user
    """
    if gPyVersion[0] == "3":
        return input(msg)
    return raw_input(msg)


def check_platform():
    """
    check platform

    Currently only supports Linux platforms.
    """
    if CURRENT_OS is None or not CURRENT_OS.strip():
        print("Can not get platform information.")
        sys.exit(1)
    if CURRENT_OS == "Linux":
        pass
    else:
        print("This install script can not support %s platform." % CURRENT_OS)
        sys.exit(1)


def usage():
    """install.py is a utility to install zengine server.

Usage:
  python install.py --help
  python install.py -U user:group -R installpath -D DATADIR [-O] [-C PARAMETER=VALUE] [-g withoutroot] [-f SQLFILE]
  python install.py -U user:group -R installpath -D DATADIR [-O] [-C 'PARAMETER=VALUE'] [-g withoutroot] [-f SQLFILE]
  python install.py -U user:group -R installpath -D DATADIR [-O] [-C \"PARAMETER=VALUE\"] [-g withoutroot] [-f SQLFILE]

Common options:
  -U        the database program and cluster owner
  -R        the database program path
  -O        only install database program, and omit other optional parameters
  -D        location of the database cluster storage area
  -g        run install script without root privilege, but you must have permission of installation folder
            note: use \"-g withoutroot\" exactly
  -C        configure the database cluster config, for more detail information see
  -l        specify the zengine install log file path and name, if not, use the default
  -X        sql dialect is enabled by default, specify the option to disable it(not recommended)
  -P        if sysdba login is disabled by configuration, specify this option at the end
  -f        specify a customized create database sql file. if not, use default sql file.
  --help    show this help, then exit

If all the optional parameters are not specified, -O option will be used.
    """
    print(usage.__doc__)


def parse_parameter():
    """
    parse parameters
    -U: username and group
    -R: install path
    -D: data path
    -C: kernel parameter
    -O: don't create database
    -P: used when sysdba is disabled
    -X: to disable sql dialect
    -l: log file
    -g: no-root user to install
    """
    try:
        # Parameters are passed into argv. After parsing, they are stored
        # in opts as binary tuples. Unresolved parameters are stored in args.
        opts, args = getopt.getopt(sys.argv[1:], "U:R:OD:C:g:l:XPf:", ["help"])
        if args:
            print("Parameter input error: " + str(args[0]))
            exit(1)

        # If there is "--help" in parameter, we should print the usage and
        # ignore other parameters.
        for _key, _value in opts:
            if _key == "--help":
                usage()
                print("End check parameters")
                exit(0)

        for _key, _value in opts:
            if _key == "-g":
                if os.getuid():
                    g_opts.install_user_privilege = _value
            elif _key == "-l":
                g_opts.log_file = _value.strip()
            # Get the user name and user group
            elif _key == "-U":
                _value = _value.strip()
                user_info = _value.split(":")
                if len(user_info) != 2 or not user_info[0] or not user_info[1]:
                    print("Parameter input error: -U " + _value)
                    exit(1)
                # The username and user group can't have invalid symbol.
                check_invalid_symbol(user_info[0])
                g_opts.os_user = user_info[0]
                check_invalid_symbol(user_info[1])
                g_opts.os_group = user_info[1]

        g_opts.opts = opts
    except getopt.GetoptError as err:
        print("Parameter input error: " + err.msg)
        sys.exit(1)


def check_parameter():
    """
    check parameter
    """

    if g_opts.install_user_privilege != "withoutroot":
        if os.getuid():
            print("Error: User has no root privilege, do install, need specify parameter '-g withoutroot'.")
            sys.exit(1)

    # Check the log path.
    if g_opts.log_file:
        g_opts.log_file = os.path.realpath(os.path.normpath(g_opts.log_file))
        base_name = os.path.basename(g_opts.log_file)
        dir_path = os.path.dirname(g_opts.log_file)

        if not os.path.isdir(dir_path):
            g_opts.log_file = ""
            print("Specified log path: \"%s\" does not exist, "
                  "choose the default path instead." % dir_path)
        elif not base_name:
            g_opts.log_file = ""
            print("Log file does not been specified, "
                  "choose the default logfile instead.")

    # Use the default log path.
    if not g_opts.log_file:
        # if install with -g parameter the default log
        # is ~/zengineinstall.log or the default is
        # /var/log/zengineinstall.log
        if g_opts.install_user_privilege == "withoutroot":
            cmd = "echo ~"
        else:
            cmd = "su - %s -c \"echo ~\"" % g_opts.os_user
        ret_code, stdout, _ = _exec_popen(cmd)
        if ret_code:
            print("Can not get user home, command: %s" % cmd)
            sys.exit(1)
        if not os.path.exists(os.path.realpath(stdout)):
            print("Cant get the home path of current user.")
            sys.exit(1)
        g_opts.log_file = os.path.join(os.path.realpath(os.path.normpath(stdout)), "zengineinstall.log")

    # Check the legitimacy of the path logfile
    if not checkPath(g_opts.log_file):
        print("Error: There is invalid character in specified log file.")
        sys.exit(1)
    if os.path.exists(g_opts.log_file):
        try:
            os.chmod(g_opts.log_file, stat.S_IWUSR + stat.S_IRUSR)
            os.remove(g_opts.log_file)
        except OSError as ex:
            print("Error: Can not remove log file: " + g_opts.log_file)
            print(str(ex))
            sys.exit(1)

    try:
        g_opts.fp = open(g_opts.log_file, "w")
    except IOError as err:
        print("Error: Can not create or open log file: " + g_opts.log_file)
        print(str(err))
        sys.exit(1)

    try:
        os.chmod(g_opts.log_file, stat.S_IWUSR + stat.S_IRUSR)
    except OSError as err:
        print("Error: Can not change the mode of log file: " + g_opts.log_file)
        print(str(err))
        sys.exit(1)


def log(msg, is_screen=False):
    """
    Print log
    :param msg: log message
    :return: NA
    """
    if is_screen:
        print(msg)

    if g_opts.fp:
        g_opts.fp.write(time.strftime("[%Y-%m-%d %H:%M:%S] ") + msg)
        g_opts.fp.write(os.linesep)
        # Flush the log from cache to file.
        g_opts.fp.flush()


def logExit(msg):
    """
    Print log and exit
    :param msg: log message
    :return: NA
    """
    log("Error: " + msg)
    print("Error: " + msg)

    if g_opts.fp:
        g_opts.fp.flush()
        # before exit, we must close the log file.
        g_opts.fp.close()
        os.chmod(g_opts.log_file, stat.S_IRUSR)
        g_opts.fp = None

    print("Please refer to install log \"%s\" for more detailed information."
          % g_opts.log_file)
    sys.exit(1)


class Installer:
    """ This  is Zengine installer. """

    # Defining a constant identifies which step the installer failed to take.
    # For roll back.
    FAILED_INIT = "0"
    DECOMPRESS_BIN_FAILED = "1"
    SET_ENV_FAILED = "2"
    PRE_DATA_DIR_FAILED = "3"
    INIT_DB_FAILED = "4"
    CREATE_DB_FAILED = "5"
    # Define the installation mode constant identifier
    INS_ALL = "all"
    INS_PROGRAM = "program"
    # Record the steps for the current operation to fail
    FAILED_POS = FAILED_INIT
    # Record running version number information
    # Initial value is "GAUSSDB100-V300R001C00-RUN"
    RUN_VERSION_A = "GAUSSDB100-V300R001C00-RUN"
    DIALECT_SCRIPT_PREFIX_A = "DIALECT-SCRIPT-3.1.0.0.0"

    # other version: GaussDB_100
    RUN_VERSION_B = "GaussDB_100_1.0.1-RUN"
    DIALECT_SCRIPT_PREFIX_B = "DIALECT-SCRIPT-GaussDB_100_1.0.1"

    # start mode
    NOMOUNT_MODE = "nomount"
    MOUNT_MODE = "mount"
    OPEN_MODE = "open"
    # configure file
    ZENGINE_CONF_FILE = "zengine.ini"
    ZENGINE_HBA_FILE = "zhba.conf"
    DEFAULT_INSTANCE_NAME = "zenith"
    # backup zengine install log dir
    backup_log_dir = ""

    LOGIN_IP = ""
    IPV_TYPE = "ipv4"

    def __init__(self, user, group):
        """ Constructor for the Installer class. """
        log("Begin init...")
        log("Installer runs on python version : " + gPyVersion)

        os.umask(0o22)

        # User
        self.user = user
        # Sysdba login enabled by default
        self.enableSysdbaLogin = True
        # Group
        self.group = group
        self.user_info = "%s:%s" % (self.user, self.group)
        # Install path
        self.installPath = ""
        # Option for installing program only or all.
        self.option = "program"
        self.flagOption = 0
        # old pgdata path
        self.oldDataPath = ""
        # Data path
        self.data = ""
        # DB config parameters
        self.confParameters = []
        self.dn_conf_dict = {}
        # run file
        self.runFile = ""
        # run package name
        self.run_pkg_name = ""
        # run MDf file
        self.runSha256File = ""
        # dialect tar package
        self.dialect_tar = ""

        self.lsnr_addr = ""
        self.lsnr_port = "1611"
        self.instance_name = self.DEFAULT_INSTANCE_NAME

        self.userHomePath = ""
        # dir path
        self.dirName = ""
        self.pid = 0

        # sql dialect enabled by default
        self.isDialect = True
        # create database sql that user specify
        self.create_db_file = ""

        #user profile
        self.userProfile = ""
        #flag for creating program dir
        self.isMkdirProg = False
        #flag for creating data dir
        self.isMkdirData = False
        log("End init")

    def find_file(self, path, name_pattern):

        file_list = os.listdir(path)
        find_files = []
        for file_name in file_list:
            if re.match(name_pattern, file_name):
                find_files.append(file_name)

        if not find_files:
            return ''

        if len(find_files) > 1:
            raise Exception("More than one target found in %s: %s\n"
                            "Please remove the unused files." % (path, ' ;'.join(find_files)))
        # file exists, return absolute file name
        file_name = os.path.realpath(os.path.join(path, find_files[0]))
        if not os.path.isfile(file_name):
            raise Exception("%s is not file, please check your package." % file_name)
        return file_name

    def get_decompress_tarname(self, tar_file):
        '''
        decompress a.tar.gz, then get file name
        :return:
        '''
        # get real directory name in tar file
        tars = tarfile.open(tar_file)
        basename = tars.getnames()[0]
        tars.close()
        return basename

    def check_package(self):
        '''
        there are two package version, so we should check run, sha256 and dialect is matched.
        :return:
        '''

        run_package = os.path.basename(self.runFile)
        sha256_file = os.path.basename(self.runSha256File)
        dialect_package = ""

        # two package, index is 0 or -1, A version is standard
        run_index = run_package.find(self.RUN_VERSION_A)
        sha256_index = sha256_file.find(self.RUN_VERSION_A)
        index_list = [run_index, sha256_index]
        if self.dialect_tar:
            dialect_package = os.path.basename(self.dialect_tar)
            dialect_index = dialect_package.find(self.DIALECT_SCRIPT_PREFIX_A)
            index_list.append(dialect_index)
        # if package is right, index list is [0, 0, 0] or [-1,-1,-1]
        if len(set(index_list)) != 1:
            raise Exception("Error: [%s, %s, %s] version maybe not matched, please check your "
                            "package." % (run_package, sha256_file, dialect_package))

    def getRunPkg(self):
        """
        Get the database package.
        :return: NA
        """
        installFile = os.path.join(os.getcwd(), sys.argv[0])
        installFile = os.path.realpath(os.path.normpath(installFile))

        self.dirName = os.path.dirname(installFile)

        # In python3.7 the function platform.dist is not recommended, and
        # it will cause a warning. so we must inhibition it.
        with warnings.catch_warnings():
            warnings.filterwarnings("ignore", category=DeprecationWarning)
            distname, _, _ = platform.dist()
        bits, _ = platform.architecture()

        # get run.tar.gz package
        run_pattern = "^(%s|%s).*-64bit.tar.gz$" % (self.RUN_VERSION_A, self.RUN_VERSION_B)
        self.runFile = self.find_file(self.dirName, run_pattern)
        if not self.runFile:
            raise Exception("Can not get correct run package in path %s" % self.dirName)
        # get run.sha256 file
        sha256_pattern = "^(%s|%s).*-64bit.sha256$" % (self.RUN_VERSION_A, self.RUN_VERSION_B)
        self.runSha256File = self.find_file(self.dirName, sha256_pattern)
        if not self.runSha256File:
            raise Exception("Can not get correct sha256 file in path %s" % self.dirName)
        # get run file name without suffix
        # compress package name is run.tar.gz, decompress is run, remove .tar.gz
        self.run_pkg_name = self.get_decompress_tarname(self.runFile)
        # check os version of package is mattched with current os version
        if self.run_pkg_name.find(distname.upper().replace("OS", "")) == -1:
            logExit("Run package %s.tar.gz is inconsistent with os system %s." % (self.run_pkg_name, distname))

        # get dialect tar package
        dialect_pattern = "^(%s|%s).tar.gz" % (self.DIALECT_SCRIPT_PREFIX_A, self.DIALECT_SCRIPT_PREFIX_B)
        self.dialect_tar = self.find_file(os.path.dirname(self.dirName), dialect_pattern)

        # check run, sha256, dialect is matched
        self.check_package()

        log("Using run file as : %s" % self.runFile)

    def is_readable(self, file_name, user):
        '''
        :param path:
        :param user:
        :return:
        '''
        user_info = pwd.getpwnam(user)
        uid = user_info.pw_uid
        gid = user_info.pw_gid
        s = os.stat(file_name)
        mode = s[stat.ST_MODE]
        return (
                ((s[stat.ST_UID] == uid) and (mode & stat.S_IRUSR > 0)) or
                ((s[stat.ST_GID] == gid) and (mode & stat.S_IRGRP > 0)) or
                (mode & stat.S_IROTH > 0)
        )

    def checkCreatedbFile(self):
        '''
        check it is a file; user has read permission,
        :return:
        '''
        # check -f parameter
        if self.create_db_file:
            if self.option != self.INS_ALL:
                raise Exception("Error: -f parameter should be used without -O parameter ")
            # check it is a file
            if not os.path.isfile(self.create_db_file):
                raise Exception("Error: %s does not exists or is not a file or "
                                "permission is not right." % self.create_db_file)
            if not checkPath(self.create_db_file):
                raise Exception("Error: %s file path invalid: " % self.create_db_file)
            # if execute user is root, check common user has read permission
            file_path = os.path.dirname(self.create_db_file)

            # check path of create db sql file that user can cd
            permission_ok, _ = self.checkPermission(file_path, True)
            if not permission_ok:
                raise Exception("Error: %s can not access %s" % (self.user, file_path))

            # check create db file is readable for user
            if not self.is_readable(self.create_db_file, self.user):
                raise Exception("Error: %s is not readable for user %s" % (self.create_db_file, self.user))
            # change file to a realpath file
            self.create_db_file = os.path.realpath(self.create_db_file)

    def checkParameter(self):
        """
        Detect the legality of input parameters, and return process if not legal.
        :return: NA
        """
        log("Checking parameters.", True)
        for key, value in g_opts.opts:
            # Get the app path.
            if key == "-R":
                self.installPath = value.strip()
            elif key == "-O":
                self.option = self.INS_PROGRAM
                self.flagOption = 1
            elif key == "-X":
                self.isDialect = False
            # Get the datadir
            elif key == "-D":
                self.data = value.strip()
                if self.flagOption == 0:
                    self.option = self.INS_ALL
                if self.flagOption == 1:
                    self.option = self.INS_PROGRAM
            # Get the kernel parameter
            elif key == "-C":
                self.confParameters.append(value)
            elif key == "-P":
                print("Need database connector's name and password:")
                g_opts.db_user = _get_input("Username:")
                # The db_passwd is only used to splice the zsql command.
                # For the request of secure coding, we must handle the
                # special symbol -- "'".
                g_opts.db_passwd = getpass.getpass().replace("'", "'\"'\"'")
            elif key in ["-g", "-l", "-U"]:
                pass
            elif key == "-f":
                self.create_db_file = value.strip()
            else:
                logExit("Parameter input error: %s." % value)

        if not self.installPath:
            logExit("Parameter input error, need -R parameter.")
        self.installPath = os.path.realpath(os.path.normpath(self.installPath))
        if not self.data:
            logExit("Parameter input error, need -D parameter.")
        self.data = os.path.realpath(os.path.normpath(self.data))

        # Check user
        if not self.user:
            logExit("Parameter input error, need -U parameter.")
        os.environ['zengine_user'] = str(self.user)
        # User must be exist.
        strCmd = "id -u ${zengine_user}"
        ret_code, _, _ = _exec_popen(strCmd)
        if ret_code:
            logExit("%s : no such user, command: %s" % (self.user, strCmd))

        if self.option == self.INS_ALL:
            # App data and inst data can't be the same one.
            if self.installPath == self.data:
                logExit("Program path should not equal to data path!")
            elif self.installPath.find(self.data + os.sep) == 0:
                logExit("Can not install program under data path!")
            elif self.data.find(self.installPath + os.sep) == 0:
                logExit("Can not install data under program path!")
            else:
                log("Program path is separated with data path!")

        # Check the app path
        if not checkPath(self.installPath):
            logExit("Install program path invalid: " + self.installPath)
        # Check the data path
        if not checkPath(self.data):
            logExit("Install data path invalid: " + self.data)

        # check -f parameter
        self.checkCreatedbFile()

        # Print the result of parse.
        log("Using %s:%s to install database" % (self.user, self.group))
        log("Using install program path : %s" % self.installPath)
        log("Using option : " + self.option)
        log("Using install data path : %s" % self.data)
        log("Using set config parameters : " + str(self.confParameters))
        log("End check parameters.", True)

    def checkRunner(self):
        """
        The user currently running the script must be root or in root group,
        if not exit.
        :return: NA
        """

        log("Checking runner.", True)
        gid = os.getgid()
        uid = os.getuid()
        log("Check runner user id and group id is : %s, %s" % (str(uid), str(gid)))
        if(gid != 0 and uid != 0):
            logExit("Only user with root privilege can run this script")

        log("End check runner is root")

    def checkUser(self):
        """
        The user currently running the script must be root or in root group
        and must exists in reality, if not exit.
        :return: NA
        """

        log("Checking user.", True)
        # User can not be root.
        if self.user == "root":
            logExit("Can not install program to root user.")
        # User can not in root group.
        strCmd = "id -g %s | grep -q -w 0" % self.user
        log("Check user cmd: " + strCmd)
        ret_code, _, _ = _exec_popen(strCmd)
        if not ret_code:
            logExit("Can not install program to user with root privilege.")
        # User should be exist and in the group.
        strCmd = "id -gn " + self.user
        log("Check user cmd: " + strCmd)
        ret_code, stdout, _ = _exec_popen(strCmd)
        if ret_code:
            logExit("User not exist.")
        else:
            if stdout != self.group:
                logExit("User group get from \"%s\" is %s, which is not same as %s." % (strCmd, stdout, self.group))

        log("End check user.", True)

        # user and group is right, chown logfile to user
        self.chownLogFile()

    def chownLogFile(self):
        """
        chmod and chown log file
        :return:
        """
        try:
            if os.path.exists(g_opts.log_file):
                uid = pwd.getpwnam(self.user).pw_uid
                gid = grp.getgrnam(self.group).gr_gid
                os.chown(g_opts.log_file, uid, gid)
        except Exception as ex:
            logExit("Can not change log file's owner. Output:%s" % str(ex))

    ###########################################################################
    # Is there a database installed by the user? If right, raise error
    # and exit. Because each user is only allowed install one database by
    # this script.
    ###########################################################################
    def checkOldInstall(self):
        """
        Is there a database installed by the user?
        :return: NA
        """

        log("Checking old install.", True)

        #Check $GSDB_HOME.
        if(g_opts.install_user_privilege == "withoutroot"):
            strCmd = "echo ~"
        else:
            strCmd = "su - %s -c \"echo ~\"" % self.user
        ret_code, stdout, _ = _exec_popen(strCmd)
        if ret_code:
            logExit("Can not get user home.")
        # Get the profile of user.
        output = os.path.realpath(os.path.normpath(stdout))
        if (not checkPath(output)):
            logExit("The user home directory is invalid.")
        self.userProfile = os.path.join(output, ".bashrc")
        self.userHomePath = output
        log("Using user profile : " + self.userProfile)

 
        isFind = False
        try:
            with open(self.userProfile, "r") as _file:
                while True:
                    strLine = _file.readline()
                    if(not strLine):
                        break
                    strLine = strLine.strip()
                    if(strLine.startswith("#")):
                        continue
                    user_info = strLine.split()
                    # deal with the GSDB_DATA with """
                    if len(user_info)>= 2 and user_info[0] == "export" and user_info[1].startswith('GSDB_DATA="')>0:
                        self.oldDataPath = strLine[strLine.find("=")+2:-1]
                        self.oldDataPath = os.path.normpath(self.oldDataPath)
                        self.oldDataPath = os.path.realpath(self.oldDataPath)
                        if not checkPath(self.oldDataPath):
                            logExit("The Path specified by GSDB_DATA is invalid.")
                        log("Old data path: " + self.oldDataPath)
                        if self.option == self.INS_ALL and self.oldDataPath != self.data:
                            logExit("User GSDB_DATA is different from -D parameter value")
                    # deal with the GSDB_DATA path without """
                    elif len(user_info)>= 2 and user_info[0] == "export" and user_info[1].startswith("GSDB_DATA=")>0:
                        self.oldDataPath = strLine[strLine.find("=")+1:]
                        self.oldDataPath = os.path.normpath(self.oldDataPath)
                        self.oldDataPath = os.path.realpath(self.oldDataPath)
                        if (not checkPath(self.oldDataPath)):
                            logExit("The Path specified by GSDB_DATA is invalid.")
                        log("Old data path: " + self.oldDataPath)
                        if self.option == self.INS_ALL and self.oldDataPath != self.data:
                            logExit("User GSDB_DATA is different from -D parameter value")
                    if len(user_info)>= 2 and user_info[0] == "export" and user_info[1].startswith("GSDB_HOME=")>0:
                        isFind = True
                        break
                    else:
                        continue
        except IOError as ex:
            logExit("Can not read user profile: " + str(ex))
        except IndexError as ex:
            logExit("Failed to read user profile: %s" % str(ex))

        if isFind:
            logExit("Database has been installed already.")

        log("End check old install.", True)

    def prepareGivenPath(self, onePath, checkEmpty = True):
        """
        function:
            make sure the path exist and user has private to access this path
        precondition:
            1.checkEmpty is True or False
            2.path list has been initialized
        input:
            1.path list
            2.checkEmpty
            3.path owner

        for each path in the path list
            save the path
            if path exist
                if need check empty
                    check empty
            else
                find the top path to be created
            create the path
            chown owner
            check permission
            check path size
        """
        log("Preparing path [%s]." % onePath)
        ownerPath = onePath
        if(os.path.exists(onePath)):
            if(checkEmpty):
                fileList = os.listdir(onePath)
                if(len(fileList) != 0):
                    logExit("Database path %s should be empty." % onePath)
        else:
            while True:
                #find the top path to be created
                (ownerPath, dirName) = os.path.split(ownerPath)
                if (os.path.exists(ownerPath) or dirName == ""):
                    ownerPath = os.path.join(ownerPath, dirName)
                    break
            #create the given path
            log("Path [%s] does not exist. Please create it." % onePath)
            os.makedirs(onePath, 0o700)
            self.isMkdirProg = True

        #if the path already exist, just change the top path mode, else change mode with -R
        #do not change the file mode in path if exist
        #found error: given path is /a/b/c, script path is /a/b/c/d, then change mode with -R
        #will cause an error
        if ownerPath != onePath:
            cmd = "chown -R %s:%s %s; " % (self.user, self.group, ownerPath)
            cmd += "chmod -R %s %s" % (CommonValue.KEY_DIRECTORY_MODE, ownerPath)
        else:
            cmd = "chown %s:%s %s; " % (self.user, self.group, ownerPath)
            cmd += "chmod %s %s" % (CommonValue.KEY_DIRECTORY_MODE, ownerPath)

        log("cmd path %s" % cmd)
        ret_code, _, stderr = _exec_popen(cmd)
        if ret_code:
            logExit(" Command: %s. Error:\n%s" % (cmd, stderr))

        # check permission
        log("check [%s] user permission" % onePath)
        permission_ok, stderr = self.checkPermission(onePath)
        if not permission_ok:
            logExit("Failed to check user [%s] path [%s] permission. Error: %s"
                    % (self.user, onePath, stderr))

    def checkPermission(self, originalPath, check_enter_only=False):
        """
        function:
            check if given user has operation permission for given path
        precondition:
            1.user should be exist
            2.originalPath should be an absolute path
            3.caller should has root privilege
        postcondition:
            1.return True or False
        input : originalPath,check_enter_only
        output: True/False
        """
        # check the user has enter the directory permission or not
        if g_opts.install_user_privilege == "withoutroot":
            cmd = "cd %s" % originalPath
        else:
            cmd = "su - %s -c 'cd %s'" % (self.user, originalPath)

        status, _, stderr = _exec_popen(cmd)
        if status:
            return False, stderr

        if check_enter_only:
            return True, ""

        # check the user has write permission or not
        testFile = os.path.join(originalPath, "touch.tst")
        if g_opts.install_user_privilege == "withoutroot":
            cmd = "touch %s && chmod %s %s " % (testFile, CommonValue.MAX_FILE_MODE, testFile)
        else:
            cmd = "su - %s -c 'touch %s && chmod %s %s' " % (self.user, testFile, CommonValue.MAX_FILE_MODE, testFile)

        status, _, stderr = _exec_popen(cmd)
        if status != 0:
            return False, stderr
        if g_opts.install_user_privilege == "withoutroot":
            cmd = "echo aaa > %s " % (testFile)
        else:
            cmd = "su - %s -c 'echo aaa > %s' " % (self.user, testFile)

        # delete tmp file
        status, _, stderr = _exec_popen(cmd)
        if status != 0:
            cmd = "rm -f %s " % testFile
            _exec_popen(cmd)
            return False, stderr

        cmd = "rm -f %s " % testFile
        status, _, stderr = _exec_popen(cmd)
        if status != 0:
            return False, stderr

        return True, ""

    def checkDIR(self):
        """
        Check dir.

        1. Check the length of the directory entered by the user, and exit
           if it is longer than 110 characters.
        2. Check that the directory entered by the user is empty or does not
           exist, otherwise it will exit.
        3. Check if the size of the installation directory entered by the
           user is less than 100M. If it is less than, exit it.
        4. Check whether the database initialization directory entered by
           the user is less than 20G. If it is less than quit, the default
           template for building the library needs 20G to enter.
        5. Check that the installation directory entered by the user and
           the database initialization directory are on the same disk, and
           exit if the total size is less than 20580M.
        :return:
        """

        log("Checking directory.", True)
        # check if data or app path is too long(over 100 chars)
        if(len(self.data) >= 110 or len(self.installPath) >= 110):
            logExit("Install path or Data path is over 110 characters, exit.")
        #check install path is empty or not.
        self.prepareGivenPath(self.installPath)

        # check data dir is empty or not.
        self.prepareGivenPath(self.data)
        # check install path
        vfs = os.statvfs(self.installPath)
        availableSize = vfs.f_bavail * vfs.f_bsize / (1024*1024)
        log("Database program install path available size: %sM" % str(availableSize))
        if availableSize < 100:
            logExit("Database program install path available size smaller than 100M, current size is: %sM" % str(availableSize))
        # check data dir.
        if self.option == self.INS_ALL:
            # check partition of install path
            strCmd1 = "df -h \"%s\"" % self.installPath
            strCmd2 = "df -h \"%s\" | head -2" % self.installPath
            strCmd3 = "df -h \"%s\" | head -2 |tail -1" % self.installPath
            strCmd4 = "df -h \"%s\" | head -2 |tail -1 | awk -F\" \" '{print $1}'" % self.installPath

            cmds = [strCmd1, strCmd2, strCmd3, strCmd4]
            stdout = ""
            stdout_list = []
            for cmd in cmds:
                ret_code, stdout, stderr = _exec_popen(strCmd1)
                if ret_code:
                    logExit("Can not get the partition of path: %s "
                            "%scommand: %s. %sError: %s"
                            % (self.installPath, os.linesep,
                               cmd, os.linesep, stderr))
                stdout_list.append(stdout)
            log("The partition of path \"%s\": %s"
                % (self.installPath, stdout))

            # check partition of data dir
            strCmd5 = "df -h \"%s\"" % self.data
            strCmd6 = "df -h \"%s\" | head -2" % self.data
            strCmd7 = "df -h \"%s\" | head -2 |tail -1" % self.data
            strCmd8 = "df -h \"%s\" | head -2 |tail -1 | awk -F\" \" '{print $1}'" % self.data

            cmds = [strCmd5, strCmd6, strCmd7, strCmd8]
            stdout = ""
            for cmd in cmds:
                ret_code, stdout, stderr = _exec_popen(strCmd1)
                if ret_code:
                    logExit("Can not get the partition of path: %s "
                            "%scommand: %s. %sError: %s"
                            % (self.data, os.linesep,
                               cmd, os.linesep, stderr))
            log("The partition of path \"%s\": %s"
                % (self.data, stdout))

            vfs = os.statvfs(self.data)
            availableSize = vfs.f_bavail * vfs.f_bsize / (1024*1024)
            log("Database data directory available size: %sM" % str(availableSize))

            # check install path and data dir are in the same path or not
            if stdout_list[0] == stdout_list[1]:
                if(availableSize < 20580):
                    logExit("The sum of database program and data directories available size smaller than 20580M, "
                            "current size is: %sM" % str(availableSize))
            else:
                if(availableSize < 20480):
                    logExit("Database data directory available size smaller than 20480M, current size is: "
                            "%sM" % str(availableSize))
        log("End check dir.")

    #############################################################################
    # Check if the port is used in the installation parameters, and exit
    # if the port is used.
    #############################################################################
    def checkPort(self, value):
        """
        Check if the port is used in the installation parameters, and exit
        if the port is used.
        :param value: port
        :return: NA
        """
        # the value can't be empty and must be a digit.
        # the value must > 1023 and <= 65535
        TIME_OUT = 2
        check_invalid_symbol(value)
        if not value:
            logExit("the number of port is null.")
        if not value.isdigit():
            logExit("illegal number of port.")
        try:
            innerPort = int(value)
            if innerPort < 0 or innerPort > 65535:
                logExit("illegal number of port.")
            if innerPort >=0 and innerPort <= 1023:
                logExit("system reserve port.")
        except ValueError as ex:
            logExit("check port failed: " + str(ex))

        # Get the sokcet object
        if self.IPV_TYPE == "ipv6":
            sk = socket.socket(socket.AF_INET6, socket.SOCK_STREAM)
        else:
            sk = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

        # Test the socket connection.
        sk.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        sk.settimeout(TIME_OUT)

        try:
            sk.bind((self.LOGIN_IP, innerPort))
            sk.close()
        except socket.error as err:
            sk.close()
            if gPyVersion >= PYTHON242:
                try:
                    # 98: Address already in use
                    # 95: Operation not supported
                    # 13: Permission denied
                    if int(err.errno) == 98 or int(err.errno) == 95 or int(err.errno) == 13:
                        log("Error: port %s has been used,the detail information is as follows:" % value, True)
                        strCmd = "lsof -nPi:%s" % value
                        ret_code, stdout, _ = _exec_popen(strCmd)
                        if ret_code:
                            logExit("can not get detail information of the port, command: " + strCmd)
                        logExit(str(stdout))
                except ValueError as ex:
                    logExit("check port failed: " + str(ex))
            else:
                logExit("This install script can not support python version : " + gPyVersion)

    #############################################################################
    # Check if the port is used in the installation parameters, and exit
    # if the port is used.
    #############################################################################
    def checkIPisVaild(self, nodeIp):
        """
        function: Check the ip is vaild
        input : ip
        output: NA
        """
        check_invalid_symbol(nodeIp)
        try:
            socket.inet_aton(nodeIp)
            self.IPV_TYPE = "ipv4"
        except socket.error:
            try:
                socket.inet_pton(socket.AF_INET6, nodeIp)
                self.IPV_TYPE = "ipv6"
            except socket.error:
                logExit("The invalid IP:%s is not ipv4 or ipv6 format." % nodeIp)

        if self.IPV_TYPE == "ipv6":
            ping_cmd = "ping6"
        else:
            ping_cmd = "ping"
        # use ping command to chech the the ip, if no package lost,
        # the ip is valid
        cmd = "%s %s -i 1 -c 3 |grep ttl |wc -l" % (ping_cmd,nodeIp)
        ret_code, stdout, _ = _exec_popen(cmd)

        if all_zero_addr_after_ping(nodeIp):
            ip_is_found = 1
        elif len(nodeIp) != 0:
            ip_is_found = os.popen("ip addr |grep -w %s |wc -l" % nodeIp).read()
        else:
            ip_is_found = 0

        if ret_code or stdout != '3' or not int(ip_is_found):
            logExit("The invalid IP is '%s'." % nodeIp)

    ###########################################################################
    # Check the operating system kernel parameters and exit if they do
    # not meet the requirements of the database。
    ###########################################################################
    def checkConfigOptions(self):
        """
        Check the operating system kernel parameters and exit if they do
        not meet the requirements of the database。
        :return: NA
        """

        log("Checking kernel parameters.", True)
        #GB MB kB
        GB = 1024*1024*1024
        MB = 1024*1024
        KB = 1024
        # The size of database
        log_buffer_size = 4*MB
        shared_pool_size = 128*MB
        data_buffer_size = 128*MB
        temp_buffer_size = 32*MB
        sga_buff_size = log_buffer_size + shared_pool_size + data_buffer_size + temp_buffer_size

        # parse the value of kernel parameters
        for item in self.confParameters:
            _list = item.strip().split("=", 1)
            # The parameter must meets the format "key=value"
            if (2 != len(_list)):
                logExit("The invalid parameters %s" % item.strip())
            try:
                check_invalid_symbol(_list[0])
                check_invalid_symbol(_list[1])

                # Unit conversion
                if _list[0].lower() in ["temp_buffer_size", "data_buffer_size",
                                        "shared_pool_size", "log_buffer_size"]:
                    if (_list[1][0:-1].isdigit()
                            and _list[1][-1:] in ["G", "M", "K"]):
                        unit_map = {
                            "G": GB,
                            "M": MB,
                            "K": KB,
                        }
                        size_unit = unit_map[_list[1][-1:]]
                        sga_buff_size += int(_list[1][0:-1]) * size_unit

                if _list[0].lower() == "temp_buffer_size":
                    sga_buff_size -= temp_buffer_size
                if _list[0].lower() == "data_buffer_size":
                    sga_buff_size -= data_buffer_size
                if _list[0].lower() == "shared_pool_size":
                    sga_buff_size -= shared_pool_size
                if _list[0].lower() == "log_buffer_size":
                    sga_buff_size -= log_buffer_size

                if _list[0].lower() == "lsnr_addr":
                    self.lsnr_addr = _list[1]
                elif _list[0].lower() == "instance_name":
                    self.instance_name = _list[1]
                elif _list[0].lower() == "lsnr_port":
                    self.lsnr_port = _list[1]
                elif _list[0].lower() == "enable_sysdba_login":
                    if _list[1].lower() == "false":
                        self.enableSysdbaLogin = False
                    else:
                        self.enableSysdbaLogin = True
                else:
                    self.dn_conf_dict[_list[0]] = _list[1]
            except ValueError as ex:
                logExit("check kernel parameter failed: " + str(ex))

        if self.lsnr_addr != "":
            _list = self.lsnr_addr.split(",")
            # Check the ip address
            for item in _list:
                if len(_list) is not 1 and all_zero_addr_after_ping(item):
                    logExit("lsnr_addr contains all-zero ip, can not specify other ip.")
                self.checkIPisVaild(item)
        else:
            # If this parameter is empty, the IPv4 is used by default.
            # The default IP address is 127.0.0.1
            self.lsnr_addr = "127.0.0.1"

        self.LOGIN_IP =  self.lsnr_addr.split(",")[0]

        self.checkPort(self.lsnr_port)
        self.lsnr_port = int(self.lsnr_port)

        # check sga_buff_size
        strCmd = "cat /proc/meminfo"
        ret_code, cur_avi_memory, _ = _exec_popen(strCmd)
        if ret_code:
            logExit("can not get shmmax parameters, command: %s" % strCmd)
        cur_avi_memory = os.popen("cat /proc/meminfo  |grep -wE 'MemFree:|Buffers:|Cached:|SwapCached' |awk '{sum += $2};END {print sum}'").read()
        if sga_buff_size < 114*MB:
            logExit("sga_buff_size should bigger than or equal to 114*MB, please check it!")
        try:
            if sga_buff_size > int(cur_avi_memory)*KB:
                logExit("sga_buff_size should smaller than shmmax, please check it!")
        except ValueError as ex:
            logExit("check kernel parameter failed: " + str(ex))

        log("End check kernel parameters")

    def checkSHA256(self):
        """
        Verify the integrity of the bin file, exit if it is not complete
        :return: NA
        """

        log("Checking integrality of run file...", True)
        if(self.runFile == ""):
            logExit("Can not find run file.")
        if(self.runSha256File == ""):
            logExit("Can not find verification file.")
        _file = None
        sha256Obj = None
        oldSHA256 = ""
        strSHA256 = ""
        isSameSHA256=False
        try:
            with open(self.runFile, "rb") as _file:
                # Use sha256 when python version is lower higher 2.4 and
                # lower than 2.5.
                if(gPyVersion >= PYTHON242 and gPyVersion < PYTHON25):
                    sha256Obj = sha256.new()
                # Use hash when python version is higher than 2.5
                elif(gPyVersion >= PYTHON25):
                    sha256Obj = hashlib.sha256()
                if(sha256Obj == None):
                    logExit("check integrality of bin file failed, can not get verification Obj.")
                while True:
                    strRead = _file.read(8096)
                    if(not strRead):
                        break
                    sha256Obj.update(strRead)
                strSHA256 = sha256Obj.hexdigest()
                with open(self.runSha256File, "r") as fileSHA256:
                    strRead = fileSHA256.readline()
                    oldSHA256 = strRead.strip()
                    if(strSHA256 == oldSHA256):
                        isSameSHA256 = True
                    else:
                        isSameSHA256 = False
        except IOError as ex:
            logExit("Check integrality of bin file except: " + str(ex))

        if (isSameSHA256 == True):
            log("Check integrality of bin file ok")
        else:
            logExit("Check integrality of bin file failed")
        log("End check integrality of bin file")

    def changeAppPermission(self):
        """
        function: after decompression install package, change file permission
        input : NA
        output: NA
        """
        # change install path privilege to 700
        strCmd = "chmod %s %s -R" % (CommonValue.KEY_DIRECTORY_MODE, self.installPath)
        # chmod add-ons/ file 500
        strCmd += "&& find '%s'/add-ons -type f | xargs chmod %s " % (self.installPath, CommonValue.MID_FILE_MODE)
        # chmod admin/ file 600
        strCmd += "&& find '%s'/admin -type f | xargs chmod %s " % (self.installPath, CommonValue.KEY_FILE_MODE)
        # chmod lib/ file 500
        strCmd += "&& find '%s'/lib -type f | xargs chmod %s" % (self.installPath, CommonValue.MID_FILE_MODE)
        # chmod bin/ file 500
        strCmd += "&& find '%s'/bin -type f | xargs chmod %s " % (self.installPath, CommonValue.MID_FILE_MODE)
        package_xml = os.path.join(self.installPath, "package.xml")
        if os.path.exists(package_xml):
            strCmd += "&& chmod %s '%s'/package.xml" % (CommonValue.MIN_FILE_MODE, self.installPath)

        log("Change app permission cmd: %s" % strCmd)
        ret_code, _, stderr = _exec_popen(strCmd)
        if ret_code:
            self.FAILED_POS = self.DECOMPRESS_BIN_FAILED
            self.rollBack()
            logExit("chmod %s return: " % CommonValue.KEY_DIRECTORY_MODE + str(ret_code) + os.linesep + stderr)

    def copyDialectScripts(self):
        """
        function: decompress DIALECT package, cp files to admin/scripts/sql_dialect
        input : NA
        output: NA
        """
        if not self.dialect_tar:
            log("Warning: Dialect Scripts not found! But still proceed installation", True)
            return

        dialect_file_name = self.get_decompress_tarname(self.dialect_tar)
        dialect_sql = os.path.join(self.dirName, dialect_file_name)
        strCmd = "tar -xvf %s" % self.dialect_tar
        strCmd += " && cp -rf %s/* %s/admin/scripts/sql_dialect/" % (
            dialect_sql, self.installPath)
        strCmd += " && rm -rf %s" % dialect_sql
        log("copy dialect sql scripts cmd: " + strCmd)

        ret_code, stdout, stderr = _exec_popen(strCmd)
        if ret_code:
            self.FAILED_POS = self.DECOMPRESS_BIN_FAILED
            self.rollBack()
            logExit("Decompress bin (copy dialect scripts) return: %s%sSTDOUT: %s%sSTDERR: %s"
                    % (ret_code, os.linesep, stdout, os.linesep, stderr))

    #############################################################################
    # Unzip the installation files to the installation directory.
    #############################################################################
    def decompressBin(self):
        """
        Unzip the installation files to the installation directory.
        :return: NA
        """

        log("Decompressing run file.", True)

        #let bin executable
        strCmd = "chmod %s \"%s\"" % (CommonValue.KEY_DIRECTORY_MODE, self.runFile)
        log("decompress bin file executable cmd: %s" % strCmd)
        ret_code, _, stderr = _exec_popen(strCmd)
        if ret_code:
            self.FAILED_POS = self.DECOMPRESS_BIN_FAILED
            self.rollBack()
            logExit("decompress bin file executable return: %s%s%s" % (str(ret_code), os.linesep, stderr))
        #decompress bin file.
        zenith_pkg_file = "%s/%s" % (self.installPath, self.run_pkg_name)
        strCmd = "tar -xvf \"%s\" -C \"%s\"" % (self.runFile, self.installPath)
        strCmd = "%s && cp -rf %s/add-ons %s/admin %s/bin %s/cfg %s/lib %s/package.xml  %s" % (
                strCmd, zenith_pkg_file, zenith_pkg_file, zenith_pkg_file, zenith_pkg_file, zenith_pkg_file,
                zenith_pkg_file, self.installPath)
        strCmd += " && rm -rf %s" % zenith_pkg_file
        log("Decompress cmd: " + strCmd)
        ret_code, _, stderr = _exec_popen(strCmd)
        if ret_code:
            self.FAILED_POS = self.DECOMPRESS_BIN_FAILED
            self.rollBack()
            logExit("Decompress bin return: " + str(ret_code) + os.linesep + stderr)

        # ater decompress app, check package is green or not
        ora_dialect_sql = os.path.join(self.installPath, "admin/scripts/sql_dialect/ora-dialect.sql")
        if os.path.exists(ora_dialect_sql):
            # database package is green package
            log("%s file exists in package %s" % (ora_dialect_sql, self.runFile))
        else:
            if self.isDialect:
                self.copyDialectScripts()
        log("Successfully Install zenith application")

        # in some system(such as euler2.0 SP8): logger depend the libuuid library,
        # but the lib provide by zenith is not match with the one provide by system,
        # so we choose the high version by remove the link of low version library
        self.check_uuid_lib()

        # change app permission
        self.changeAppPermission()

        # change owner to user:group
        strCmd = "chown %s:%s -R %s " % (self.user, self.group, self.installPath)
        # Change the owner
        log("Change owner cmd: %s" % strCmd)
        ret_code, _, stderr = _exec_popen(strCmd)
        if ret_code:
            self.FAILED_POS = self.DECOMPRESS_BIN_FAILED
            self.rollBack()
            logExit("chown to %s: %s return: %s%s%s" % (self.user, self.group, str(ret_code), os.linesep, stderr))

        log("End decompress bin file.")

    def _get_uuid_version(self, uuid_lib):
        """
        function: get real libuuid version, such as 1.0.0,
        input: uuid lib file or link
        output: the version of uuid library
        """
        if os.path.islink(uuid_lib):
            uuid_lib_file = os.path.realpath(uuid_lib)
        else:
            uuid_lib_file = uuid_lib

        if uuid_lib_file.endswith('so') or uuid_lib_file.endswith('so.'):
            # libuuid.so or libuuid.so.
            lib_ver = ""
        else:
            # libuuid.so.x.y.z
            ver_idx = uuid_lib_file.rfind('so') + 3
            lib_ver = uuid_lib_file[ver_idx:]

        return lib_ver

    def check_uuid_lib(self):
        """
        function: check system libuuid version, if the version number
                  is great than that in zenith package, we use the system
                  libuuid avoid affecting system functions
        input: NA
        output: NA
        """
        my_uuid_lib = self.installPath + "/add-ons/libuuid.so.1"
        if not os.path.exists(my_uuid_lib):
            return
        my_uuid_lib_ver = self._get_uuid_version(my_uuid_lib)

        lib_paths = ["/usr/lib", "/usr/lib64", "/lib", "/lib64"]
        for lib in lib_paths:
            sys_uuid_lib = os.path.join(lib, "libuuid.so.1")
            if not os.path.exists(sys_uuid_lib):
                continue
            sys_uuid_lib_ver = self._get_uuid_version(sys_uuid_lib)
            if sys_uuid_lib_ver > my_uuid_lib_ver:
                os.remove(my_uuid_lib)
            break

    def setUserEnv(self):
        """
        Set the user's environment variables.

        The modification of Linux system:
            1. export PATH=the value of '-R'/bin:$PATH
            2. export LD_LIBRARY_PATH=the value of '-R'/lib:the value of '-R'/add-ons:$LD_LIBRARY_PATH
            3. export GSDB_DATA=the value of '-D'
            4. export GSDB_HOME=the value of '-D'
        :return: NA
        """

        log("Setting user env.", True)

        # set PATH, LD_LIBRARY_PATH

        try:
            with open(self.userProfile, "a") as _file:
                _file.write("export GSDB_HOME=\"%s\"" % self.installPath)
                _file.write(os.linesep)
                _file.write("export PATH=\"%s\":$PATH" % os.path.join(self.installPath,"bin"))
                _file.write(os.linesep)
                _file.write("export LD_LIBRARY_PATH=\"%s\":\"%s\":$LD_LIBRARY_PATH" 
                            % (os.path.join(self.installPath, "lib"), os.path.join(self.installPath, "add-ons")))
                _file.write(os.linesep)
                if(self.oldDataPath == ""):
                    #set GSDB_DATA
                    _file.write("export GSDB_DATA=\"%s\"" % self.data)
                    _file.write(os.linesep)
                _file.flush()
        except IOError as ex:
            self.FAILED_POS = self.SET_ENV_FAILED
            self.rollBack()
            logExit("Can not set user environment variables: %s" % str(ex))

        if g_opts.install_user_privilege == "withoutroot":
            os.environ['PATH'] = os.path.join(self.installPath, "bin") + ":"+ os.environ['PATH']
            # in some system LD_LIBRARY_PATH is not set, so must check it, or excetion will be raise
            if 'LD_LIBRARY_PATH' in os.environ:
                os.environ['LD_LIBRARY_PATH'] = "%s:%s:%s" % (os.path.join(self.installPath, "lib"), os.path.join(
                    self.installPath, "add-ons"), os.environ['LD_LIBRARY_PATH'])
            else:
                os.environ['LD_LIBRARY_PATH'] = "%s:%s" % (os.path.join(self.installPath, "lib"), os.path.join(
                    self.installPath, "add-ons"))
            os.environ["GSDB_HOME"] = self.installPath
            os.environ["GSDB_DATA"] = self.data

        log("End set user env.")

    def set_zenith_conf(self, param_dict, zenith_conf_file):
        """
        function: echo 'key:value' conf to zengine.ini file
        input : parameter dict,such as:{LSNR_PORT : 8000}, zengine.ini
        output: NA
        """
        cmd = ""
        # make the command of write the parameter
        for key in list(param_dict.keys()):
            cmd += "echo '%s = %s' >> %s;" % (key, param_dict[key], zenith_conf_file)

        if cmd:
            cmd = cmd.strip(";")
            ret_code, _, stderr = _exec_popen(cmd)
            if ret_code:
                raise Exception("Can not write the  %s, command: %s, output: %s" % (self.ZENGINE_CONF_FILE, cmd, stderr))

    def clean_old_conf(self, param_list, zenith_conf_file):
        """
        function: clean old conf in zengine.ini file
        input : parameter list, zengine.ini
        output: NA
        """
        cmd = ""
        # make the command of delete the parameter 
        for parameter in param_list:
            cmd += "sed -i '/^%s/d' %s;" % (parameter, zenith_conf_file)

        if cmd:
            cmd = cmd.strip(";")
            ret_code, _, stderr = _exec_popen(cmd)
            if ret_code:
                raise Exception("Can not write the  %s, command: %s, output: %s" % (self.ZENGINE_CONF_FILE, cmd, stderr))

    def set_common_conf(self):
        """
        function: set zenith common conf
        input : NA
        output: NA
        """
        zenith_conf_file = os.path.join(self.data, "cfg", self.ZENGINE_CONF_FILE)
        #Make sure this is a newline, when setting the first parameter
        cmd = "echo >> %s" % zenith_conf_file
        ret_code, _, stderr = _exec_popen(cmd)
        if ret_code:
            raise Exception("Can not write the  %s, command: %s, output: %s" % (self.ZENGINE_CONF_FILE, cmd, stderr))

        # Generate new kernel parameters
        common_parameters = {}
        common_parameters['LSNR_PORT'] = self.lsnr_port
        common_parameters['LSNR_ADDR'] = self.lsnr_addr
        common_parameters['INSTANCE_NAME'] = self.instance_name
        common_parameters['ENABLE_SYSDBA_LOGIN'] = str(self.enableSysdbaLogin).upper()

        #1.clean old conf
        self.clean_old_conf(list(common_parameters.keys()), zenith_conf_file)
        #2.set zenith conf
        self.set_zenith_conf(common_parameters, zenith_conf_file)

    def InitDbInstance(self):
        """
        Modify the database configuration file zengine.ini with the given
        parameters, which are specified by the -C parameter.
        :return: NA
        """

        log("Initialize db instance.", True)
        try:
            self.FAILED_POS = self.INIT_DB_FAILED
            self.set_common_conf()
            if len(self.dn_conf_dict) == 0:
                log("config Parameters is empty, so just return.")
                return

            #set dn private conf
            zenith_conf_file = os.path.join(self.data, "cfg", self.ZENGINE_CONF_FILE)
            #1.clean old dn conf
            self.clean_old_conf(list(self.dn_conf_dict.keys()), zenith_conf_file)
            #2.set dn conf
            self.set_zenith_conf(self.dn_conf_dict, zenith_conf_file)
        except Exception as err:
            self.rollBack()
            logExit(str(err))

        log("End init db instance")

    def genregstring(self, text):
        """
        Generates a regular expression string path return based on the
        passed string path.
        :param text: string path
        :return: NA
        """
        log("Begin gen regular string...")
        if not text:
            return ""
        insStr = text
        insList = insStr.split(os.sep)
        regString = ""
        for i in insList:
            if(i == ""):
                continue
            else:
                regString += r"\/" + i
        log("End gen regular string")
        return regString

    def cleanEnvironment(self):
        """
        Clear environment variables
        :return: NA
        """
        log("Begin clean user environment variables...")

        # Clear environment variable GSDB_DATA
        data_cmd = r"/^\s*export\s*GSDB_DATA=.*$/d"
        # Clear environment variable PATH about database
        path_cmd = (r"/^\s*export\s*PATH=.*%s\/bin.*:\$PATH$/d"
                    % self.genregstring(self.installPath))
        # Clear environment variable LD_LIBRARY_PATH about database
        lib_cmd = (r"/^\s*export\s*LD_LIBRARY_PATH=.*%s\/lib.*:.*%s\/add-ons.*:\$LD_LIBRARY_PATH$/d"
                   % (self.genregstring(self.installPath),
                      self.genregstring(self.installPath)))
        # Clear environment variable GSDB_HOME
        home_cmd = r"/^\s*export\s*GSDB_HOME=.*$/d"

        cmds = [path_cmd, lib_cmd, home_cmd]
        if self.option == self.INS_ALL:
            cmds.insert(0, data_cmd)

        # do clean
        for cmd in cmds:
            cmd = 'sed -i "%s" "%s"' % (cmd, self.userProfile)
            log("Clean environment variables cmd: %s" % cmd)
            ret_code, _, stderr = _exec_popen(cmd)
            if ret_code:
                log("Failed to clean environment variables. Error: %s" % stderr)
                logExit("Failed to clean environment variables.")
        log("End clean user environment variables...")

    def rollBack(self):
        """
        Rollback operation.

        This function mainly used to fail during the installation process,
        clear the files and environment variables that have been installed,
        and let the environment restore the state before installation.
        :return: NA
        """
        log("Begin roll back...")

        if not self.userProfile:
            logExit("Roll back failed, can not find user user profile.")
        log("Roll back type: " + self.FAILED_POS)
        # rollback from decompress
        if self.FAILED_POS == self.DECOMPRESS_BIN_FAILED:
            #Delete program.
            if os.path.exists(self.installPath):
                shutil.rmtree(self.installPath)
                log("Roll back: " + self.installPath)
            if self.option == self.INS_ALL:
                #Delete data.
                if os.path.exists(self.data):
                    shutil.rmtree(self.data)
                    log("Roll back: " + self.data)
        # rollback from set user env
        elif(self.FAILED_POS == self.SET_ENV_FAILED
             or self.FAILED_POS == self.PRE_DATA_DIR_FAILED
             or self.FAILED_POS == self.INIT_DB_FAILED):
            log("Using user profile: " + self.userProfile)
            #Delete program
            if os.path.exists(self.installPath):
                shutil.rmtree(self.installPath)
                log("Roll back: remove " + self.installPath)
            if self.option == self.INS_ALL:
                #Delete data
                if os.path.exists(self.data):
                    shutil.rmtree(self.data)
                    log("Roll back: remove " + self.data)
            # Delete env value
            self.cleanEnvironment()

            log("Roll back: profile is updated ")
        # rollback from create database
        elif self.FAILED_POS == self.CREATE_DB_FAILED:
            log("Using user profile: " + self.userProfile)
            # backup zengine log before rm data
            strCmd = "cp -r %s/log %s " % (self.data, self.backup_log_dir)
            log("Begin to backup log cmd: " + strCmd)
            ret_code, _, stderr = _exec_popen(strCmd)
            if ret_code:
                logExit("Can not backup zengine log command: %s, output: %s" % (strCmd, stderr))
            log("Error:The detail log for CREATE_DB_FAILED: %s" % self.backup_log_dir)

            # kill database process
            if g_opts.install_user_privilege == "withoutroot":
                # user do install, kill process
                kill_cmd = r"proc_pid_list=`ps ux | grep %s$ | grep -v grep|awk '{print $2}'` && " % self.data
                kill_cmd += r"(if [ X\"$proc_pid_list\" != X\"\" ];then echo $proc_pid_list | xargs kill -9; exit 0; fi)"
            else:
                # root do install, need su - user kill process
                cmd = "proc_pid_list=\`ps ux | grep %s$ | grep -v grep | awk '{print \$2}'\`" % self.data
                cmd += " && (if [ X\\\"\$proc_pid_list\\\" != X\\\"\\\" ]; then echo \\\"\$proc_pid_list\\\" | xargs kill -9 ; exit 0; fi)"
                kill_cmd = "su - %s -c \"%s\" " % (self.user, cmd)

            log("kill process cmd: %s" % kill_cmd)
            ret_code, _, _ = _exec_popen(kill_cmd)
            if ret_code:
                logExit("kill process %s faild" % self.data)
            log("Roll back: process killed.")

            #Delete program
            if os.path.exists(self.installPath):
                shutil.rmtree(self.installPath)
                log("Roll back: remove " + self.installPath)
            #Delete data
            if os.path.exists(self.data):
                shutil.rmtree(self.data)
                log("Roll back: remove " + self.data)

            self.cleanEnvironment()

            log("Roll back: profile is updated ")
        # rollback from init, nothing to do
        elif self.FAILED_POS == self.FAILED_INIT:
            #init status, pass
            log("Roll back: init ")
        else:
            #should not be here.
            logExit("Roll back can not recognize this operation: " + str(self.FAILED_POS))
        log("End roll back")


    #############################################################################
    #check datadir and prepare cfg/zengine.ini, mkdir datadir/data, datadir/log
    #The function fails to execute, the log is printed, and then exits
    #############################################################################
    def prepareDataDir(self):
        """
        function: check datadir and prepare cfg/zengine.ini,
                  mkdir datadir/data, datadir/log, datadir/trc
        input : NA
        output: NA
        """
        print("Checking data dir and config file")
        try:
            self.FAILED_POS = self.PRE_DATA_DIR_FAILED
            strCmd = "chmod %s %s/ -R " % (CommonValue.KEY_DIRECTORY_MODE, self.data)
            log("Change privilege cmd: %s" % strCmd)
            ret_code, _, stderr = _exec_popen(strCmd)
            if ret_code:
                raise Exception("chmod %s return: " % CommonValue.KEY_DIRECTORY_MODE  + str(ret_code) + os.linesep + stderr)

            # create data, cfg, log dir, trc
            os.makedirs("%s/data" % self.data, CommonValue.KEY_DIRECTORY_PERMISSION)
            os.makedirs("%s/log" % self.data, CommonValue.KEY_DIRECTORY_PERMISSION)
            os.makedirs("%s/archive_log" % self.data, CommonValue.KEY_DIRECTORY_PERMISSION)
            os.makedirs("%s/trc" % self.data, CommonValue.KEY_DIRECTORY_PERMISSION)

            # move the config files about database.
            cmd = "mv -i %s/cfg %s" % (self.installPath, self.data)
            ret_code, _, stderr = _exec_popen(cmd)
            if ret_code:
                raise Exception("Can not create prepare data dir, command: %s, output: %s" % (cmd, stderr))

            # Change the mode of config files to 600
            cmd = "chmod %s %s/cfg/%s %s/cfg/%s" % (CommonValue.KEY_FILE_MODE, self.data, self.ZENGINE_CONF_FILE, self.data, self.ZENGINE_HBA_FILE)
            ret_code, _, stderr = _exec_popen(cmd)
            if ret_code:
                raise Exception("chmod %s return: " % CommonValue.KEY_FILE_MODE + str(ret_code) + os.linesep + stderr)

            # Change the owner of config files
            cmd = "chown %s:%s -R \"%s\"" % (self.user, self.group, self.data)
            log("Change owner cmd: %s" % cmd)
            ret_code, _, stderr = _exec_popen(cmd)
            if ret_code:
                raise Exception("chown to %s:%s return: %s%s%s" % (self.user, self.group, str(ret_code), os.linesep, stderr))
        except Exception as ex:
            self.rollBack()
            logExit(str(ex))

    ##################################################################
    # start zenith instance
    ##################################################################
    def start_instance(self, start_mode, start_inst_type=""):
        """
        function:start zenith instacne
        input : start mode, start type
        output: NA
        """
        #start zenith dn
        status_success = False
        # clean old backup log
        # backup log file before rm data
        backup_log_basedir = os.path.dirname(self.data)
        self.backup_log_dir = backup_log_basedir + "/log"
        if os.path.exists(self.backup_log_dir):
            shutil.rmtree(self.backup_log_dir)
            log("rm the backup log of zengine " + self.backup_log_dir)

        # Clean the old status log
        status_log = "%s/log/zenithstatus.log" % self.data
        if os.path.exists(status_log):
            os.remove(status_log)

        # Start instance.
        if g_opts.install_user_privilege == "withoutroot":
            cmd = "nohup %s/bin/zengine %s %s -D %s >> %s 2>&1 &" % (self.installPath,
                                                                     start_mode,
                                                                     start_inst_type,
                                                                     self.data,
                                                                     status_log)
        else:
            cmd = "su - %s -c \"nohup %s/bin/zengine %s %s -D %s >> %s 2>&1 & \"" % (self.user,
                                                                                     self.installPath,
                                                                                     start_mode,
                                                                                     start_inst_type,
                                                                                     self.data,
                                                                                     status_log)
        status, _, _ = _exec_popen(cmd)
        if status != 0:
            raise Exception("Can not start instance %s.\nStart cmd: %s." % (self.data, str(cmd)))

        # int some conidition, zenith start will take some time, 
        # so wait and check the process after the start command return,
        # 10s per wait, totally 1h, if more than 1h, we can't find the
        # process of zengine, we consider that start failed
        start_time = 1200
        tem_log_info = ""
        for i in range(0, start_time):
            time.sleep(3)
            if g_opts.install_user_privilege == "withoutroot":
                cmd = "ps ux | grep -v grep | grep zengine | grep %s$ |awk '{print $2}'" % (self.data)
            else:
                cmd = "su - %s -c \"ps ux | grep -v grep | grep zengine | grep %s$ |awk '{print \$2}'\" " % (
                                                                                                self.user,
                                                                                                self.data)
            ret_code, stdout, stderr = _exec_popen(cmd)
            if ret_code:
                status_success = False
                tem_log_info = "Failed to execute cmd: %s.output:%s" % (str(cmd), str(stderr))
                break
            else:
                all_the_text = open(status_log).read()
                log("Instance start log output:%s." % str(all_the_text))
                if all_the_text.find("instance started") > 0:
                    if stdout:
                        status_success = True
                        self.pid = stdout.strip()
                        log("start instance successfully, pid = %s" % stdout)
                        break
                elif all_the_text.find("instance startup failed") > 0:
                    status_success = False
                    tem_log_info = "instance startup failed "
                    break
            if (i + 1) == start_time:
                status_success = False
                tem_log_info = "Instance startup timeout, more than 3600s"
            elif (i % 30) != 0:
                log("Instance startup in progress, please wait.", True)

        # the log file's permission is 600, change it
        if os.path.exists(status_log):
            uid = pwd.getpwnam(self.user).pw_uid
            gid = grp.getgrnam(self.group).gr_gid
            os.chown(status_log, uid, gid)
            os.chmod(status_log, CommonValue.KEY_FILE_PERMISSION)

        if not status_success:
            raise Exception("Can not get instance '%s' process pid,The detailed information: '%s' " % (self.data,tem_log_info))


    def execute_sql_file(self, sql_file):
        """
        function: execute sql file
        input : sql cmd
        output: NA
        """
        if not self.enableSysdbaLogin:
            if not (g_opts.db_user and g_opts.db_passwd):
                raise Exception("sysdba login is disabled, please specify -P parameter"
                                " to input username and password, refer to --help.")
        # root or normal user can execute install command, and can enable
        # or disable sysdba user, so the zsql command have 4 condition
        # 1 root execute install.py and enable sysdba
        # 2 root execute install.py and disable sysdba
        # 3 normal user execute install.py and enable sysdba
        # 4 normal user execute install.py and disable sysdba
        if g_opts.install_user_privilege == "withoutroot":
            if self.enableSysdbaLogin:
                cmd = "%s/bin/zsql / as sysdba %s:%s -q -D %s -f \"%s\" " % (
                    self.installPath,
                    self.LOGIN_IP,
                    self.lsnr_port,
                    self.data,
                    sql_file)
            else:
                cmd = "echo \'%s\' | %s/bin/zsql %s@%s:%s -q -f \"%s\" " % (
                    g_opts.db_passwd, self.installPath,
                    g_opts.db_user,
                    self.LOGIN_IP,
                    self.lsnr_port,
                    sql_file)
        else:
            if self.enableSysdbaLogin:
                cmd = "su - %s -c \"%s/bin/zsql / as sysdba %s:%s -q -D %s -f \"%s\" \"" \
                      % (self.user, self.installPath, self.LOGIN_IP, self.lsnr_port, self.data, sql_file)
            else:
                cmd = "echo \'%s\' | su - %s -c \"%s/bin/zsql %s@%s:%s -q -f \"%s\"\"" % (
                    g_opts.db_passwd,
                    self.user,
                    self.installPath,
                    g_opts.db_user,
                    self.LOGIN_IP,
                    self.lsnr_port,
                    sql_file)

        return_code, stdout_data, stderr_data = _exec_popen(cmd)
        output = "%s%s" % (str(stdout_data), str(stderr_data))
        log("Execute sql file %s output: %s" % (sql_file, output))
        if return_code:
            g_opts.db_passwd = ""
            raise Exception("Failed to execute sql file %s, output:%s" % (sql_file, output))

        # return code is 0, but output has error info, GS-xxx, ZS-xxx
        result = output.replace("\n", "")
        if re.match(".*GS-\d{5}.*", result) or re.match(".*ZS-\d{5}.*", result):
            g_opts.db_passwd = ""
            raise Exception("Failed to execute sql file %s, output:%s" % (sql_file, output))

        # clean password, because this function is called once, so assgin empty string to 
        # g_opts.db_passwd, but if function is called more than once in the future, modify it
        g_opts.db_passwd = ""

    def createDb(self):
        """
        function:config zenith dn
                1. start dn
                2. create database guass
                3. create user
        input : NA
        output: NA
        """
        log("Creating database.", True)
        try:
            # 1.start dn process in nomount mode
            self.FAILED_POS = self.CREATE_DB_FAILED
            self.start_instance(self.NOMOUNT_MODE)

            log("create zenith database ...")
            if self.create_db_file:
                # execute customized sql file
                create_database_sql = self.create_db_file
            else:
                # execute default sql file
                # modify the sql file for create database
                sql_file_path = "%s/admin/scripts" % self.installPath
                dbDataPath = self.data.replace("/", r"\/")
                create_database_sql = os.path.join(sql_file_path, "create_database.sample.sql")

                fixSqlFileCmd = "sed -i 's/?/%s/g' %s" %(dbDataPath, create_database_sql)
                ret_code, _, _ = _exec_popen(fixSqlFileCmd)
                if ret_code:
                    raise Exception("sed create_database.sample.sql failed, data dir %s" % dbDataPath)
            # 2.create database
            self.execute_sql_file(create_database_sql)
        except Exception as err:
            self.rollBack()
            logExit(str(err))

        log("Creating database succeed.", True)

    def chmodInstallSqlfile(self):
        """
        function: when install finished, modify sql file permission to 400
        input : NA
        output: NA
        """
        try:
            strCmd = "find '%s'/admin -type f | xargs chmod %s " % (self.installPath, CommonValue.MIN_FILE_MODE)
            ret_code, _, _ = _exec_popen(strCmd)
            if ret_code:
                print("Change file permission to %s failed. Please chmod %s file"
                                "in directory %s/admin manually." % (CommonValue.MIN_FILE_MODE,
                                                                     CommonValue.MIN_FILE_MODE, self.installPath))
        except Exception as err:
            logExit(str(err))

    def securityAudit(self):
        """
        function:  securityAudit, add oper if you needed
                1. chmod sql file permission
                2. ...
                3.
        input : NA
        output: NA
        """

        log("Changing file permission due to security audit.", True)
        # 1. chmod sql file permission
        self.chmodInstallSqlfile()

    #############################################################################
    # The main process of installation.
    # It is not necessary to check the return value of each function,
    # because there are check behavior them. If failed to execute code,
    # they will print the log and exit.
    #############################################################################
    def install(self):
        """
        install zenith app and create database
        the step of install for rollback:
        1. init
        2. create database
        3. set user env
        4. decompress bin file
        the install process will save the install step in
        temp file, and when some step failed, the rollback
        process read the install step and clean the files
        and directory created when install
        """
        self.getRunPkg()
        if g_opts.install_user_privilege == "withoutroot":
            pass
        else:
            self.checkRunner()
        self.checkParameter()
        self.checkUser()
        self.checkOldInstall()
        self.checkConfigOptions()
        self.checkDIR()
        self.checkSHA256()
        self.decompressBin()
        self.setUserEnv()
        self.prepareDataDir()
        self.InitDbInstance()
        log("Successfully Initialize %s instance." % self.instance_name)
        if self.option == self.INS_ALL:
            self.createDb()
        self.securityAudit()
        log("Successfully install %s instance." % self.instance_name)


def main():
    """
    main entry
    """
    check_platform()
    parse_parameter()
    check_parameter()

    try:
        installer = Installer(g_opts.os_user, g_opts.os_group)
        installer.install()
        log("Install successfully, for more detail information see %s."
              % g_opts.log_file, True)
    except Exception as err:
        logExit("Install failed: " + str(err))

    if g_opts.fp:
        g_opts.fp.flush()
        g_opts.fp.close()


if __name__ == "__main__":
    main()
